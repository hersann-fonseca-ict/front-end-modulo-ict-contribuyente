prompt --application/pages/page_00113
begin
--   Manifest
--     PAGE: 00113
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>108
,p_default_id_offset=>149139848948344617
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>113
,p_user_interface_id=>wwv_flow_api.id(154283420613688838)
,p_name=>unistr('113-Solicitud Descripci\00F3n ')
,p_alias=>unistr('113-SOLICITUD-DESCRIPCI\00D3N')
,p_step_title=>unistr('113-Solicitud Descripci\00F3n ')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_browser_cache=>'N'
,p_last_updated_by=>'KIMBERLYN.SOLANO'
,p_last_upd_yyyymmddhh24miss=>'20230707102359'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(174437686810084818)
,p_plug_name=>unistr('Des-Inscripci\00F3n como agente retenedor de  impuesto')
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'MAESTRO_CONTRIBUYENTE'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(174438548162084826)
,p_plug_name=>'Des-inscripcion'
,p_parent_plug_id=>wwv_flow_api.id(174437686810084818)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_region_attributes=>'style="width: 900px;"'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>20
,p_plug_display_column=>3
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(174439134594084832)
,p_plug_name=>unistr('Informaci\00F3n Apoderado de la Entidad')
,p_parent_plug_id=>wwv_flow_api.id(174437686810084818)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_region_attributes=>'style="width: 900px;"'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>30
,p_plug_display_column=>3
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(174555055683053066)
,p_name=>' Requisitos solicitados'
,p_parent_plug_id=>wwv_flow_api.id(174437686810084818)
,p_template=>wwv_flow_api.id(154198847510688906)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_column=>3
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_REQUISITOS_INS,',
'       TIPO_REQUISTO,',
'       NOMBRE_REQUISITO,',
'       ID_TIPO_CONTRIBUYENTE,',
'       PKG_INSCRIPCION_REGULAR.EXISTE_ARCH_DESINCRIPCION (ID_REQUISITOS_INS,:P113_ID_DESINCRIPCION)EXISTE_ARCHIVO,',
'       case PKG_INSCRIPCION_REGULAR.EXISTE_ARCH_DESINCRIPCION (ID_REQUISITOS_INS,:P113_ID_DESINCRIPCION) ',
'           when ''S'' then ''far fa-check-circle''',
'           when ''N'' then ''fas fa-times-circle''',
'           when ''C'' then ''fas fa-question-circle''',
'       end as icon_class,       ',
'       case PKG_INSCRIPCION_REGULAR.EXISTE_ARCH_DESINCRIPCION (ID_REQUISITOS_INS,:P113_ID_DESINCRIPCION) ',
'           when ''S'' then ''#7AFF33''',
'           when ''N'' then ''#FF5733''',
'           when ''C'' then ''#F7DC6F''',
'       end as color_class,',
'       case PKG_INSCRIPCION_REGULAR.EXISTE_ARCH_DESINCRIPCION (ID_REQUISITOS_INS,:P113_ID_DESINCRIPCION) ',
'           when ''N'' then ''javascript:$s("P113_ID_REQUISITO",''||ID_REQUISITOS_INS||'');javascript:openModal("ID_REQUI"); $("#ID_REQUI").trigger("apexrefresh");''',
'           when ''S'' then ''#''',
'           when ''C'' then ''#''',
'       end as link ',
'  from TIPO_REQUISITOS',
'  where ID_TIPO_CONTRIBUYENTE = :P113_ID_TIPO_CONTRIBUYENTE',
'  and   TIPO_REQUISTO = ''D'''))
,p_display_when_condition=>'P113_ID_DESINCRIPCION'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P113_ID_TIPO_CONTRIBUYENTE,P113_ID_DESINCRIPCION'
,p_query_row_template=>wwv_flow_api.id(154225098567688891)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.set_region_column_width(
 p_id=>wwv_flow_api.id(174555055683053066)
,p_plug_column_width=>'style="width: 920px;"'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(174626277997759623)
,p_query_column_id=>1
,p_column_alias=>'ID_REQUISITOS_INS'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(174626435595759624)
,p_query_column_id=>2
,p_column_alias=>'TIPO_REQUISTO'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(174626528103759625)
,p_query_column_id=>3
,p_column_alias=>'NOMBRE_REQUISITO'
,p_column_display_sequence=>4
,p_column_heading=>'Requisitos'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(174626620323759626)
,p_query_column_id=>4
,p_column_alias=>'ID_TIPO_CONTRIBUYENTE'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(174626704849759627)
,p_query_column_id=>5
,p_column_alias=>'EXISTE_ARCHIVO'
,p_column_display_sequence=>5
,p_column_heading=>'Existe Archivo'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="fa #ICON_CLASS#" style="color: #COLOR_CLASS#;">',
'    <spam class="visuallyhidden">#EXISTE_ARCHIVO#</spam>',
'</span>'))
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(174626782668759628)
,p_query_column_id=>6
,p_column_alias=>'ICON_CLASS'
,p_column_display_sequence=>6
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(174626897576759629)
,p_query_column_id=>7
,p_column_alias=>'COLOR_CLASS'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(174628075154759641)
,p_query_column_id=>8
,p_column_alias=>'LINK'
,p_column_display_sequence=>9
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(174627451049759635)
,p_query_column_id=>9
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>8
,p_column_heading=>'&nbsp;'
,p_use_as_row_header=>'N'
,p_column_link=>'#LINK#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(187060548166387118)
,p_plug_name=>'Apoderado'
,p_parent_plug_id=>wwv_flow_api.id(174555055683053066)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(187060621672387119)
,p_name=>' Otros Requisitos '
,p_parent_plug_id=>wwv_flow_api.id(187060548166387118)
,p_template=>wwv_flow_api.id(154198847510688906)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_column=>3
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_REQUISITOS_INS,',
'       TIPO_REQUISTO,',
'       NOMBRE_REQUISITO,',
'       ID_TIPO_CONTRIBUYENTE,',
'       PKG_INSCRIPCION_REGULAR.EXISTE_ARCH_DESINCRIPCION (ID_REQUISITOS_INS,:P113_ID_DESINCRIPCION)EXISTE_ARCHIVO,',
'       case PKG_INSCRIPCION_REGULAR.EXISTE_ARCH_DESINCRIPCION (ID_REQUISITOS_INS,:P113_ID_DESINCRIPCION) ',
'           when ''S'' then ''far fa-check-circle''',
'           when ''N'' then ''fas fa-times-circle''',
'           when ''C'' then ''fas fa-question-circle''',
'       end as icon_class,       ',
'       case PKG_INSCRIPCION_REGULAR.EXISTE_ARCH_DESINCRIPCION (ID_REQUISITOS_INS,:P113_ID_DESINCRIPCION) ',
'           when ''S'' then ''#7AFF33''',
'           when ''N'' then ''#FF5733''',
'           when ''C'' then ''#F7DC6F''',
'       end as color_class,',
'       case PKG_INSCRIPCION_REGULAR.EXISTE_ARCH_DESINCRIPCION (ID_REQUISITOS_INS,:P113_ID_DESINCRIPCION) ',
'           when ''N'' then ''javascript:$s("P113_ID_REQUISITO",''||ID_REQUISITOS_INS||'');javascript:openModal("ID_REQUI"); $("#ID_REQUI").trigger("apexrefresh");''',
'           when ''S'' then ''#''',
'           when ''C'' then ''#''',
'       end as link ',
'  from TIPO_REQUISITOS',
'  where ID_TIPO_CONTRIBUYENTE = :P113_ID_TIPO_CONTRIBUYENTE',
'  and   TIPO_REQUISTO = ''O'''))
,p_display_condition_type=>'NEVER'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P113_ID_TIPO_CONTRIBUYENTE,P113_ID_DESINCRIPCION'
,p_query_row_template=>wwv_flow_api.id(154225098567688891)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.set_region_column_width(
 p_id=>wwv_flow_api.id(187060621672387119)
,p_plug_column_width=>'style="width: 920px;"'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(187061529081387128)
,p_query_column_id=>1
,p_column_alias=>'ID_REQUISITOS_INS'
,p_column_display_sequence=>9
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(187060774531387121)
,p_query_column_id=>2
,p_column_alias=>'TIPO_REQUISTO'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(187060877992387122)
,p_query_column_id=>3
,p_column_alias=>'NOMBRE_REQUISITO'
,p_column_display_sequence=>3
,p_column_heading=>'Requisitos'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(187061012413387123)
,p_query_column_id=>4
,p_column_alias=>'ID_TIPO_CONTRIBUYENTE'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(187061103025387124)
,p_query_column_id=>5
,p_column_alias=>'EXISTE_ARCHIVO'
,p_column_display_sequence=>5
,p_column_heading=>'Existe Archivo'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="fa #ICON_CLASS#" style="color: #COLOR_CLASS#;">',
'    <spam class="visuallyhidden">#EXISTE_ARCHIVO#</spam>',
'</span>'))
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(187061164687387125)
,p_query_column_id=>6
,p_column_alias=>'ICON_CLASS'
,p_column_display_sequence=>6
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(187061271815387126)
,p_query_column_id=>7
,p_column_alias=>'COLOR_CLASS'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(187060674674387120)
,p_query_column_id=>8
,p_column_alias=>'LINK'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(187061416205387127)
,p_query_column_id=>9
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>8
,p_column_heading=>'&nbsp;'
,p_use_as_row_header=>'N'
,p_column_link=>'#LINK#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(174627582607759636)
,p_plug_name=>'Adjuntar Archivos'
,p_region_name=>'ID_REQUI'
,p_parent_plug_id=>wwv_flow_api.id(174437686810084818)
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size480x320'
,p_plug_template=>wwv_flow_api.id(154191258258688908)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(265489402150614199)
,p_plug_name=>'Tirulo'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
unistr('<center><h3>Solicitud Des-inscripci\00F3n</h3></center>')))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(174628318431759643)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(174627582607759636)
,p_button_name=>'BTN_GUARDA_ARCHIVO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(174627132899759631)
,p_button_sequence=>170
,p_button_plug_id=>wwv_flow_api.id(174439134594084832)
,p_button_name=>'BTN_SIGUIENTE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Siguiente'
,p_button_position=>'BELOW_BOX'
,p_button_condition=>'P113_ID_DESINCRIPCION'
,p_button_condition_type=>'ITEM_IS_NULL'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(174627995478759640)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(187060548166387118)
,p_button_name=>'BTN_ENVIAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Enviar'
,p_button_position=>'REGION_TEMPLATE_CREATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(192279022645450563)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(174437686810084818)
,p_button_name=>'BTN_CANCELAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cancelar'
,p_button_position=>'TOP'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(174365524767375554)
,p_branch_name=>'Go To Page 113'
,p_branch_action=>'f?p=&APP_ID.:126:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(174627995478759640)
,p_branch_sequence=>1
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(180217299236062934)
,p_branch_name=>'Go To Page 110'
,p_branch_action=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.::P110_NUM_SOLICITUD,P110_NOMBRE_ENTIDAD:&P113_ID_DESINCRIPCION.,&P113_NOMBRE_ENTIDAD.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(174628318431759643)
,p_branch_sequence=>11
,p_branch_condition_type=>'NEVER'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174357811630375567)
,p_name=>'P113_NOMBRE_ENTIDAD'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(174438548162084826)
,p_item_source_plug_id=>wwv_flow_api.id(174437686810084818)
,p_prompt=>'Nombre Entidad:'
,p_source=>'NOMBRE_ENTIDAD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174358140035375563)
,p_name=>'P113_ID_TIPO_IDENTIFICACION'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(174438548162084826)
,p_item_source_plug_id=>wwv_flow_api.id(174437686810084818)
,p_prompt=>unistr('Tipo Identificaci\00F3n')
,p_source=>'ID_TIPO_IDENTIFICACION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_TIPO_IDENTIFICACION'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174358506550375562)
,p_name=>'P113_RAZON_SOCIAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(174438548162084826)
,p_item_source_plug_id=>wwv_flow_api.id(174437686810084818)
,p_prompt=>unistr('Raz\00F3n Social:')
,p_source=>'RAZON_SOCIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P113_ID_TIPO_IDENTIFICACION'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174358921675375562)
,p_name=>'P113_PERSONA_FISICA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(174438548162084826)
,p_item_source_plug_id=>wwv_flow_api.id(174437686810084818)
,p_prompt=>'Persona Fisica'
,p_source=>'PERSONA_FISICA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P113_ID_TIPO_IDENTIFICACION'
,p_display_when2=>'2'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174359332967375562)
,p_name=>'P113_CEDULA_JURIDICA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(174438548162084826)
,p_item_source_plug_id=>wwv_flow_api.id(174437686810084818)
,p_prompt=>'Cedula Juridica'
,p_source=>'CEDULA_JURIDICA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P113_ID_TIPO_IDENTIFICACION'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174359735599375561)
,p_name=>'P113_CEDULA_FISICA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(174438548162084826)
,p_item_source_plug_id=>wwv_flow_api.id(174437686810084818)
,p_prompt=>'Cedula Fisica'
,p_source=>'CEDULA_FISICA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P113_ID_TIPO_IDENTIFICACION'
,p_display_when2=>'2'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174360138293375561)
,p_name=>'P113_ID_TIPO_CONTRIBUYENTE'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(174438548162084826)
,p_item_source_plug_id=>wwv_flow_api.id(174437686810084818)
,p_prompt=>'Tipo Contribuyente:'
,p_source=>'ID_TIPO_CONTRIBUYENTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_CONTRIBUYENTE_IR'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174360459093375561)
,p_name=>'P113_CODIGO_IATA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(174438548162084826)
,p_item_source_plug_id=>wwv_flow_api.id(174437686810084818)
,p_prompt=>'Codigo Iata'
,p_source=>'CODIGO_IATA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P113_VAL_COD_IATA'
,p_display_when2=>'S'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174437876821084820)
,p_name=>'P113_FECHA_CESE_OPE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(174438548162084826)
,p_prompt=>'Cese Operaciones:'
,p_format_mask=>'DD/MM/YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174438715703084828)
,p_name=>'P113_MOV_CESE'
,p_is_required=>true
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(174438548162084826)
,p_prompt=>'Motivo Cese Operaciones:'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>80
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(154259886985688872)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174438751497084829)
,p_name=>'P113_NOM_APODERADO'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(174439134594084832)
,p_prompt=>'Nombre:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174438871022084830)
,p_name=>'P113_CED_APODERADO'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(174439134594084832)
,p_prompt=>'Cedula:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>10
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174438961941084831)
,p_name=>'P113_CORREO_APODERADO'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(174439134594084832)
,p_prompt=>'Correo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174441315161084854)
,p_name=>'P113_ID_CONTRIBUYENTE'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(174438548162084826)
,p_item_source_plug_id=>wwv_flow_api.id(174437686810084818)
,p_prompt=>unistr(' C\00F3digo Tributario:')
,p_source=>'ID_CONTRIBUYENTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174627153719759632)
,p_name=>'P113_ID_DESINCRIPCION'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_api.id(174439134594084832)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174627697835759637)
,p_name=>'P113_ID_REQUISITO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(174627582607759636)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174627848494759638)
,p_name=>'P113_ARCHIVO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(174627582607759636)
,p_prompt=>'Archivo:'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_field_template=>wwv_flow_api.id(154259822246688872)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(186205614944847867)
,p_name=>'P113_MENSAJE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(187060548166387118)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('Declaro bajo fe de juramento que la informaci\00F3n consignada en este documento es cierta, asumo las responsabilidades y'),
unistr('consecuencias legales que correspondan en caso de omisi\00F3n, falsedad o inexactitud.')))
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(154259822246688872)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(186834165272930124)
,p_name=>'P113_ESTADO'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(174438548162084826)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(187061602334387129)
,p_name=>'P113_FECHA_SUSCRITO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(187060548166387118)
,p_item_default=>'SYSDATE'
,p_item_default_type=>'PLSQL_EXPRESSION'
,p_prompt=>'Fecha:'
,p_format_mask=>'DD/MM/YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>10
,p_tag_attributes=>'disabled=disabled'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'focus'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(187061717730387130)
,p_name=>'P113_LUGAR_SUSCRITO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(187060548166387118)
,p_item_default=>unistr('''San Jos\00E9''')
,p_item_default_type=>'PLSQL_EXPRESSION'
,p_prompt=>'Suscrito en:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>10
,p_tag_attributes=>'disabled=disabled'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(187061809046387131)
,p_name=>'P113_USUARIO_INTERNO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(187060548166387118)
,p_item_default=>':APP_USER'
,p_item_default_type=>'PLSQL_EXPRESSION'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(192279126348450564)
,p_name=>'P113_VAL_COD_IATA'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(174438548162084826)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(186833823921930120)
,p_name=>'DAC_BTN_SIGUIENTE'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P113_MOV_CESE'
,p_condition_element=>'P113_MOV_CESE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186833920169930121)
,p_event_id=>wwv_flow_api.id(186833823921930120)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(174627132899759631)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186833977975930122)
,p_event_id=>wwv_flow_api.id(186833823921930120)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(174627132899759631)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(186834290142930125)
,p_name=>'DAC_BTN_ENVIAR'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P113_ESTADO'
,p_condition_element=>'P113_ESTADO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'E'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186834366536930126)
,p_event_id=>wwv_flow_api.id(186834290142930125)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(174627995478759640)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186834463814930127)
,p_event_id=>wwv_flow_api.id(186834290142930125)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(174627995478759640)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(232310224575278345)
,p_name=>'DAC_UPPER_MOV'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P113_MOV_CESE'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(232310261209278346)
,p_event_id=>wwv_flow_api.id(232310224575278345)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P113_MOV_CESE").val($("#P113_MOV_CESE").val().toUpperCase());'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(174046495980863262)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_DATOS_CONTRIBU'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    vId_contribuyente NUMBER;',
'    vId_Num_inscripcion NUMBER;',
'    vId_Apoderado NUMBER;',
'    vNombre_Apoderado VARCHAR2(80);',
'    vCedula_Apoderado VARCHAR2(20);',
'    vCorreo_Apoderado VARCHAR2(40);',
'    vEstado VARCHAR2(3);',
'    vFechaOpe DATE;',
'    ',
'    --Obtenemos el id contribuyente del usuario logueado',
'    CURSOR C_MC IS',
'    SELECT ID_CONTRIBUYENTE',
'    FROM   USUARIOS_EXTERNOS',
'    WHERE ID_USUARIO = :APP_USER;',
'    ',
'    -- Obtenemos si el contribuyente tiene inscripcion o fue migrado',
'    CURSOR C_MC_NUM_INS (p_id_contribuyente NUMBER) IS',
'    SELECT ID_NUM_INSCRIPCION',
'    FROM   MAESTRO_CONTRIBUYENTE',
'    WHERE id_contribuyente = p_id_contribuyente;',
'    ',
'        ',
'    --Obtenemos el apoderado',
'    CURSOR C_APODERADO(p_id_contribuyente NUMBER) IS',
'    SELECT MIN(id_apoderado)',
'    FROM APODERADOS ',
'    WHERE id_contribuyente = p_id_contribuyente ',
'    AND indica_autorizo = ''A'' ',
'    AND FECHA_FIN_AUTORIZA IS NULL ',
'    AND id_tipo_apoderado IS NOT NULL;',
'    ',
'    CURSOR C_VAL_DESINCRIPCION IS',
'    SELECT CODIGO_ESTADO',
'    FROM   SOLICITUD_DES_INSCRIPCION',
'    WHERE  ID_DESC_INSCRIPCION = :P113_ID_DESINCRIPCION;',
'BEGIN',
'    OPEN  C_MC;',
'    FETCH C_MC INTO vId_contribuyente;',
'    CLOSE C_MC;',
'    ',
'    :P113_ID_CONTRIBUYENTE := vId_contribuyente;',
'    vFechaOpe := SYSDATE;',
'    :P113_FECHA_CESE_OPE := vFechaOpe;',
'        ',
'    OPEN  C_MC_NUM_INS (vId_contribuyente); ',
'    FETCH C_MC_NUM_INS  INTO vId_Num_inscripcion;',
'    CLOSE C_MC_NUM_INS;',
'    ',
'    ',
'    OPEN  C_APODERADO(vId_contribuyente);',
'    FETCH C_APODERADO INTO vId_Apoderado;',
'    CLOSE C_APODERADO;',
'    ',
'    OPEN  C_VAL_DESINCRIPCION;',
'    FETCH C_VAL_DESINCRIPCION INTO vEstado;',
'    CLOSE C_VAL_DESINCRIPCION;',
'    ',
'    :P113_ESTADO := vEstado;  ',
'    ',
'    IF vEstado IN (''R'',''A'') THEN',
'        :P113_ID_DESINCRIPCION := NULL;',
'    END IF;',
'    ',
'    if vId_Num_inscripcion is not null',
'    then',
'      IF vId_Apoderado is not null then',
'       SELECT NOMBRE_APODERADO,CEDULA_APODERADO,CORREO_APODERADO INTO vNombre_Apoderado, vCedula_Apoderado, vCorreo_Apoderado FROM APODERADOS WHERE ID_CONTRIBUYENTE = vId_contribuyente AND ID_APODERADO = vId_Apoderado; ',
'       :P113_NOM_APODERADO    := vNombre_Apoderado;',
'       :P113_CED_APODERADO    := vCedula_Apoderado;',
'       :P113_CORREO_APODERADO := vCorreo_Apoderado;',
'      end if;',
'    end if;   ',
'    ',
'    BEGIN',
'IF :P113_ID_TIPO_CONTRIBUYENTE IN (4,5) THEN',
'    :P113_VAL_COD_IATA := ''N'';',
'    ELSE',
'    :P113_VAL_COD_IATA := ''S'';',
'END IF;',
'END;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>108
,p_default_id_offset=>149139848948344617
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(174366016594375551)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(174437686810084818)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialize form 113-Solicitud Descripci\00F3n ')
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(174627851524759639)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERT_DESINCRIPCION'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vDesincripcion NUMBER;',
'vMensaje_Retorno VARCHAR2(355);',
'vRetorno boolean;',
'BEGIN',
'PKG_INSCRIPCION_REGULAR.P_INSERT_SOLICITUD_DESINCRIP (vDesincripcion,',
'                              :P113_ID_CONTRIBUYENTE,',
'                              TO_DATE(:P113_FECHA_CESE_OPE,''DD/MM/YYYY''),',
'                              :P113_MOV_CESE,',
'                              :APP_USER,',
'                              vMensaje_Retorno,',
'                              vRetorno);',
'                              ',
':P113_ID_DESINCRIPCION :=  vDesincripcion;                             ',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(174627132899759631)
,p_process_when=>'P113_ID_DESINCRIPCION'
,p_process_when_type=>'ITEM_IS_NULL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(174628167177759642)
,p_process_sequence=>20
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTA_ARCHIVO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vMensaje_Retorno VARCHAR2(355);',
'vRetorno boolean;',
'vArchivo BLOB;',
'vMimetype VARCHAR2(255);',
'vFilename VARCHAR2(255);',
'BEGIN',
'    --Insertamos documentos requeridos',
'SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P113_ARCHIVO;',
'PKG_INSCRIPCION_REGULAR.P_INSERT_ARCH_REQUI_DESINSCRIP (:P113_ID_REQUISITO,',
'                                :P113_ID_DESINCRIPCION,',
'                                vFilename,',
'                                vArchivo,',
'                                vMimetype,',
'                                :APP_USER,',
'                                vMensaje_Retorno,',
'                                vRetorno);',
'--PKG_ENVIO_NOTIF_ICT_CONTRIB.NOTIF_INGRESO_DESINCRIPCION (:P113_ID_CONTRIBUYENTE,:P113_ID_DESINCRIPCION,6);                                ',
'END;                                                           '))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(174628318431759643)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(186834137766930123)
,p_process_sequence=>30
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_ENVIAR_SOLICITUD'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Begin',
'UPDATE SOLICITUD_DES_INSCRIPCION SET CODIGO_ESTADO = ''E'' WHERE ID_DESC_INSCRIPCION = :P113_ID_DESINCRIPCION;',
'COMMIT;',
'PKG_ENVIO_NOTIF_ICT_CONTRIB.NOTIFICA_CONTRIBUYENTES (:P113_ID_CONTRIBUYENTE,:P113_ID_DESINCRIPCION,6,''D'',''E'',0);  ',
'',
'PKG_ENVIO_NOTIF_ICT_CONTRIB.NOTIFICA_CONTRIBUYENTES (:P113_ID_CONTRIBUYENTE,:P113_ID_DESINCRIPCION,6,''D'',''I'',0); ',
'',
'End;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(174627995478759640)
);
wwv_flow_api.component_end;
end;
/
