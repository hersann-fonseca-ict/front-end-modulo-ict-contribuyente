prompt --application/pages/page_00131
begin
--   Manifest
--     PAGE: 00131
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>108
,p_default_id_offset=>149139848948344617
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>131
,p_user_interface_id=>wwv_flow_api.id(154283420613688838)
,p_name=>'131-Comprobante de pago COT'
,p_alias=>'131-COMPROBANTE-DE-PAGO-COT'
,p_step_title=>'Comprobante de pago'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'JORGE.ROJAS'
,p_last_upd_yyyymmddhh24miss=>'20240517100326'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(291088372459548251)
,p_plug_name=>'Principal'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(291349395935181241)
,p_plug_name=>'131-Comprobante de pago COT'
,p_parent_plug_id=>wwv_flow_api.id(291088372459548251)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'COMPROBANTE_PAGO_COT'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(583631343806058679)
,p_plug_name=>'Titulo'
,p_parent_plug_id=>wwv_flow_api.id(291088372459548251)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
unistr('<center><h4>Declaraci\00F3n Jurada de Ch\00E1rter Terrestre Transporte Internacional.</h4></center>'),
'<center><h4>Comprobante de pago</h4></center>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(152871098237666717)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(291349395935181241)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P131_ID_COMPROBANTE'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(152870289641666722)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(291349395935181241)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(152871448527666717)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(291349395935181241)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Enviar'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P131_ID_COMPROBANTE'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(152870621048666722)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(291349395935181241)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P131_ID_COMPROBANTE'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(152881740733666703)
,p_branch_name=>'Go To Page 110'
,p_branch_action=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.::P110_TIPO_INSCRIPCION:COT&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152871846668666716)
,p_name=>'P131_ID_COMPROBANTE'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(291349395935181241)
,p_item_source_plug_id=>wwv_flow_api.id(291349395935181241)
,p_item_default=>'SEQ_COMPROBANTE_COT'
,p_item_default_type=>'SEQUENCE'
,p_source=>'ID_COMPROBANTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152872285958666712)
,p_name=>'P131_ID_DECLARA_CTO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(291349395935181241)
,p_item_source_plug_id=>wwv_flow_api.id(291349395935181241)
,p_source=>'ID_DECLARA_CTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152872686571666712)
,p_name=>'P131_NUM_DEPOSITO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(291349395935181241)
,p_item_source_plug_id=>wwv_flow_api.id(291349395935181241)
,p_prompt=>unistr('N\00B0 Deposito/Transferencia:')
,p_source=>'NUM_DEPOSITO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>20
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152873057280666712)
,p_name=>'P131_NOMBRE_ENTIDAD'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(291349395935181241)
,p_item_source_plug_id=>wwv_flow_api.id(291349395935181241)
,p_prompt=>'Entidad:'
,p_source=>'NOMBRE_ENTIDAD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT NOMBRE_ENTIDAD, CODIGO_ENTIDAD  FROM ENTIDADES@CONSULTA_ICTX'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152873489698666711)
,p_name=>'P131_FECHA_COMPROB'
,p_source_data_type=>'DATE'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(291349395935181241)
,p_item_source_plug_id=>wwv_flow_api.id(291349395935181241)
,p_prompt=>'Fecha Comprobante:'
,p_format_mask=>'DD/MM/YYYY'
,p_source=>'FECHA_COMPROB'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>10
,p_cMaxlength=>255
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152873892587666711)
,p_name=>'P131_CODIGO_MONEDA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(291349395935181241)
,p_item_source_plug_id=>wwv_flow_api.id(291349395935181241)
,p_prompt=>unistr('C\00F3digo Moneda:')
,p_source=>'CODIGO_MONEDA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select upper(DESCRIPCION), CODIGO_MONEDA',
'from TIPO_MONEDAS@CONSULTA_ICTX',
'where CODIGO_MONEDA = :P127_CODIGO_MONEDA'))
,p_cHeight=>1
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152874279827666709)
,p_name=>'P131_MONTO_COMPROB'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(291349395935181241)
,p_item_source_plug_id=>wwv_flow_api.id(291349395935181241)
,p_prompt=>'Monto Comprobante:'
,p_source=>'MONTO_COMPROB'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(154259886985688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152874621884666709)
,p_name=>'P131_ARCHIVO1'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(291349395935181241)
,p_prompt=>'Archivos:'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(154259886985688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_11=>'.pdf'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152875084435666709)
,p_name=>'P131_ARCHIVO2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(291349395935181241)
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_11=>'.pdf'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152875493458666709)
,p_name=>'P131_ARCHIVO3'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(291349395935181241)
,p_display_as=>'NATIVE_FILE'
,p_cSize=>20
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_11=>'.pdf'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152875824915666709)
,p_name=>'P131_ALERTA'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(291349395935181241)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152879871190666705)
,p_name=>'DAC_VALIDA_COMPROBANTE'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P131_MONTO_COMPROB'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152880377534666704)
,p_event_id=>wwv_flow_api.id(152879871190666705)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vFecha DATE;',
'BEGIN',
' vFecha := TO_DATE(:P131_FECHA_COMPROB,''DD/MM/YYYY'');',
'IF PKG_TRAMITE_COT.VAL_CONPROBANTE_PAGO (:P131_NUM_DEPOSITO, :P131_NOMBRE_ENTIDAD,vFecha, REPLACE(:P131_MONTO_COMPROB,'','','''')) = ''S'' THEN',
'    :P131_ALERTA := ''S'';',
'ELSE',
'     :P131_ALERTA := ''N'';',
'END IF;',
'END;'))
,p_attribute_02=>'P131_ID_COMPROBANTE,P131_NOMBRE_ENTIDAD,P131_FECHA_COMPROB,P131_MONTO_COMPROB,P131_ALERTA,P131_NUM_DEPOSITO'
,p_attribute_03=>'P131_ALERTA'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152880765830666704)
,p_name=>'New'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P131_ALERTA'
,p_condition_element=>'P131_ALERTA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'S'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152881201972666704)
,p_event_id=>wwv_flow_api.id(152880765830666704)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>unistr('El dep\00F3sito bancario ya fue utilizado en otra transacci\00F3n, favor verificar')
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(152876637278666708)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(291349395935181241)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form 131-Comprobante de pago COT'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(152879484514666706)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTA_ARCHIVOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_retorno_boolean   boolean;',
'v_mensaje_retorno   varchar2(2000);',
'vArchivo BLOB;',
'vMimetype VARCHAR2(255);',
'vFilename VARCHAR2(255);',
'',
'BEGIN',
'       PKG_ENVIO_NOTIF_ICT_CONTRIB.NOTIFICA_INSCRIPCION_COT(:P131_ID_DECLARA_CTO,14,''E'',''I'');',
'       PKG_ENVIO_NOTIF_ICT_CONTRIB.NOTIFICA_INSCRIPCION_COT(:P131_ID_DECLARA_CTO,14,''I'',''I'');',
'    --Insertamos documentos',
'    IF :P131_ARCHIVO1 IS NOT NULL THEN',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P131_ARCHIVO1;',
'    PKG_TRAMITE_COT.ARCHIVOS_COMPROBANTE_PAGO (:P131_ID_COMPROBANTE,',
'                                                vFilename,',
'                                                vArchivo,',
'                                                vMimetype,',
'                                                v_mensaje_retorno,',
'                                                v_retorno_boolean); ',
'                                                                       ',
'   END IF;',
'   IF :P131_ARCHIVO2 IS NOT NULL THEN',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P131_ARCHIVO2;',
'    PKG_TRAMITE_COT.ARCHIVOS_COMPROBANTE_PAGO (:P131_ID_COMPROBANTE,',
'                                                vFilename,',
'                                                vArchivo,',
'                                                vMimetype,',
'                                                v_mensaje_retorno,',
'                                                v_retorno_boolean); ',
'                                                                       ',
'   END IF;',
'   IF :P131_ARCHIVO3 IS NOT NULL THEN',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P131_ARCHIVO3;',
'    PKG_TRAMITE_COT.ARCHIVOS_COMPROBANTE_PAGO (:P131_ID_COMPROBANTE,',
'                                                vFilename,',
'                                                vArchivo,',
'                                                vMimetype,',
'                                                v_mensaje_retorno,',
'                                                v_retorno_boolean); ',
'                                                                       ',
'   END IF;',
'   ',
'IF NOT v_retorno_boolean  ',
'   THEN',
'     RAISE_APPLICATION_ERROR(-20000,v_mensaje_retorno);',
'     rollback;',
'     return; ',
'   else ',
'      commit;',
'   end if;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(152871448527666717)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(152876200291666708)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(291349395935181241)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form 131-Comprobante de pago COT'
);
wwv_flow_api.component_end;
end;
/
