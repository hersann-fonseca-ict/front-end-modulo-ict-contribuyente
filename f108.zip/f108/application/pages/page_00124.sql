prompt --application/pages/page_00124
begin
--   Manifest
--     PAGE: 00124
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>108
,p_default_id_offset=>149139848948344617
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>124
,p_user_interface_id=>wwv_flow_api.id(154283420613688838)
,p_name=>'124- Inscripcion Agencias de Viajes No Recaudaras de impuestos'
,p_alias=>'124-INSCRIPCION-AGENCIAS-DE-VIAJES-NO-RECAUDARAS-DE-IMPUESTOS'
,p_step_title=>'Registro Agencias de Viajes No Recaudaras de impuestos'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_browser_cache=>'N'
,p_last_updated_by=>'KIMBERLYN.SOLANO'
,p_last_upd_yyyymmddhh24miss=>'20231011114614'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(184056055454637638)
,p_plug_name=>'Titulo'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
unistr('<center><h3>Registro Agencias de Viajes No Recaudaras de impuestos (para Declaraci\00F3n Informativa)</h3></center>')))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(184093927917279165)
,p_plug_name=>'Registro Agencias de Viajes No Recaudaras de impuestos'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'SOLICITUD_INSCRIPCION'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(184100955613279188)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(184093927917279165)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P124_ID_NUM_INSCRIPCION'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(184101394160279189)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(184093927917279165)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Enviar'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_execute_validations=>'N'
,p_button_condition=>'P124_ID_NUM_INSCRIPCION'
,p_button_condition_type=>'ITEM_IS_NULL'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(184099848442279183)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(184093927917279165)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cancelar'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(184100638690279188)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(184093927917279165)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_image_alt=>'Delete'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P124_ID_NUM_INSCRIPCION'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(184101660400279189)
,p_branch_name=>'Go To Page 110'
,p_branch_action=>unistr('f?p=&APP_ID.:110:&SESSION.::&DEBUG.::P110_NUM_SOLICITUD,P110_TIPO_INSCRIPCION,P110_MENSAJE:&P124_ID_NUM_INSCRIPCION.,ANRI,Estimado usuario, su gesti\00F3n de registro, ha sido enviada a la Administraci\00F3n Tributaria, su solicitud ser\00E1 resuelta en los pr\00F3ximos 10 d\00EDas naturales como m\00E1ximo. Cordialmente&success_msg=#SUCCESS_MSG#')
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(184055368675637631)
,p_name=>'P124_ARCHIVO'
,p_is_required=>true
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_api.id(184093927917279165)
,p_prompt=>unistr('Adjuntar Personer\00EDa jur\00EDdica:')
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_field_template=>wwv_flow_api.id(154259886985688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(184055528197637632)
,p_name=>'P124_APODERADO'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(184093927917279165)
,p_prompt=>unistr('Apoderado General\00EDsimo:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_colspan=>5
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(184055614830637633)
,p_name=>'P124_TELEFONO1'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(184093927917279165)
,p_prompt=>'Telefonos:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_colspan=>5
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(184055722801637634)
,p_name=>'P124_TELEFONO2'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_api.id(184093927917279165)
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_colspan=>5
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(184055762370637635)
,p_name=>'P124_CORREOS_NOTIF1'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_api.id(184093927917279165)
,p_prompt=>unistr(' Direcci\00F3n Electr\00F3nica para Notificaciones:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(154259886985688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(184055863747637636)
,p_name=>'P124_CORREOS_NOTIF2'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_api.id(184093927917279165)
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(184056007184637637)
,p_name=>'P124_ENCARGADO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_api.id(184093927917279165)
,p_item_source_plug_id=>wwv_flow_api.id(184093927917279165)
,p_prompt=>unistr('Encargado Declaraci\00F3n Informativa:')
,p_source=>'ENCARGADO_RESPONSABLE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>54
,p_cMaxlength=>80
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(184056297974637640)
,p_name=>'P124_TIPO_IMPUESTO'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_api.id(184093927917279165)
,p_item_default=>'1'
,p_prompt=>'Tipo Impuesto:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Impuesto del 5% (CR);1'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(184094280138279169)
,p_name=>'P124_ID_NUM_INSCRIPCION'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(184093927917279165)
,p_item_source_plug_id=>wwv_flow_api.id(184093927917279165)
,p_item_default=>'SEQ_SOLICITUD_INSCRIPCION'
,p_item_default_type=>'SEQUENCE'
,p_source=>'ID_NUM_INSCRIPCION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(184094613758279176)
,p_name=>'P124_NOMBRE_ENTIDAD'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(184093927917279165)
,p_item_source_plug_id=>wwv_flow_api.id(184093927917279165)
,p_prompt=>'Nombre completo:'
,p_source=>'NOMBRE_ENTIDAD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>50
,p_colspan=>5
,p_field_template=>wwv_flow_api.id(154259886985688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(184094998024279180)
,p_name=>'P124_ID_TIPO_IDENTIFICACION'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(184093927917279165)
,p_item_source_plug_id=>wwv_flow_api.id(184093927917279165)
,p_item_default=>'1'
,p_prompt=>unistr('Tipo Identificaci\00F3n:')
,p_source=>'ID_TIPO_IDENTIFICACION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>unistr('STATIC:Jur\00EDdica;1,F\00EDsica;2')
,p_cHeight=>1
,p_colspan=>5
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(184095373318279180)
,p_name=>'P124_RAZON_SOCIAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(184093927917279165)
,p_item_source_plug_id=>wwv_flow_api.id(184093927917279165)
,p_prompt=>unistr('Raz\00F3n Social:')
,p_source=>'RAZON_SOCIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>55
,p_cMaxlength=>80
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(184095840821279181)
,p_name=>'P124_CEDULA_JURIDICA'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(184093927917279165)
,p_item_source_plug_id=>wwv_flow_api.id(184093927917279165)
,p_prompt=>'Documento de identidad:'
,p_source=>'CEDULA_JURIDICA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_field_template=>wwv_flow_api.id(154259886985688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_help_text=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333).')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(184096246296279181)
,p_name=>'P124_CODIGO_IATA'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(184093927917279165)
,p_item_source_plug_id=>wwv_flow_api.id(184093927917279165)
,p_prompt=>unistr('C\00F3digo IATA:')
,p_source=>'CODIGO_IATA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(154259886985688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(184096613376279181)
,p_name=>'P124_DIRECCION_ENTIDAD'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_api.id(184093927917279165)
,p_item_source_plug_id=>wwv_flow_api.id(184093927917279165)
,p_prompt=>unistr('Direcci\00F3n Entidad:')
,p_source=>'DIRECCION_ENTIDAD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>56
,p_cMaxlength=>1000
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(184096974909279181)
,p_name=>'P124_NOMBRE_REPRE_LEGAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(184093927917279165)
,p_item_source_plug_id=>wwv_flow_api.id(184093927917279165)
,p_prompt=>'Representante Legal:'
,p_source=>'NOMBRE_REPRE_LEGAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>80
,p_colspan=>5
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(184208503213354824)
,p_name=>'P124_CEDULA_REPRE_LEGAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(184093927917279165)
,p_item_source_plug_id=>wwv_flow_api.id(184093927917279165)
,p_prompt=>'Cedula Representante:'
,p_source=>'CEDULA_REPRE_LEGAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_colspan=>5
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_help_text=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(184208551554354825)
,p_name=>'P124_CEDULA_APO'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(184093927917279165)
,p_prompt=>'Cedula Apoderado:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_colspan=>5
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_help_text=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(184208668334354826)
,p_name=>'P124_ADJUNTAR_APO'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(184093927917279165)
,p_prompt=>'Cedula Apoderado:'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>10
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(184208755513354827)
,p_name=>'P124_ADJUNTAR_REPRE'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(184093927917279165)
,p_prompt=>'Cedula Representante:'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(184210075094354840)
,p_name=>'P124_MENSAJE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(184093927917279165)
,p_item_default=>unistr('El contribuyente ya se encuentra inscrito, favor comunicarse con la Administraci\00F3n Tributaria del ICT.')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="color:red;"'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(184210244744354841)
,p_name=>'P124_EXISTE_MC'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(184093927917279165)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(187062727860387140)
,p_name=>'P124_ENVIA_CORREO'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_api.id(184093927917279165)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(187063289097387146)
,p_name=>'P124_EXISTE_IATA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(184093927917279165)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(187063409055387147)
,p_name=>'P124_MSJ_IATA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(184093927917279165)
,p_item_default=>unistr('C\00F3digo IATA ya existe')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="color:red;"'
,p_grid_column=>6
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(184056429765637641)
,p_validation_name=>'VAL_CORREO1'
,p_validation_sequence=>10
,p_validation=>'P124_CORREOS_NOTIF1'
,p_validation2=>'@'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Formato de correo no valido...'
,p_always_execute=>'Y'
,p_validation_condition=>'P124_CORREOS_NOTIF1'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(184055762370637635)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(184056476592637642)
,p_validation_name=>'VAL_CORREO2'
,p_validation_sequence=>20
,p_validation=>'P124_CORREOS_NOTIF2'
,p_validation2=>'@'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Formato de correo no valido...'
,p_always_execute=>'Y'
,p_validation_condition=>'P124_CORREOS_NOTIF2'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(184055863747637636)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(184056623618637643)
,p_validation_name=>'VAL_CEDULA'
,p_validation_sequence=>30
,p_validation=>'P124_CEDULA_JURIDICA'
,p_validation_type=>'ITEM_IS_ALPHANUMERIC'
,p_error_message=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_always_execute=>'Y'
,p_validation_condition=>'P124_CEDULA_JURIDICA'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(184095840821279181)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(184208881524354828)
,p_validation_name=>'VAL_CEDULA_APO'
,p_validation_sequence=>40
,p_validation=>'P124_CEDULA_APO'
,p_validation_type=>'ITEM_IS_ALPHANUMERIC'
,p_error_message=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_always_execute=>'Y'
,p_validation_condition=>'P124_CEDULA_APO'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(184208551554354825)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(184208955964354829)
,p_validation_name=>'VAL_CEDULA_REPRE'
,p_validation_sequence=>50
,p_validation=>'P124_CEDULA_REPRE_LEGAL'
,p_validation_type=>'ITEM_IS_ALPHANUMERIC'
,p_error_message=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_always_execute=>'Y'
,p_validation_condition=>'P124_CEDULA_REPRE_LEGAL'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(184208503213354824)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(160435329170400285)
,p_validation_name=>'VAL_COMAS_EMAIL1'
,p_validation_sequence=>60
,p_validation=>'P124_CORREOS_NOTIF1'
,p_validation2=>','
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_NO_CHAR_IN_STRING2'
,p_error_message=>'Formato de correo no valido, por favor verificar'
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(158829336704968245)
,p_validation_name=>'VAL_COMAS_EMAIL2'
,p_validation_sequence=>70
,p_validation=>'P124_CORREOS_NOTIF2'
,p_validation2=>','
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_NO_CHAR_IN_STRING2'
,p_error_message=>'Formato de correo no valido, por favor verificar'
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(184952733350269040)
,p_validation_name=>'VAL_IATA_SIN_GUION'
,p_validation_sequence=>80
,p_validation=>'P124_CODIGO_IATA'
,p_validation2=>'-'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>unistr('El c\00F3digo IATA no puede contener guiones (-)')
,p_associated_item=>wwv_flow_api.id(184096246296279181)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(202975908042379715)
,p_validation_name=>'VAL_VAL_IATA_NOT_NULL'
,p_validation_sequence=>90
,p_validation=>'P124_CODIGO_IATA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe ingresar el c\00F3digo IATA')
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_api.id(184096246296279181)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(202976006090379716)
,p_validation_name=>'VAL_NOM_NOT_NULL'
,p_validation_sequence=>100
,p_validation=>'P124_NOMBRE_ENTIDAD'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'El nombre de la entidad no puede ser nulo'
,p_always_execute=>'Y'
,p_validation_condition=>'P124_NOMBRE_ENTIDAD'
,p_validation_condition_type=>'ITEM_IS_NULL'
,p_associated_item=>wwv_flow_api.id(184094613758279176)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(202976194860379717)
,p_validation_name=>'VAL_CORREO_NOT_NULL'
,p_validation_sequence=>110
,p_validation=>'P124_CORREOS_NOTIF1'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Debe ingresar una direcci\00F3n de correo')
,p_validation_condition=>'P124_CORREOS_NOTIF1'
,p_validation_condition_type=>'ITEM_IS_NULL'
,p_associated_item=>wwv_flow_api.id(184055762370637635)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(184209934441354838)
,p_name=>'DAC_VALIDA_CEDULA'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P124_CEDULA_JURIDICA'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(184210021967354839)
,p_event_id=>wwv_flow_api.id(184209934441354838)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vExiste VARCHAR2(1);',
'BEGIN',
':P124_EXISTE_MC:= PKG_MAESTRO_CONTRIBUYENTE.VALIDA_EXISTE_MC (:P124_CEDULA_JURIDICA);',
'END;'))
,p_attribute_02=>'P124_CEDULA_JURIDICA'
,p_attribute_03=>'P124_EXISTE_MC'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(184210311414354842)
,p_name=>'DAC_MOSTRAR_MSJ'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P124_EXISTE_MC'
,p_condition_element=>'P124_EXISTE_MC'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'S'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(184210423548354843)
,p_event_id=>wwv_flow_api.id(184210311414354842)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P124_MENSAJE'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(184210455956354844)
,p_event_id=>wwv_flow_api.id(184210311414354842)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P124_MENSAJE'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(184705194777750127)
,p_event_id=>wwv_flow_api.id(184210311414354842)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(184101394160279189)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(184705269893750128)
,p_event_id=>wwv_flow_api.id(184210311414354842)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(184101394160279189)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(187063140873387144)
,p_name=>'DAC_VAL_IATA'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P124_CODIGO_IATA'
,p_condition_element=>'P124_CODIGO_IATA'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(187063237885387145)
,p_event_id=>wwv_flow_api.id(187063140873387144)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vExiste VARCHAR2(1);',
'BEGIN',
'vExiste:= PKG_MAESTRO_CONTRIBUYENTE.F_VALIDA_CODIGO_IATA (:P124_CODIGO_IATA);',
':P124_EXISTE_IATA := vExiste;',
'END;'))
,p_attribute_02=>'P124_CODIGO_IATA'
,p_attribute_03=>'P124_EXISTE_IATA'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(187063497802387148)
,p_name=>'DAC_MSJ_IATA'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P124_EXISTE_IATA'
,p_condition_element=>'P124_EXISTE_IATA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'S'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(187063634410387149)
,p_event_id=>wwv_flow_api.id(187063497802387148)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P124_MSJ_IATA'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(187063652003387150)
,p_event_id=>wwv_flow_api.id(187063497802387148)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P124_MSJ_IATA'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(187063825378387151)
,p_event_id=>wwv_flow_api.id(187063497802387148)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(184101394160279189)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(187063863967387152)
,p_event_id=>wwv_flow_api.id(187063497802387148)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(184101394160279189)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(192570949605360550)
,p_name=>'DAC_UPPER_NOM_ENTIDAD'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P124_NOMBRE_ENTIDAD'
,p_bind_type=>'bind'
,p_bind_event_type=>'focusout'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(192571091488360551)
,p_event_id=>wwv_flow_api.id(192570949605360550)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P124_NOMBRE_ENTIDAD").val($("#P124_NOMBRE_ENTIDAD").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(192571210604360552)
,p_name=>'DAC_RAZON_SOCIAL'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P124_RAZON_SOCIAL'
,p_bind_type=>'bind'
,p_bind_event_type=>'focusout'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(192571332216360553)
,p_event_id=>wwv_flow_api.id(192571210604360552)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P124_RAZON_SOCIAL").val($("#P124_RAZON_SOCIAL").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(192571393887360554)
,p_name=>'DAC_UPPER_APODERADO'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P124_APODERADO'
,p_bind_type=>'bind'
,p_bind_event_type=>'focusout'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(192571488486360555)
,p_event_id=>wwv_flow_api.id(192571393887360554)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P124_APODERADO").val($("#P124_APODERADO").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(192571642768360556)
,p_name=>'DAC_UPPER_NOM_REPRE'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P124_NOMBRE_REPRE_LEGAL'
,p_bind_type=>'bind'
,p_bind_event_type=>'focusout'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(192571719948360557)
,p_event_id=>wwv_flow_api.id(192571642768360556)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P124_NOMBRE_REPRE_LEGAL").val($("#P124_NOMBRE_REPRE_LEGAL").val().toUpperCase());'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>108
,p_default_id_offset=>149139848948344617
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(192571825786360558)
,p_name=>'DAC_UPPER_DIRECCION'
,p_event_sequence=>90
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P124_DIRECCION_ENTIDAD'
,p_bind_type=>'bind'
,p_bind_event_type=>'focusout'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(192571904129360559)
,p_event_id=>wwv_flow_api.id(192571825786360558)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P124_DIRECCION_ENTIDAD").val($("#P124_DIRECCION_ENTIDAD").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(192571994223360560)
,p_name=>'DAC_UPPER_ENCARGADO'
,p_event_sequence=>100
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P124_ENCARGADO'
,p_bind_type=>'bind'
,p_bind_event_type=>'focusout'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(192572049645360561)
,p_event_id=>wwv_flow_api.id(192571994223360560)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P124_ENCARGADO").val($("#P124_ENCARGADO").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(159255793232013745)
,p_name=>'DAC_LOWER_CORREO'
,p_event_sequence=>110
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P124_CORREOS_NOTIF1'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(159255897908013746)
,p_event_id=>wwv_flow_api.id(159255793232013745)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P124_CORREOS_NOTIF1").val($("#P124_CORREOS_NOTIF1").val().toLowerCase());'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(184102590620279192)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(184093927917279165)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form 124- Inscripcion Agencias de Viajes No Recaudaras de impuestos'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(184056151185637639)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTA_SOLICITUD'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vId_Num_Inscripcion NUMBER;',
'vIdApoderado NUMBER;',
'v_retorno_boolean   boolean;',
'v_mensaje_retorno   varchar2(2000);',
'vCed_Juridica VARCHAR2(20);',
'vCed_Fisica VARCHAR2(20);',
'',
'vArchivo BLOB;',
'vMimetype VARCHAR2(255);',
'vFilename VARCHAR2(255);',
'BEGIN',
'    IF :P124_ID_TIPO_IDENTIFICACION = 1 THEN',
'        vCed_Juridica:= :P124_CEDULA_JURIDICA;',
'    ELSE ',
'    vCed_Fisica:= :P124_CEDULA_JURIDICA;',
'    END IF;',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_SOLICITUD_INSCRIP(vId_Num_Inscripcion,',
'                               :P124_NOMBRE_ENTIDAD,',
'                               :P124_ID_TIPO_IDENTIFICACION,',
'                               :P124_RAZON_SOCIAL,',
'                               NULL,',
'                               vCed_Juridica,',
'                               vCed_Fisica,',
'                               16,',
'                               :P124_CODIGO_IATA,',
'                               NULL,',
'                               NULL,',
'                               :P124_DIRECCION_ENTIDAD,',
'                               NULL,',
'                               NULL,',
'                               NULL,',
'                               NULL,',
'                               NULL,',
'                               NULL,',
'                               NULL, ',
'                               NULL,',
'                               NULL,',
'                               NULL,                                  ',
'                               :P124_NOMBRE_REPRE_LEGAL,',
'                               :P124_CEDULA_REPRE_LEGAL,',
'                               NULL,',
'                               ''P'',',
'                               SYSDATE,--pFECHA_INSCRIPCION,',
'                               NULL,',
'                               NULL,--pOBSERVA_ADM_TRIBUTA,    ',
'                               NULL,--pFECHA_SUSCRITO,',
'                               NULL,--pLUGAR_SUSCRITO,',
'                               NULL,--pUSUARIO_INTERNO,',
'                               NULL,--ID_CHARTER',
'                               NULL,--ID_REQUISITOS_INS',
'                               NULL,',
'                               NULL,',
'                               NULL,',
'                               NULL,',
'                               :P124_ENCARGADO,',
'                               :APP_USER,',
'                               v_mensaje_retorno,',
'                               v_retorno_boolean);',
'                               COMMIT;',
'',
'    :P124_ID_NUM_INSCRIPCION := vId_Num_Inscripcion;',
'   --Insertamos el archivo del representante legal',
'   IF :P124_ADJUNTAR_REPRE IS NOT NULL THEN',
'           SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P124_ADJUNTAR_REPRE;',
'   ',
'   PKG_INSCRIPCION_REGULAR.P_INSERT_ARCHI_REPRE_LEGAL_IR (vArchivo,',
'                                  vFilename,',
'                                  vMimetype,',
'                                  vId_Num_Inscripcion,',
'                                 :APP_USER);',
'   END IF;                               ',
'    --Insertamos los datos en la tabla TELEFONO_X_SOLICITUD_INSCRIP-----------------',
'   PKG_INSCRIPCION_REGULAR.P_INSERT_TEL_SOLIC_INSCRIP (vId_Num_Inscripcion,',
'                                  :P124_TELEFONO1,',
'                                  NULL,',
'                                  :APP_USER,',
'                                  v_mensaje_retorno,',
'                                  v_retorno_boolean);',
'    IF :P124_TELEFONO2 IS NOT NULL THEN                                        ',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_TEL_SOLIC_INSCRIP (vId_Num_Inscripcion,',
'                                  :P124_TELEFONO2,',
'                                  NULL,',
'                                  :APP_USER,',
'                                  v_mensaje_retorno,',
'                                  v_retorno_boolean);',
'    END IF;                                         ',
'--Insertamos los datos en la tabla IMPUESTO_X_SOLICITUD_INSCRI------------------                                        ',
'     IF :P124_TIPO_IMPUESTO IS NOT NULL THEN',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_IMP_SOLIC_INSCRIP (vId_Num_Inscripcion,',
'                                  :P124_TIPO_IMPUESTO,',
'                                  NULL,',
'                                  NULL,',
'                                  NULL,',
'                                  :APP_USER,',
'                                  v_mensaje_retorno,',
'                                  v_retorno_boolean); ',
'    END IF;',
'    /*IF :P117_TIP_IMPUESTO_1 IS NOT NULL THEN ',
'    P_INSERT_IMP_SOLIC_INSCRIP (vId_Num_Inscripcion,',
'                                  :P117_TIP_IMPUESTO_1,',
'                                  NULL,',
'                                  NULL,',
'                                  NULL,',
'                                  v_mensaje_retorno,',
'                                  v_retorno_boolean); ',
'    END IF;',
'    IF :P117_TIP_IMPUESTO_2 IS NOT NULL THEN',
'    P_INSERT_IMP_SOLIC_INSCRIP (vId_Num_Inscripcion,',
'                                  :P117_TIP_IMPUESTO_2,',
'                                  NULL,',
'                                  NULL,',
'                                  NULL,',
'                                  v_mensaje_retorno,',
'                                  v_retorno_boolean);',
'    END IF;  */                          ',
'                                              ',
'--Inserta datos en la tabla CORREO_NOTIFICA_INSCRIP-----------------------------                                          ',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_CORREO_NOT_INSCRIP (vId_Num_Inscripcion,',
'                                 :P124_CORREOS_NOTIF1,',
'                                 :P124_CORREOS_NOTIF2,',
'                                 :APP_USER,',
'                                 v_mensaje_retorno,',
'                                 v_retorno_boolean);',
'                                 ',
'    IF :P124_ADJUNTAR_APO IS NOT NULL THEN',
'        SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P124_ADJUNTAR_APO;',
'    END IF;',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_APODERADOS_SOLICITUD (vIdApoderado,',
'                                   vId_Num_Inscripcion,',
'                                   2,',
'                                   :P124_APODERADO,',
'                                   :P124_CEDULA_APO,',
'                                   NULL,',
'                                   ''A'',',
'                                   vArchivo,',
'                                   vFilename,',
'                                   vMimetype,',
'                                   :APP_USER,',
'                                   v_mensaje_retorno,',
'                                   v_retorno_boolean);      ',
'                                   ',
'    IF :P124_ARCHIVO IS NOT NULL THEN',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P124_ARCHIVO;',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_ARCHIVO_REQUI_INSCRIP (NULL,',
'                                    vId_Num_Inscripcion,',
'                                    vFilename,',
'                                    vArchivo,',
'                                    vMimetype,',
'                                    :APP_USER,',
'                                    v_mensaje_retorno,',
'                                    v_retorno_boolean);  ',
'    END IF;',
'    :P124_ENVIA_CORREO := ''S'';',
'IF NOT v_retorno_boolean  ',
'   THEN',
'     RAISE_APPLICATION_ERROR(-20000,v_mensaje_retorno);',
'     rollback;',
'     return; ',
'   else ',
'      commit;',
'   end if;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(184101394160279189)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(187062053094387134)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_ENVIA_CORREO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'IF :P124_ID_NUM_INSCRIPCION IS NOT NULL THEN',
'--Envio de correo usuario externo',
'PKG_ENVIO_NOTIF_ICT_CONTRIB.NOTIFICA_INSCRIPCION (:P124_ID_NUM_INSCRIPCION,5,''E'',''I'');',
'--Envio de correo usuario interno',
'PKG_ENVIO_NOTIF_ICT_CONTRIB.NOTIFICA_INSCRIPCION (:P124_ID_NUM_INSCRIPCION,5,''I'',''I'');',
'END IF;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P124_ENVIA_CORREO'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'S'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(184102223965279191)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(184093927917279165)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form 124- Inscripcion Agencias de Viajes No Recaudaras de impuestos'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(184210614122354845)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DAC_DATOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
':P124_EXISTE_MC:= NULL;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
