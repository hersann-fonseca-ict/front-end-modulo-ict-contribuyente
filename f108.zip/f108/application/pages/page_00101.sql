prompt --application/pages/page_00101
begin
--   Manifest
--     PAGE: 00101
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>108
,p_default_id_offset=>149139848948344617
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>101
,p_user_interface_id=>wwv_flow_api.id(154283420613688838)
,p_name=>unistr('101-Requisitos para Des-inscripci\00F3n')
,p_alias=>unistr('101-REQUISITOS-PARA-DES-INSCRIPCI\00D3N')
,p_step_title=>unistr('101-Requisitos para Des-inscripci\00F3n')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_browser_cache=>'N'
,p_last_updated_by=>'KIMBERLYN.SOLANO'
,p_last_upd_yyyymmddhh24miss=>'20221121124857'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(156424473722818450)
,p_plug_name=>unistr('Requisitos para des-inscripci\00F3n')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(156422411639818429)
,p_plug_name=>'Transportes Terrestres'
,p_parent_plug_id=>wwv_flow_api.id(156424473722818450)
,p_region_template_options=>'#DEFAULT#:t-Region--controlsPosEnd:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154181813833688913)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_plug_display_when_cond2=>'4'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(156422489650818430)
,p_name=>'Reporte Transportes Terrestres'
,p_parent_plug_id=>wwv_flow_api.id(156422411639818429)
,p_template=>wwv_flow_api.id(154198847510688906)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--staticRowColors:t-Report--rowHighlightOff:t-Report--verticalBorders'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_REQUISITOS_INS,',
'       NOMBRE_REQUISITO',
'  from TIPO_REQUISITOS',
'  where TIPO_REQUISTO = ''D''',
'  and   ID_TIPO_CONTRIBUYENTE = ''4''',
'    and   CODIGO_ESTADO = ''AC'''))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(154225098567688891)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(156422550961818431)
,p_query_column_id=>1
,p_column_alias=>'ID_REQUISITOS_INS'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(156422739570818432)
,p_query_column_id=>2
,p_column_alias=>'NOMBRE_REQUISITO'
,p_column_display_sequence=>2
,p_column_heading=>'Requisito'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(156422795029818433)
,p_plug_name=>'Navieras'
,p_parent_plug_id=>wwv_flow_api.id(156424473722818450)
,p_region_template_options=>'#DEFAULT#:t-Region--controlsPosEnd:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154181813833688913)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_plug_display_when_cond2=>'5'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(156422947825818434)
,p_name=>'Reporte Navieras'
,p_parent_plug_id=>wwv_flow_api.id(156422795029818433)
,p_template=>wwv_flow_api.id(154198847510688906)
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--staticRowColors:t-Report--rowHighlightOff:t-Report--verticalBorders'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_REQUISITOS_INS,',
'       NOMBRE_REQUISITO',
'  from TIPO_REQUISITOS',
'  where TIPO_REQUISTO = ''D''',
'  and   ID_TIPO_CONTRIBUYENTE = ''5''',
'    and   CODIGO_ESTADO = ''AC'''))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(154225098567688891)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(156422961399818435)
,p_query_column_id=>1
,p_column_alias=>'ID_REQUISITOS_INS'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(156423060300818436)
,p_query_column_id=>2
,p_column_alias=>'NOMBRE_REQUISITO'
,p_column_display_sequence=>2
,p_column_heading=>'Requisito'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(159855665186064446)
,p_plug_name=>'Agencia de Viajes'
,p_parent_plug_id=>wwv_flow_api.id(156424473722818450)
,p_region_template_options=>'#DEFAULT#:t-Region--controlsPosEnd:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154181813833688913)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_plug_display_when_cond2=>'2'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(159836704893080114)
,p_name=>'Reporte Agencia de Viajes'
,p_parent_plug_id=>wwv_flow_api.id(159855665186064446)
,p_template=>wwv_flow_api.id(154198847510688906)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--staticRowColors:t-Report--rowHighlightOff:t-Report--verticalBorders'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_REQUISITOS_INS,',
'       NOMBRE_REQUISITO',
'  from TIPO_REQUISITOS',
'  where TIPO_REQUISTO = ''D''',
'  and   ID_TIPO_CONTRIBUYENTE = ''2''',
'  and   CODIGO_ESTADO = ''AC'''))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(154225098567688891)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(156421980563818425)
,p_query_column_id=>1
,p_column_alias=>'ID_REQUISITOS_INS'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(156422107665818426)
,p_query_column_id=>2
,p_column_alias=>'NOMBRE_REQUISITO'
,p_column_display_sequence=>2
,p_column_heading=>'Requisito'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(159855767749064447)
,p_plug_name=>unistr('L\00EDnea A\00E9rea')
,p_parent_plug_id=>wwv_flow_api.id(156424473722818450)
,p_region_template_options=>'#DEFAULT#:t-Region--controlsPosEnd:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154181813833688913)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_plug_display_when_cond2=>'3'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(159855937413064448)
,p_name=>unistr('Reporte L\00EDnea A\00E9rea')
,p_parent_plug_id=>wwv_flow_api.id(159855767749064447)
,p_template=>wwv_flow_api.id(154198847510688906)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--staticRowColors:t-Report--rowHighlightOff:t-Report--verticalBorders'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_REQUISITOS_INS,',
'       NOMBRE_REQUISITO',
'  from TIPO_REQUISITOS',
'  where TIPO_REQUISTO = ''D''',
'  and   ID_TIPO_CONTRIBUYENTE = ''3''',
'    and   CODIGO_ESTADO = ''AC'''))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(154225098567688891)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(156422153711818427)
,p_query_column_id=>1
,p_column_alias=>'ID_REQUISITOS_INS'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(156422314494818428)
,p_query_column_id=>2
,p_column_alias=>'NOMBRE_REQUISITO'
,p_column_display_sequence=>2
,p_column_heading=>'Requisito'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(172408639257123130)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(159836704893080114)
,p_button_name=>'BTN_FORMULARIO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Ir a Formulario'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:113:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(172408679721123131)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(159855937413064448)
,p_button_name=>'BTN_FORMULARIO2'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Ir a Formulario'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:113:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(172408800118123132)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(156422489650818430)
,p_button_name=>'BTN_FORMULARIO3'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Ir a Formulario'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:113:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(172408856041123133)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(156422947825818434)
,p_button_name=>'BTN_FORMULARIO4'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Ir a Formulario'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:113:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(192278850595450562)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(156424473722818450)
,p_button_name=>'BTN_CANCELAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cancelar'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.component_end;
end;
/
