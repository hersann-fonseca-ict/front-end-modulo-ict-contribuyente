prompt --application/pages/page_00127
begin
--   Manifest
--     PAGE: 00127
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>108
,p_default_id_offset=>149139848948344617
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>127
,p_user_interface_id=>wwv_flow_api.id(154283420613688838)
,p_name=>unistr('127-Formulario Declaraci\00F3n Jurada Ocasional Terrestre')
,p_alias=>unistr('127-FORMULARIO-DECLARACI\00D3N-JURADA-OCASIONAL-TERRESTRE')
,p_step_title=>unistr('Formulario Declaraci\00F3n Jurada Ocasional Terrestre')
,p_reload_on_submit=>'A'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'JORGE.ROJAS'
,p_last_upd_yyyymmddhh24miss=>'20240510151726'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(278517514350238800)
,p_plug_name=>'Principal'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(166182382120266336)
,p_plug_name=>'TituloTTR'
,p_parent_plug_id=>wwv_flow_api.id(278517514350238800)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
unistr('<center><h4>Solicitud Gesti\00F3n de Tr\00E1mite Terrestre Regular de Transporte Internacional.</h4></center>'),
unistr('<center><h4>Art\00EDculo 46, inciso a) Ley 1917 de 9 de agosto de 1955</h4></center>'),
unistr('<center><h4>Decreto Ejecutivo N\00B037979-MP-H-MEIC-G-J-TUR del 25 de octubre del 2013</h4></center>')))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_plug_display_when_cond2=>'17'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(278517191512238797)
,p_plug_name=>unistr('Formulario declaraci\00F3n Jurada ')
,p_parent_plug_id=>wwv_flow_api.id(278517514350238800)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'DECLARA_CHARTER_TERRESTRE_O'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(313527029560527005)
,p_plug_name=>'Titulo COT'
,p_parent_plug_id=>wwv_flow_api.id(278517514350238800)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
unistr('<center><h4>Declaraci\00F3n Jurada de Ch\00E1rter Terrestre Transporte Internacional.</h4></center>'),
unistr('<center><h4>Art\00EDculo 46, inciso a) Ley 1917 de 9 de agosto de 1955</h4></center>'),
unistr('<center><h4>Decreto Ejecutivo N\00B037979-MP-H-MEIC-G-J-TUR del 25 de octubre del 2013</h4></center>')))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_plug_display_when_cond2=>'8'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(152742669867926780)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(278517191512238797)
,p_button_name=>'BTN_GENERAR_PDF_CONTRATO_COT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Vista Previa Declaraci\00F3n Jurada')
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:130:&SESSION.::&DEBUG.:::'
,p_button_condition=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_button_condition2=>'8'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(167971411614571005)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(278517191512238797)
,p_button_name=>'BTN_GENERAR_PDF_CONTRATO_TTR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Vista Previa Declaraci\00F3n Jurada')
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:130:&SESSION.::&DEBUG.:::'
,p_button_condition=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_button_condition2=>'17'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(152742228181926781)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(278517191512238797)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Continuar'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(152743084299926780)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(278517191512238797)
,p_button_name=>'BTN_CANCELAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cancelar'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(152784092538926739)
,p_branch_name=>'Go to 129'
,p_branch_action=>'f?p=&APP_ID.:129:&SESSION.::&DEBUG.::P129_ID_DECLARA_CTO:&P127_ID_DECLARA_CTO.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(152742228181926781)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152743475786926780)
,p_name=>'P127_ID_COT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(278517191512238797)
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_display_when2=>'8'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152743825466926777)
,p_name=>'P127_ID_DECLARA_CTO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(278517191512238797)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152744244915926777)
,p_name=>'P127_FECHA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(278517191512238797)
,p_item_default=>'SYSDATE'
,p_item_default_type=>'PLSQL_EXPRESSION'
,p_prompt=>'Fecha:'
,p_format_mask=>'DD/MM/YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>10
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152744658834926777)
,p_name=>'P127_NUMERO_PLACA'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(278517191512238797)
,p_prompt=>unistr('N\00BA placa automotora:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_field_template=>wwv_flow_api.id(154259886985688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152745094474926777)
,p_name=>'P127_NOMBRE_ENTIDAD'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(278517191512238797)
,p_prompt=>unistr('Nombre due\00F1o f\00EDsico o jur\00EDdico:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>100
,p_field_template=>wwv_flow_api.id(154259886985688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152745401807926776)
,p_name=>'P127_ID_TIPO_IDENTIFICACION'
,p_is_required=>true
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(278517191512238797)
,p_prompt=>unistr('Tipo Identificaci\00F3n:')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_TIPO_IDENTIFICACION'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(154259886985688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152745869424926776)
,p_name=>'P127_CEDULA'
,p_is_required=>true
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(278517191512238797)
,p_prompt=>unistr('C\00E9dula:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(154259886985688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152746294002926775)
,p_name=>'P127_CONTRATO_ARRENDA'
,p_is_required=>true
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(278517191512238797)
,p_item_default=>'NULL;'
,p_item_default_type=>'PLSQL_FUNCTION_BODY'
,p_prompt=>'Contrato de arrendamiento?'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_SI_NO'
,p_lov=>'.'||wwv_flow_api.id(152784941721926735)||'.'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152746654775926775)
,p_name=>'P127_NOMBRE_ARRENDA'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(278517191512238797)
,p_prompt=>'Nombre de Arrendatario:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>80
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152747098957926775)
,p_name=>'P127_ID_TIPO_IDENTIFICA'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(278517191512238797)
,p_prompt=>unistr('Tipo Identificaci\00F3n:')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_TIPO_IDENTIFICACION'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152747456196926775)
,p_name=>'P127_CEDULA_ARRE'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(278517191512238797)
,p_prompt=>unistr('Identificaci\00F3n:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152747813173926775)
,p_name=>'P127_FECHA_INI_EXCUSION'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(278517191512238797)
,p_prompt=>unistr('Fecha Inicio Exclusi\00F3n:')
,p_format_mask=>'DD/MM/YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>10
,p_display_when=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_display_when2=>'8'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259886985688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152748274686926774)
,p_name=>'P127_FECHA_FIN_EXCUSION'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(278517191512238797)
,p_prompt=>unistr('Fecha Fin Exclusi\00F3n:')
,p_format_mask=>'DD/MM/YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>10
,p_begin_on_new_line=>'N'
,p_display_when=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_display_when2=>'8'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259886985688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152748624490926774)
,p_name=>'P127_DESTINO_VIAJE'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_api.id(278517191512238797)
,p_prompt=>'Destino del Viaje:'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>40
,p_cHeight=>5
,p_display_when=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_display_when2=>'8'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259886985688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152749072880926774)
,p_name=>'P127_ID_TIPO_PUESTO'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(278517191512238797)
,p_prompt=>'Tipo Puesto Fronterizo:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_TIPO_PUESTOF'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_display_when2=>'8'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259886985688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152749432257926774)
,p_name=>'P127_TOTAL_PASAJEROS'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_api.id(278517191512238797)
,p_prompt=>'Total pasajeros:'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>10
,p_begin_on_new_line=>'N'
,p_display_when=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_display_when2=>'8'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259886985688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152749883336926774)
,p_name=>'P127_CODIGO_MONEDA'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_api.id(278517191512238797)
,p_prompt=>unistr('C\00F3digo Moneda:')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select upper(DESCRIPCION), CODIGO_MONEDA',
'from TIPO_MONEDAS@CONSULTA_ICTX',
'where CODIGO_MONEDA in (1,2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_display_when2=>'8'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259886985688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152750291233926773)
,p_name=>'P127_MONTO_TOTAL_TRANS'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_api.id(278517191512238797)
,p_prompt=>'Monto Total por Transporte:'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>10
,p_display_when=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_display_when2=>'8'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259886985688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152750621366926773)
,p_name=>'P127_IMPUESTO_PAGAR'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_api.id(278517191512238797)
,p_prompt=>'Impuesto por pagar:'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>10
,p_begin_on_new_line=>'N'
,p_display_when=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_display_when2=>'8'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259886985688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152751042653926772)
,p_name=>'P127_NOMBRE_CHOFER'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_api.id(278517191512238797)
,p_prompt=>'Nombre Chofer:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>80
,p_display_when=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_display_when2=>'8'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259886985688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152751435240926772)
,p_name=>'P127_NOMBRE_GUIA'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_api.id(278517191512238797)
,p_prompt=>unistr('Nombre Gu\00EDa:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>80
,p_begin_on_new_line=>'N'
,p_display_when=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_display_when2=>'8'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152751895473926772)
,p_name=>'P127_CORREO_NOTIFICA1'
,p_is_required=>true
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_api.id(278517191512238797)
,p_prompt=>'Correo para Notificaciones 1:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>50
,p_field_template=>wwv_flow_api.id(154259886985688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152752257040926772)
,p_name=>'P127_CORREO_NOTIFICA2'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_api.id(278517191512238797)
,p_prompt=>'Correo para Notificaciones 2:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>50
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152752617265926772)
,p_name=>'P127_TELEFONO1'
,p_is_required=>true
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_api.id(278517191512238797)
,p_prompt=>'Telefono1:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(154259886985688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152753051338926772)
,p_name=>'P127_TELEFONO2'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_api.id(278517191512238797)
,p_prompt=>'Telefono2:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152753437636926771)
,p_name=>'P127_ID_OFICINA'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_api.id(278517191512238797)
,p_prompt=>'Oficina Regional Registro Nacional:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_OFICINA'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(154259886985688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152753812700926771)
,p_name=>'P127_CODIGO_ESTADO'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_api.id(278517191512238797)
,p_item_default=>'P'
,p_prompt=>'Estado:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_ESTADO_TRAMITE'
,p_lov=>'SELECT CODIGO_ESTADO, NOMBRE_ESTADO FROM estados_tramite@consulta_ictx where CODIGO_ESTADO IN (''AC'',''IA'',''A'',''R'',''P'',''RG'',''EN'')'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152754549924926771)
,p_name=>'P127_CLEAR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(313527029560527005)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152754909589926770)
,p_name=>'P127_ID_REPORTE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(313527029560527005)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(160745350371540646)
,p_name=>'P127_ID_CONTRIBUYENTE'
,p_item_sequence=>320
,p_item_plug_id=>wwv_flow_api.id(278517191512238797)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(166182409020266337)
,p_name=>'P127_CLEAR_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(166182382120266336)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(166182586409266338)
,p_name=>'P127_ID_REPORTE_1'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(166182382120266336)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(166182671213266339)
,p_name=>'P127_ID_TTR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(278517191512238797)
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_display_when2=>'4'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(167974052564571031)
,p_name=>'P127_CODIGO_TIBUTARIO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(278517191512238797)
,p_prompt=>unistr('C\00F3digo Tributario')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174899433876154102)
,p_name=>'P127_MENSAJE'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_api.id(278517191512238797)
,p_item_default=>unistr('Estimado contribuyente, favor seleccionar la moneda con la cual usted va a realizar el pago de impuestos, una vez realizado el tr\00E1mite no podr\00E1 ser modificada. Gracias')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(152755433467926757)
,p_validation_name=>'VAL_CORREO1'
,p_validation_sequence=>10
,p_validation=>'P127_CORREO_NOTIFICA1'
,p_validation2=>'@'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Formato de correo incorrecto'
,p_validation_condition=>'P127_CORREO_NOTIFICA1'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(152751895473926772)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(152755806331926755)
,p_validation_name=>'VAL_CORREO2'
,p_validation_sequence=>20
,p_validation=>'P127_CORREO_NOTIFICA2'
,p_validation2=>'@'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Formato de correo incorrecto'
,p_validation_condition=>'P127_CORREO_NOTIFICA2'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(152752257040926772)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(152756207431926755)
,p_validation_name=>'VAL_NOM_ARRE'
,p_validation_sequence=>30
,p_validation=>'P127_NOMBRE_ARRENDA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Campo Obligatorio'
,p_validation_condition=>'P127_CONTRATO_ARRENDA'
,p_validation_condition2=>'S'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_associated_item=>wwv_flow_api.id(152746654775926775)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(152757009028926755)
,p_validation_name=>'VAL_CED_ARRE'
,p_validation_sequence=>40
,p_validation=>'P127_CEDULA_ARRE'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Campo Obligatorio'
,p_validation_condition=>'P127_CONTRATO_ARRENDA'
,p_validation_condition2=>'S'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_associated_item=>wwv_flow_api.id(152747456196926775)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(152756629883926755)
,p_validation_name=>'VAL_TIP_CED_ARRE'
,p_validation_sequence=>50
,p_validation=>'P127_ID_TIPO_IDENTIFICA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Campo Obligatorio'
,p_validation_condition=>'P127_CONTRATO_ARRENDA'
,p_validation_condition2=>'S'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_associated_item=>wwv_flow_api.id(152747098957926775)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(167974547573571036)
,p_validation_name=>'DAC_NOT_NULL'
,p_validation_sequence=>60
,p_validation=>'P127_ID_OFICINA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Campo Obligatorio'
,p_associated_item=>wwv_flow_api.id(152753437636926771)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152779264874926742)
,p_name=>'DAC_MUESTRA_ARRENDAT'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_CONTRATO_ARRENDA'
,p_condition_element=>'P127_CONTRATO_ARRENDA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'S'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152779732666926742)
,p_event_id=>wwv_flow_api.id(152779264874926742)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P127_NOMBRE_ARRENDA,P127_ID_TIPO_IDENTIFICA,P127_CEDULA_ARRE'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152780249675926742)
,p_event_id=>wwv_flow_api.id(152779264874926742)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P127_NOMBRE_ARRENDA,P127_ID_TIPO_IDENTIFICA,P127_CEDULA_ARRE'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152780744878926742)
,p_event_id=>wwv_flow_api.id(152779264874926742)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'NULL;',
'IF :GLOBAL_TIPO_CONTRIBUYENTE = 8 THEN',
':P127_ID_REPORTE := 1220;',
'ELSE ',
':P127_ID_REPORTE := 1282;',
'END IF;',
'',
'END;'))
,p_attribute_02=>'P127_CONTRATO_ARRENDA,P127_NOMBRE_ARRENDA,P127_ID_TIPO_IDENTIFICA,P127_CEDULA_ARRE,P127_ID_REPORTE'
,p_attribute_03=>'P127_ID_REPORTE'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152781222614926741)
,p_event_id=>wwv_flow_api.id(152779264874926742)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P127_NOMBRE_ARRENDA := NULL;',
':P127_ID_TIPO_IDENTIFICA := NULL;',
':P127_CEDULA_ARRE := NULL;',
'IF :GLOBAL_TIPO_CONTRIBUYENTE = 8 THEN',
':P127_ID_REPORTE := 1240;',
'ELSE ',
':P127_ID_REPORTE := 1302;',
'END IF;',
''))
,p_attribute_02=>'P127_CONTRATO_ARRENDA,P127_ID_REPORTE'
,p_attribute_03=>'P127_NOMBRE_ARRENDA,P127_ID_TIPO_IDENTIFICA,P127_CEDULA_ARRE,P127_ID_REPORTE'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152781641012926741)
,p_name=>'DAC_FORMULA'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_MONTO_TOTAL_TRANS'
,p_bind_type=>'live'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152782188778926740)
,p_event_id=>wwv_flow_api.id(152781641012926741)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vImpuesto NUMBER;',
'BEGIN',
'vImpuesto:= :P127_MONTO_TOTAL_TRANS * 0.05;',
':P127_IMPUESTO_PAGAR:= vImpuesto;',
'END;'))
,p_attribute_02=>'P127_MONTO_TOTAL_TRANS,P127_IMPUESTO_PAGAR'
,p_attribute_03=>'P127_IMPUESTO_PAGAR'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152782661233926740)
,p_event_id=>wwv_flow_api.id(152781641012926741)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P127_IMPUESTO_PAGAR'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152783008671926740)
,p_name=>'DAC_SUBMIT_ITEMS'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_ID_OFICINA'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152783548001926740)
,p_event_id=>wwv_flow_api.id(152783008671926740)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'NULL;'
,p_attribute_02=>'P127_NUMERO_PLACA,P127_NOMBRE_ENTIDAD,P127_ID_TIPO_IDENTIFICACION,P127_CEDULA,P127_CONTRATO_ARRENDA,P127_NOMBRE_ARRENDA,P127_ID_TIPO_IDENTIFICA,P127_CEDULA_ARRE,P127_FECHA_INI_EXCUSION,P127_FECHA_FIN_EXCUSION,P127_DESTINO_VIAJE,P127_ID_TIPO_PUESTO,P1'
||'27_TOTAL_PASAJEROS,P127_CODIGO_MONEDA,P127_MONTO_TOTAL_TRANS,P127_IMPUESTO_PAGAR,P127_NOMBRE_CHOFER,P127_NOMBRE_GUIA,P127_CORREO_NOTIFICA1,P127_CORREO_NOTIFICA2,P127_TELEFONO1,P127_TELEFONO2,P127_ID_OFICINA'
,p_wait_for_result=>'Y'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>108
,p_default_id_offset=>149139848948344617
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152776961775926743)
,p_name=>'DAC_SUBMIT_ITEMS_22'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_TELEFONO2'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152777425555926743)
,p_event_id=>wwv_flow_api.id(152776961775926743)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'NULL;'
,p_attribute_02=>'P127_NUMERO_PLACA,P127_NOMBRE_ENTIDAD,P127_ID_TIPO_IDENTIFICACION,P127_CEDULA,P127_CONTRATO_ARRENDA,P127_NOMBRE_ARRENDA,P127_ID_TIPO_IDENTIFICA,P127_CEDULA_ARRE,P127_FECHA_INI_EXCUSION,P127_FECHA_FIN_EXCUSION,P127_DESTINO_VIAJE,P127_ID_TIPO_PUESTO,P1'
||'27_TOTAL_PASAJEROS,P127_CODIGO_MONEDA,P127_MONTO_TOTAL_TRANS,P127_IMPUESTO_PAGAR,P127_NOMBRE_CHOFER,P127_NOMBRE_GUIA,P127_CORREO_NOTIFICA1,P127_CORREO_NOTIFICA2,P127_TELEFONO1,P127_TELEFONO2,P127_ID_OFICINA'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152776007998926744)
,p_name=>'DAC_SUBMIT_ITEMS_21'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_TELEFONO1'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152776522675926744)
,p_event_id=>wwv_flow_api.id(152776007998926744)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'NULL;'
,p_attribute_02=>'P127_NUMERO_PLACA,P127_NOMBRE_ENTIDAD,P127_ID_TIPO_IDENTIFICACION,P127_CEDULA,P127_CONTRATO_ARRENDA,P127_NOMBRE_ARRENDA,P127_ID_TIPO_IDENTIFICA,P127_CEDULA_ARRE,P127_FECHA_INI_EXCUSION,P127_FECHA_FIN_EXCUSION,P127_DESTINO_VIAJE,P127_ID_TIPO_PUESTO,P1'
||'27_TOTAL_PASAJEROS,P127_CODIGO_MONEDA,P127_MONTO_TOTAL_TRANS,P127_IMPUESTO_PAGAR,P127_NOMBRE_CHOFER,P127_NOMBRE_GUIA,P127_CORREO_NOTIFICA1,P127_CORREO_NOTIFICA2,P127_TELEFONO1,P127_TELEFONO2,P127_ID_OFICINA'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152775132691926744)
,p_name=>'DAC_SUBMIT_ITEMS_20'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_CORREO_NOTIFICA2'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152775671617926744)
,p_event_id=>wwv_flow_api.id(152775132691926744)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'NULL;'
,p_attribute_02=>'P127_NUMERO_PLACA,P127_NOMBRE_ENTIDAD,P127_ID_TIPO_IDENTIFICACION,P127_CEDULA,P127_CONTRATO_ARRENDA,P127_NOMBRE_ARRENDA,P127_ID_TIPO_IDENTIFICA,P127_CEDULA_ARRE,P127_FECHA_INI_EXCUSION,P127_FECHA_FIN_EXCUSION,P127_DESTINO_VIAJE,P127_ID_TIPO_PUESTO,P1'
||'27_TOTAL_PASAJEROS,P127_CODIGO_MONEDA,P127_MONTO_TOTAL_TRANS,P127_IMPUESTO_PAGAR,P127_NOMBRE_CHOFER,P127_NOMBRE_GUIA,P127_CORREO_NOTIFICA1,P127_CORREO_NOTIFICA2,P127_TELEFONO1,P127_TELEFONO2,P127_ID_OFICINA'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152774375796926745)
,p_name=>'DAC_SUBMIT_ITEMS_19'
,p_event_sequence=>90
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_CORREO_NOTIFICA1'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152774853301926745)
,p_event_id=>wwv_flow_api.id(152774375796926745)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'NULL;'
,p_attribute_02=>'P127_NUMERO_PLACA,P127_NOMBRE_ENTIDAD,P127_ID_TIPO_IDENTIFICACION,P127_CEDULA,P127_CONTRATO_ARRENDA,P127_NOMBRE_ARRENDA,P127_ID_TIPO_IDENTIFICA,P127_CEDULA_ARRE,P127_FECHA_INI_EXCUSION,P127_FECHA_FIN_EXCUSION,P127_DESTINO_VIAJE,P127_ID_TIPO_PUESTO,P1'
||'27_TOTAL_PASAJEROS,P127_CODIGO_MONEDA,P127_MONTO_TOTAL_TRANS,P127_IMPUESTO_PAGAR,P127_NOMBRE_CHOFER,P127_NOMBRE_GUIA,P127_CORREO_NOTIFICA1,P127_CORREO_NOTIFICA2,P127_TELEFONO1,P127_TELEFONO2,P127_ID_OFICINA'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152773415804926745)
,p_name=>'DAC_SUBMIT_ITEMS_18'
,p_event_sequence=>100
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_NOMBRE_GUIA'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152773926491926745)
,p_event_id=>wwv_flow_api.id(152773415804926745)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'NULL;'
,p_attribute_02=>'P127_NUMERO_PLACA,P127_NOMBRE_ENTIDAD,P127_ID_TIPO_IDENTIFICACION,P127_CEDULA,P127_CONTRATO_ARRENDA,P127_NOMBRE_ARRENDA,P127_ID_TIPO_IDENTIFICA,P127_CEDULA_ARRE,P127_FECHA_INI_EXCUSION,P127_FECHA_FIN_EXCUSION,P127_DESTINO_VIAJE,P127_ID_TIPO_PUESTO,P1'
||'27_TOTAL_PASAJEROS,P127_CODIGO_MONEDA,P127_MONTO_TOTAL_TRANS,P127_IMPUESTO_PAGAR,P127_NOMBRE_CHOFER,P127_NOMBRE_GUIA,P127_CORREO_NOTIFICA1,P127_CORREO_NOTIFICA2,P127_TELEFONO1,P127_TELEFONO2,P127_ID_OFICINA'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152772503648926745)
,p_name=>'DAC_SUBMIT_ITEMS_17'
,p_event_sequence=>110
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_NOMBRE_CHOFER'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(166179964077266312)
,p_event_id=>wwv_flow_api.id(152772503648926745)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P127_NOMBRE_CHOFER").val($("#P127_NOMBRE_CHOFER").val().toUpperCase());'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152773094996926745)
,p_event_id=>wwv_flow_api.id(152772503648926745)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'NULL;'
,p_attribute_02=>'P127_NUMERO_PLACA,P127_NOMBRE_ENTIDAD,P127_ID_TIPO_IDENTIFICACION,P127_CEDULA,P127_CONTRATO_ARRENDA,P127_NOMBRE_ARRENDA,P127_ID_TIPO_IDENTIFICA,P127_CEDULA_ARRE,P127_FECHA_INI_EXCUSION,P127_FECHA_FIN_EXCUSION,P127_DESTINO_VIAJE,P127_ID_TIPO_PUESTO,P1'
||'27_TOTAL_PASAJEROS,P127_CODIGO_MONEDA,P127_MONTO_TOTAL_TRANS,P127_IMPUESTO_PAGAR,P127_NOMBRE_CHOFER,P127_NOMBRE_GUIA,P127_CORREO_NOTIFICA1,P127_CORREO_NOTIFICA2,P127_TELEFONO1,P127_TELEFONO2,P127_ID_OFICINA'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152771656833926746)
,p_name=>'DAC_SUBMIT_ITEMS_16'
,p_event_sequence=>120
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_IMPUESTO_PAGAR'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152772160154926746)
,p_event_id=>wwv_flow_api.id(152771656833926746)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'NULL;'
,p_attribute_02=>'P127_NUMERO_PLACA,P127_NOMBRE_ENTIDAD,P127_ID_TIPO_IDENTIFICACION,P127_CEDULA,P127_CONTRATO_ARRENDA,P127_NOMBRE_ARRENDA,P127_ID_TIPO_IDENTIFICA,P127_CEDULA_ARRE,P127_FECHA_INI_EXCUSION,P127_FECHA_FIN_EXCUSION,P127_DESTINO_VIAJE,P127_ID_TIPO_PUESTO,P1'
||'27_TOTAL_PASAJEROS,P127_CODIGO_MONEDA,P127_MONTO_TOTAL_TRANS,P127_IMPUESTO_PAGAR,P127_NOMBRE_CHOFER,P127_NOMBRE_GUIA,P127_CORREO_NOTIFICA1,P127_CORREO_NOTIFICA2,P127_TELEFONO1,P127_TELEFONO2,P127_ID_OFICINA'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152770721474926746)
,p_name=>'DAC_SUBMIT_ITEMS_15'
,p_event_sequence=>130
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_MONTO_TOTAL_TRANS'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152771222150926746)
,p_event_id=>wwv_flow_api.id(152770721474926746)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'NULL;'
,p_attribute_02=>'P127_NUMERO_PLACA,P127_NOMBRE_ENTIDAD,P127_ID_TIPO_IDENTIFICACION,P127_CEDULA,P127_CONTRATO_ARRENDA,P127_NOMBRE_ARRENDA,P127_ID_TIPO_IDENTIFICA,P127_CEDULA_ARRE,P127_FECHA_INI_EXCUSION,P127_FECHA_FIN_EXCUSION,P127_DESTINO_VIAJE,P127_ID_TIPO_PUESTO,P1'
||'27_TOTAL_PASAJEROS,P127_CODIGO_MONEDA,P127_MONTO_TOTAL_TRANS,P127_IMPUESTO_PAGAR,P127_NOMBRE_CHOFER,P127_NOMBRE_GUIA,P127_CORREO_NOTIFICA1,P127_CORREO_NOTIFICA2,P127_TELEFONO1,P127_TELEFONO2,P127_ID_OFICINA'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152769871114926746)
,p_name=>'DAC_SUBMIT_ITEMS_14'
,p_event_sequence=>140
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_CODIGO_MONEDA'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152770366949926746)
,p_event_id=>wwv_flow_api.id(152769871114926746)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'NULL;'
,p_attribute_02=>'P127_NUMERO_PLACA,P127_NOMBRE_ENTIDAD,P127_ID_TIPO_IDENTIFICACION,P127_CEDULA,P127_CONTRATO_ARRENDA,P127_NOMBRE_ARRENDA,P127_ID_TIPO_IDENTIFICA,P127_CEDULA_ARRE,P127_FECHA_INI_EXCUSION,P127_FECHA_FIN_EXCUSION,P127_DESTINO_VIAJE,P127_ID_TIPO_PUESTO,P1'
||'27_TOTAL_PASAJEROS,P127_CODIGO_MONEDA,P127_MONTO_TOTAL_TRANS,P127_IMPUESTO_PAGAR,P127_NOMBRE_CHOFER,P127_NOMBRE_GUIA,P127_CORREO_NOTIFICA1,P127_CORREO_NOTIFICA2,P127_TELEFONO1,P127_TELEFONO2,P127_ID_OFICINA'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152768954501926747)
,p_name=>'DAC_SUBMIT_ITEMS_13'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_TOTAL_PASAJEROS'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152769424962926747)
,p_event_id=>wwv_flow_api.id(152768954501926747)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'NULL;'
,p_attribute_02=>'P127_NUMERO_PLACA,P127_NOMBRE_ENTIDAD,P127_ID_TIPO_IDENTIFICACION,P127_CEDULA,P127_CONTRATO_ARRENDA,P127_NOMBRE_ARRENDA,P127_ID_TIPO_IDENTIFICA,P127_CEDULA_ARRE,P127_FECHA_INI_EXCUSION,P127_FECHA_FIN_EXCUSION,P127_DESTINO_VIAJE,P127_ID_TIPO_PUESTO,P1'
||'27_TOTAL_PASAJEROS,P127_CODIGO_MONEDA,P127_MONTO_TOTAL_TRANS,P127_IMPUESTO_PAGAR,P127_NOMBRE_CHOFER,P127_NOMBRE_GUIA,P127_CORREO_NOTIFICA1,P127_CORREO_NOTIFICA2,P127_TELEFONO1,P127_TELEFONO2,P127_ID_OFICINA'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152768017579926747)
,p_name=>'DAC_SUBMIT_ITEMS_12'
,p_event_sequence=>160
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_ID_TIPO_PUESTO'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152768591902926747)
,p_event_id=>wwv_flow_api.id(152768017579926747)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'NULL;'
,p_attribute_02=>'P127_NUMERO_PLACA,P127_NOMBRE_ENTIDAD,P127_ID_TIPO_IDENTIFICACION,P127_CEDULA,P127_CONTRATO_ARRENDA,P127_NOMBRE_ARRENDA,P127_ID_TIPO_IDENTIFICA,P127_CEDULA_ARRE,P127_FECHA_INI_EXCUSION,P127_FECHA_FIN_EXCUSION,P127_DESTINO_VIAJE,P127_ID_TIPO_PUESTO,P1'
||'27_TOTAL_PASAJEROS,P127_CODIGO_MONEDA,P127_MONTO_TOTAL_TRANS,P127_IMPUESTO_PAGAR,P127_NOMBRE_CHOFER,P127_NOMBRE_GUIA,P127_CORREO_NOTIFICA1,P127_CORREO_NOTIFICA2,P127_TELEFONO1,P127_TELEFONO2,P127_ID_OFICINA'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152767193274926748)
,p_name=>'DAC_SUBMIT_ITEMS_11'
,p_event_sequence=>170
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_DESTINO_VIAJE'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(166179838960266311)
,p_event_id=>wwv_flow_api.id(152767193274926748)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P127_DESTINO_VIAJE").val($("#P127_DESTINO_VIAJE").val().toUpperCase());'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152767643921926747)
,p_event_id=>wwv_flow_api.id(152767193274926748)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'NULL;'
,p_attribute_02=>'P127_NUMERO_PLACA,P127_NOMBRE_ENTIDAD,P127_ID_TIPO_IDENTIFICACION,P127_CEDULA,P127_CONTRATO_ARRENDA,P127_NOMBRE_ARRENDA,P127_ID_TIPO_IDENTIFICA,P127_CEDULA_ARRE,P127_FECHA_INI_EXCUSION,P127_FECHA_FIN_EXCUSION,P127_DESTINO_VIAJE,P127_ID_TIPO_PUESTO,P1'
||'27_TOTAL_PASAJEROS,P127_CODIGO_MONEDA,P127_MONTO_TOTAL_TRANS,P127_IMPUESTO_PAGAR,P127_NOMBRE_CHOFER,P127_NOMBRE_GUIA,P127_CORREO_NOTIFICA1,P127_CORREO_NOTIFICA2,P127_TELEFONO1,P127_TELEFONO2,P127_ID_OFICINA'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152766230369926748)
,p_name=>'DAC_SUBMIT_ITEMS_10'
,p_event_sequence=>180
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_FECHA_FIN_EXCUSION'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152766712856926748)
,p_event_id=>wwv_flow_api.id(152766230369926748)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'NULL;'
,p_attribute_02=>'P127_NUMERO_PLACA,P127_NOMBRE_ENTIDAD,P127_ID_TIPO_IDENTIFICACION,P127_CEDULA,P127_CONTRATO_ARRENDA,P127_NOMBRE_ARRENDA,P127_ID_TIPO_IDENTIFICA,P127_CEDULA_ARRE,P127_FECHA_INI_EXCUSION,P127_FECHA_FIN_EXCUSION,P127_DESTINO_VIAJE,P127_ID_TIPO_PUESTO,P1'
||'27_TOTAL_PASAJEROS,P127_CODIGO_MONEDA,P127_MONTO_TOTAL_TRANS,P127_IMPUESTO_PAGAR,P127_NOMBRE_CHOFER,P127_NOMBRE_GUIA,P127_CORREO_NOTIFICA1,P127_CORREO_NOTIFICA2,P127_TELEFONO1,P127_TELEFONO2,P127_ID_OFICINA'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152765352983926748)
,p_name=>'DAC_SUBMIT_ITEMS_9'
,p_event_sequence=>190
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_FECHA_INI_EXCUSION'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152765822443926748)
,p_event_id=>wwv_flow_api.id(152765352983926748)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'NULL;'
,p_attribute_02=>'P127_NUMERO_PLACA,P127_NOMBRE_ENTIDAD,P127_ID_TIPO_IDENTIFICACION,P127_CEDULA,P127_CONTRATO_ARRENDA,P127_NOMBRE_ARRENDA,P127_ID_TIPO_IDENTIFICA,P127_CEDULA_ARRE,P127_FECHA_INI_EXCUSION,P127_FECHA_FIN_EXCUSION,P127_DESTINO_VIAJE,P127_ID_TIPO_PUESTO,P1'
||'27_TOTAL_PASAJEROS,P127_CODIGO_MONEDA,P127_MONTO_TOTAL_TRANS,P127_IMPUESTO_PAGAR,P127_NOMBRE_CHOFER,P127_NOMBRE_GUIA,P127_CORREO_NOTIFICA1,P127_CORREO_NOTIFICA2,P127_TELEFONO1,P127_TELEFONO2,P127_ID_OFICINA'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152764424822926749)
,p_name=>'DAC_SUBMIT_ITEMS_8'
,p_event_sequence=>200
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_CEDULA_ARRE'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152764907478926748)
,p_event_id=>wwv_flow_api.id(152764424822926749)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'NULL;'
,p_attribute_02=>'P127_NUMERO_PLACA,P127_NOMBRE_ENTIDAD,P127_ID_TIPO_IDENTIFICACION,P127_CEDULA,P127_CONTRATO_ARRENDA,P127_NOMBRE_ARRENDA,P127_ID_TIPO_IDENTIFICA,P127_CEDULA_ARRE,P127_FECHA_INI_EXCUSION,P127_FECHA_FIN_EXCUSION,P127_DESTINO_VIAJE,P127_ID_TIPO_PUESTO,P1'
||'27_TOTAL_PASAJEROS,P127_CODIGO_MONEDA,P127_MONTO_TOTAL_TRANS,P127_IMPUESTO_PAGAR,P127_NOMBRE_CHOFER,P127_NOMBRE_GUIA,P127_CORREO_NOTIFICA1,P127_CORREO_NOTIFICA2,P127_TELEFONO1,P127_TELEFONO2,P127_ID_OFICINA'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152763576120926749)
,p_name=>'DAC_SUBMIT_ITEMS_7'
,p_event_sequence=>210
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_ID_TIPO_IDENTIFICA'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152764073269926749)
,p_event_id=>wwv_flow_api.id(152763576120926749)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'NULL;'
,p_attribute_02=>'P127_NUMERO_PLACA,P127_NOMBRE_ENTIDAD,P127_ID_TIPO_IDENTIFICACION,P127_CEDULA,P127_CONTRATO_ARRENDA,P127_NOMBRE_ARRENDA,P127_ID_TIPO_IDENTIFICA,P127_CEDULA_ARRE,P127_FECHA_INI_EXCUSION,P127_FECHA_FIN_EXCUSION,P127_DESTINO_VIAJE,P127_ID_TIPO_PUESTO,P1'
||'27_TOTAL_PASAJEROS,P127_CODIGO_MONEDA,P127_MONTO_TOTAL_TRANS,P127_IMPUESTO_PAGAR,P127_NOMBRE_CHOFER,P127_NOMBRE_GUIA,P127_CORREO_NOTIFICA1,P127_CORREO_NOTIFICA2,P127_TELEFONO1,P127_TELEFONO2,P127_ID_OFICINA'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152762669352926749)
,p_name=>'DAC_SUBMIT_ITEMS_6'
,p_event_sequence=>220
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_NOMBRE_ARRENDA'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(166179723404266310)
,p_event_id=>wwv_flow_api.id(152762669352926749)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P127_NOMBRE_ARRENDA").val($("#P127_NOMBRE_ARRENDA").val().toUpperCase());'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152763148161926749)
,p_event_id=>wwv_flow_api.id(152762669352926749)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'NULL;'
,p_attribute_02=>'P127_NUMERO_PLACA,P127_NOMBRE_ENTIDAD,P127_ID_TIPO_IDENTIFICACION,P127_CEDULA,P127_CONTRATO_ARRENDA,P127_NOMBRE_ARRENDA,P127_ID_TIPO_IDENTIFICA,P127_CEDULA_ARRE,P127_FECHA_INI_EXCUSION,P127_FECHA_FIN_EXCUSION,P127_DESTINO_VIAJE,P127_ID_TIPO_PUESTO,P1'
||'27_TOTAL_PASAJEROS,P127_CODIGO_MONEDA,P127_MONTO_TOTAL_TRANS,P127_IMPUESTO_PAGAR,P127_NOMBRE_CHOFER,P127_NOMBRE_GUIA,P127_CORREO_NOTIFICA1,P127_CORREO_NOTIFICA2,P127_TELEFONO1,P127_TELEFONO2,P127_ID_OFICINA'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152761713303926751)
,p_name=>'DAC_SUBMIT_ITEMS_5'
,p_event_sequence=>230
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_CONTRATO_ARRENDA'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152762216549926750)
,p_event_id=>wwv_flow_api.id(152761713303926751)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'NULL;'
,p_attribute_02=>'P127_NUMERO_PLACA,P127_NOMBRE_ENTIDAD,P127_ID_TIPO_IDENTIFICACION,P127_CEDULA,P127_CONTRATO_ARRENDA,P127_NOMBRE_ARRENDA,P127_ID_TIPO_IDENTIFICA,P127_CEDULA_ARRE,P127_FECHA_INI_EXCUSION,P127_FECHA_FIN_EXCUSION,P127_DESTINO_VIAJE,P127_ID_TIPO_PUESTO,P1'
||'27_TOTAL_PASAJEROS,P127_CODIGO_MONEDA,P127_MONTO_TOTAL_TRANS,P127_IMPUESTO_PAGAR,P127_NOMBRE_CHOFER,P127_NOMBRE_GUIA,P127_CORREO_NOTIFICA1,P127_CORREO_NOTIFICA2,P127_TELEFONO1,P127_TELEFONO2,P127_ID_OFICINA'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152760818037926751)
,p_name=>'DAC_SUBMIT_ITEMS_4'
,p_event_sequence=>240
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_CEDULA'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152761346809926751)
,p_event_id=>wwv_flow_api.id(152760818037926751)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'NULL;'
,p_attribute_02=>'P127_NUMERO_PLACA,P127_NOMBRE_ENTIDAD,P127_ID_TIPO_IDENTIFICACION,P127_CEDULA,P127_CONTRATO_ARRENDA,P127_NOMBRE_ARRENDA,P127_ID_TIPO_IDENTIFICA,P127_CEDULA_ARRE,P127_FECHA_INI_EXCUSION,P127_FECHA_FIN_EXCUSION,P127_DESTINO_VIAJE,P127_ID_TIPO_PUESTO,P1'
||'27_TOTAL_PASAJEROS,P127_CODIGO_MONEDA,P127_MONTO_TOTAL_TRANS,P127_IMPUESTO_PAGAR,P127_NOMBRE_CHOFER,P127_NOMBRE_GUIA,P127_CORREO_NOTIFICA1,P127_CORREO_NOTIFICA2,P127_TELEFONO1,P127_TELEFONO2,P127_ID_OFICINA'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152759909815926751)
,p_name=>'DAC_SUBMIT_ITEMS_3'
,p_event_sequence=>250
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_ID_TIPO_IDENTIFICACION'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152760451122926751)
,p_event_id=>wwv_flow_api.id(152759909815926751)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'NULL;'
,p_attribute_02=>'P127_NUMERO_PLACA,P127_NOMBRE_ENTIDAD,P127_ID_TIPO_IDENTIFICACION,P127_CEDULA,P127_CONTRATO_ARRENDA,P127_NOMBRE_ARRENDA,P127_ID_TIPO_IDENTIFICA,P127_CEDULA_ARRE,P127_FECHA_INI_EXCUSION,P127_FECHA_FIN_EXCUSION,P127_DESTINO_VIAJE,P127_ID_TIPO_PUESTO,P1'
||'27_TOTAL_PASAJEROS,P127_CODIGO_MONEDA,P127_MONTO_TOTAL_TRANS,P127_IMPUESTO_PAGAR,P127_NOMBRE_CHOFER,P127_NOMBRE_GUIA,P127_CORREO_NOTIFICA1,P127_CORREO_NOTIFICA2,P127_TELEFONO1,P127_TELEFONO2,P127_ID_OFICINA'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152759064331926752)
,p_name=>'DAC_SUBMIT_ITEMS_2'
,p_event_sequence=>260
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_NOMBRE_ENTIDAD'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(166179622212266309)
,p_event_id=>wwv_flow_api.id(152759064331926752)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P127_NOMBRE_ENTIDAD").val($("#P127_NOMBRE_ENTIDAD").val().toUpperCase());'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152759500981926751)
,p_event_id=>wwv_flow_api.id(152759064331926752)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'NULL;'
,p_attribute_02=>'P127_NUMERO_PLACA,P127_NOMBRE_ENTIDAD,P127_ID_TIPO_IDENTIFICACION,P127_CEDULA,P127_CONTRATO_ARRENDA,P127_NOMBRE_ARRENDA,P127_ID_TIPO_IDENTIFICA,P127_CEDULA_ARRE,P127_FECHA_INI_EXCUSION,P127_FECHA_FIN_EXCUSION,P127_DESTINO_VIAJE,P127_ID_TIPO_PUESTO,P1'
||'27_TOTAL_PASAJEROS,P127_CODIGO_MONEDA,P127_MONTO_TOTAL_TRANS,P127_IMPUESTO_PAGAR,P127_NOMBRE_CHOFER,P127_NOMBRE_GUIA,P127_CORREO_NOTIFICA1,P127_CORREO_NOTIFICA2,P127_TELEFONO1,P127_TELEFONO2,P127_ID_OFICINA'
,p_attribute_03=>'P127_NOMBRE_ENTIDAD'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152758127141926753)
,p_name=>'DAC_SUBMIT_ITEMS_1'
,p_event_sequence=>270
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_NUMERO_PLACA'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152758662482926752)
,p_event_id=>wwv_flow_api.id(152758127141926753)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'NULL;',
''))
,p_attribute_02=>'P127_NUMERO_PLACA,P127_NOMBRE_ENTIDAD,P127_ID_TIPO_IDENTIFICACION,P127_CEDULA,P127_CONTRATO_ARRENDA,P127_NOMBRE_ARRENDA,P127_ID_TIPO_IDENTIFICA,P127_CEDULA_ARRE,P127_FECHA_INI_EXCUSION,P127_FECHA_FIN_EXCUSION,P127_DESTINO_VIAJE,P127_ID_TIPO_PUESTO,P1'
||'27_TOTAL_PASAJEROS,P127_CODIGO_MONEDA,P127_MONTO_TOTAL_TRANS,P127_IMPUESTO_PAGAR,P127_NOMBRE_CHOFER,P127_NOMBRE_GUIA,P127_CORREO_NOTIFICA1,P127_CORREO_NOTIFICA2,P127_TELEFONO1,P127_TELEFONO2,P127_ID_OFICINA,P127_CLEAR'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152777839717926743)
,p_name=>'DAC_CLEAR_ITEMS'
,p_event_sequence=>280
,p_condition_element=>'P127_CLEAR'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'S'
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_cond=>'P127_CLEAR'
,p_display_when_cond2=>'S'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152778345297926743)
,p_event_id=>wwv_flow_api.id(152777839717926743)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P127_NUMERO_PLACA,P127_NOMBRE_ENTIDAD,P127_ID_TIPO_IDENTIFICACION,P127_CEDULA,P127_CONTRATO_ARRENDA,P127_NOMBRE_ARRENDA,P127_ID_TIPO_IDENTIFICA,P127_CEDULA_ARRE,P127_FECHA_INI_EXCUSION,P127_FECHA_FIN_EXCUSION,P127_DESTINO_VIAJE,P127_ID_TIPO_PUESTO,P1'
||'27_TOTAL_PASAJEROS,P127_CODIGO_MONEDA,P127_MONTO_TOTAL_TRANS,P127_IMPUESTO_PAGAR,P127_NOMBRE_CHOFER,P127_NOMBRE_GUIA,P127_CORREO_NOTIFICA1,P127_CORREO_NOTIFICA2,P127_TELEFONO1,P127_TELEFONO2,P127_ID_OFICINA,P127_CLEAR'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152778802728926743)
,p_event_id=>wwv_flow_api.id(152777839717926743)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P127_CLEAR := ''N'';'
,p_attribute_02=>'P127_CLEAR'
,p_attribute_03=>'P127_CLEAR'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(167974152921571032)
,p_name=>'DAC_DATOS_CONTRIBUYENTE'
,p_event_sequence=>290
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(167974206524571033)
,p_event_id=>wwv_flow_api.id(167974152921571032)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    vTipoIdent NUMBER;',
'    vCedulaF VARCHAR2(20); ',
'    vCedulaJ VARCHAR2(20);',
'    vTelefono NUMBER;',
'    vCorreo VARCHAR2(50);',
'    ',
'    CURSOR C_DATOS_CONTRIB IS',
'    SELECT ID_TIPO_IDENTIFICACION,CEDULA_JURIDICA,CEDULA_FISICA',
'    FROM   MAESTRO_CONTRIBUYENTE',
'    WHERE  ID_CONTRIBUYENTE = :P127_ID_CONTRIBUYENTE;',
'    ',
'    CURSOR C_TELEFONO IS',
'    SELECT TELEFONO',
'    FROM  TELEFONO_X_MAESTRO_CONTRIBU',
'    WHERE ID_CONTRIBUYENTE = :P127_ID_CONTRIBUYENTE;',
'    ',
'    CURSOR C_CORREO IS',
'    SELECT CORREO_NOTIFICA',
'    FROM  CORREO_NOTIFICACIONES',
'    WHERE ID_CONTRIBUYENTE = :P127_ID_CONTRIBUYENTE',
'    AND   CODIGO_ESTADO = ''AC'';',
'BEGIN',
'    ',
'    OPEN  C_DATOS_CONTRIB;',
'    FETCH C_DATOS_CONTRIB  INTO vTipoIdent,vCedulaJ,vCedulaF;',
'    CLOSE C_DATOS_CONTRIB;',
'    ',
'    OPEN  C_TELEFONO;',
'    FETCH C_TELEFONO INTO vTelefono;',
'    CLOSE C_TELEFONO;',
'    ',
'    OPEN  C_CORREO;',
'    FETCH C_CORREO INTO vCorreo;',
'    CLOSE C_CORREO;',
'    ',
'    ',
'',
':P127_ID_TIPO_IDENTIFICACION := vTipoIdent;',
'    IF vTipoIdent = 1 THEN',
'       :P127_CEDULA := vCedulaJ;',
'    ELSE',
'       :P127_CEDULA := vCedulaF;',
'    END IF;',
':P127_NOMBRE_ENTIDAD := PKG_MAESTRO_CONTRIBUYENTE.F_RETORNA_NOM_CONTRI(PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR_CONTRIB (:P127_ID_CONTRIBUYENTE));',
':P127_TELEFONO1 := vTelefono;',
':P127_CORREO_NOTIFICA1 := vCorreo;',
'END ;'))
,p_attribute_02=>'P127_ID_CONTRIBUYENTE'
,p_attribute_03=>'P127_NOMBRE_ENTIDAD,P127_ID_TIPO_IDENTIFICACION,P127_CEDULA,P127_TELEFONO1,P127_CORREO_NOTIFICA1'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(152757787848926753)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_DATOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    vID NUMBER;',
'    vSecuencia_COT VARCHAR2 (10) := ''DO-03-'';',
'     vSecuencia_TTR VARCHAR2 (10) := ''TSR-'';',
'    vIdContrib NUMBER;',
'    vNombreContrib VARCHAR2 (100);',
'    ',
'    CURSOR C_ID IS',
'    SELECT MAX(ID_DECLARA_CTO)',
'    FROM DECLARA_CHARTER_TERRESTRE_O;',
'    ',
'    CURSOR C_DATOS_CONTRIB IS',
'    SELECT NOMBRE_ENTIDAD--,ID_TIPO_IDENTIFICACION,CEDULA_JURIDICA,CEDULA_FISICA',
'    FROM   MAESTRO_CONTRIBUYENTE',
'    WHERE  ID_CONTRIBUYENTE = vIdContrib;',
'BEGIN',
'    OPEN  C_ID;',
'    FETCH C_ID INTO vID;',
'    CLOSE C_ID;',
'    ',
'    OPEN  C_DATOS_CONTRIB;',
'    FETCH C_DATOS_CONTRIB  INTO vNombreContrib;',
'    CLOSE C_DATOS_CONTRIB;',
'    ',
'    vID := vID +1;',
'    :P127_ID_COT := vSecuencia_COT||vID||''-''||EXTRACT(YEAR FROM sysdate);',
'    :P127_ID_TTR := vSecuencia_TTR||vID||''-''||EXTRACT(YEAR FROM sysdate);',
'    vIdContrib := PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_CONTRIBUYENTE (:GLOBAL_USUARIO);',
'    :P127_ID_CONTRIBUYENTE := vIdContrib;',
'    :P127_CODIGO_TIBUTARIO := PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR_CONTRIB (vIdContrib);',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(152757385981926755)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTA_DECLARACION'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vIdDeclaracion NUMBER;',
'v_retorno_boolean   boolean;',
'v_mensaje_retorno   varchar2(2000);',
'vFecha DATE;',
'vFechaInicio DATE;',
'vFechaFin DATE;',
'vNum_Tramite VARCHAR2(20);',
'BEGIN',
'    vFecha       := TO_DATE(:P127_FECHA,''DD/MM/YYYY'');',
'    vFechaInicio := TO_DATE(:P127_FECHA_INI_EXCUSION,''DD/MM/YYYY'');',
'    vFechaFin    := TO_DATE(:P127_FECHA_FIN_EXCUSION,''DD/MM/YYYY'');',
'    ',
'    IF :GLOBAL_TIPO_CONTRIBUYENTE = 8 THEN',
'        vNum_Tramite := :P127_ID_COT;',
'    ELSE',
'         vNum_Tramite := :P127_ID_TTR;',
'    END IF;',
'    PKG_TRAMITE_COT.INSERTA_DECLARACION_JURADA_COT (vIdDeclaracion,',
'                                    :P127_NOMBRE_ENTIDAD,',
'                                    :P127_ID_TIPO_IDENTIFICACION,',
'                                    :P127_CEDULA,',
'                                    :P127_TELEFONO1,',
'                                    :P127_TELEFONO2,',
'                                    vFecha,',
'                                    :P127_NUMERO_PLACA,',
'                                    :P127_CONTRATO_ARRENDA,',
'                                    :P127_NOMBRE_ARRENDA,',
'                                    :P127_ID_TIPO_IDENTIFICA,',
'                                    :P127_CEDULA_ARRE,',
'                                    vFechaInicio,',
'                                    vFechaFin,',
'                                    :P127_DESTINO_VIAJE,',
'                                    :P127_TOTAL_PASAJEROS,',
'                                    :P127_MONTO_TOTAL_TRANS,',
'                                    :P127_IMPUESTO_PAGAR,',
'                                    :P127_NOMBRE_CHOFER,',
'                                    :P127_NOMBRE_GUIA,',
'                                    ''P'',',
'                                    :P127_CORREO_NOTIFICA1,',
'                                    :P127_CORREO_NOTIFICA2,',
'                                    :P127_ID_OFICINA,',
'                                    :APP_USER,',
'                                    :P127_ID_TIPO_PUESTO,',
'                                    :P127_CODIGO_MONEDA,',
'                                    vNum_Tramite,                ',
'                                          v_mensaje_retorno ,',
'                                          v_retorno_boolean );',
':P127_ID_DECLARA_CTO := vIdDeclaracion;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(152742228181926781)
);
wwv_flow_api.component_end;
end;
/
