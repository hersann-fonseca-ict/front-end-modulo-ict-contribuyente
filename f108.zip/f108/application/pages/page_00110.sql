prompt --application/pages/page_00110
begin
--   Manifest
--     PAGE: 00110
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>108
,p_default_id_offset=>149139848948344617
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>110
,p_user_interface_id=>wwv_flow_api.id(154283420613688838)
,p_name=>'110-Alerta Solicitud'
,p_alias=>'110-ALERTA-SOLICITUD'
,p_page_mode=>'MODAL'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_browser_cache=>'N'
,p_last_updated_by=>'KIMBERLYN.SOLANO'
,p_last_upd_yyyymmddhh24miss=>'20230425100509'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(156942929354980167)
,p_plug_name=>unistr('Solicitud Enviada al departamento de Administraci\00F3n Tributaria')
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--success'
,p_plug_template=>wwv_flow_api.id(154167743630688923)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'&P110_MENSAJE.',
''))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(160758012506823220)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(156942929354980167)
,p_button_name=>'BTN_ACEPTAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Aceptar'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(160758362797823224)
,p_branch_name=>'Go To Page 1'
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(160757842208823218)
,p_name=>'P110_NUM_SOLICITUD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(156942929354980167)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(160759598826823236)
,p_name=>'P110_NOMBRE_ENTIDAD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(156942929354980167)
,p_prompt=>'Nombre Entidad:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_api.id(154259822246688872)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(187062196984387135)
,p_name=>'P110_TIPO_INSCRIPCION'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(156942929354980167)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(192174994849286663)
,p_name=>'P110_MENSAJE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(156942929354980167)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(192175144470286664)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DAC_DATOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'IF :P110_TIPO_INSCRIPCION = ''IR'' THEN',
unistr(':P110_MENSAJE := ''Estimado administrado, su gesti\00F3n de inscripci\00F3n como agente retenedor de impuestos del Instituto Costarricense de Turismo, ha sido enviada a la Administraci\00F3n Tributaria, su solicitud ser\00E1 resuelta en los pr\00F3ximos 10 d\00EDas naturales')
||unistr(' como m\00E1ximo. Cordialmente'';'),
'ELSIF  :P110_TIPO_INSCRIPCION = ''ANRI''THEN',
unistr(':P110_MENSAJE := ''Estimado usuario, su gesti\00F3n de registro, ha sido enviada a la Administraci\00F3n Tributaria, su solicitud ser\00E1 resuelta en los pr\00F3ximos 10 d\00EDas naturales como m\00E1ximo. Cordialmente.'';'),
'ELSIF   :P110_TIPO_INSCRIPCION = ''IVC''THEN',
unistr(':P110_MENSAJE := ''Estimado administrado, su gesti\00F3n de inscripci\00F3n en vuelos ch\00E1rter, ha sido enviada a la Administraci\00F3n Tributaria, su solicitud ser\00E1 resuelta en los pr\00F3ximos 10 d\00EDas naturales como m\00E1ximo. Cordialmente.'';'),
'ELSIF :P110_TIPO_INSCRIPCION = ''U'' THEN',
unistr(':P110_MENSAJE := ''Estimado administrado, su solicitud de activacion de usuario, ha sido enviada a la Administraci\00F3n Tributaria, ser\00E1 resuelta en los pr\00F3ximos 10 d\00EDas naturales como m\00E1ximo. Cordialmente.'';'),
'ELSIF :P110_TIPO_INSCRIPCION = ''COT'' THEN',
unistr(':P110_MENSAJE := ''Estimado administrado, la declaracion jurada ha sido enviada a la Administraci\00F3n Tributaria del ICT, de ser aprobada, en el plazo de 8 horas h\00E1biles se estar\00E1 notificando la nota al Registro Nacional. Cordialmente'';'),
'END IF;',
'END;',
''))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
