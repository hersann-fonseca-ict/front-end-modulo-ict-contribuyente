prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>108
,p_default_id_offset=>149139848948344617
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>2
,p_user_interface_id=>wwv_flow_api.id(154283420613688838)
,p_name=>unistr('Recordar mi contrase\00F1a')
,p_alias=>unistr('RECORDAR-CONTRASE\00D1A')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Recordar Contrase\00F1a')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_browser_cache=>'N'
,p_last_updated_by=>'KIMBERLYN.SOLANO'
,p_last_upd_yyyymmddhh24miss=>'20221121124749'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(154484598890319624)
,p_plug_name=>unistr('Recordar mi contrase\00F1a ')
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(154484793393319626)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(154484598890319624)
,p_button_name=>'BTN_ENVIAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Enviar'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(252730623430454920)
,p_branch_action=>'f?p=&APP_ID.:9999:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(154484697399319625)
,p_name=>'P2_USUARIO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(154484598890319624)
,p_prompt=>'Usuario'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(154259822246688872)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(261069749829918848)
,p_name=>'P2_CONTROLA_ALERTA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(154484598890319624)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(261070144644918851)
,p_name=>'P2_ALERTA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(154484598890319624)
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'style="color:red;"'
,p_field_template=>wwv_flow_api.id(154259822246688872)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(261069849883918849)
,p_name=>'DAC_VAL_USR'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P2_USUARIO'
,p_condition_element=>'P2_USUARIO'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(261069987664918850)
,p_event_id=>wwv_flow_api.id(261069849883918849)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vExiste varchar2(255):= ''N'';',
'BEGIN',
' vExiste := FNC_VALIDA_USR (:P2_USUARIO);',
'',
'--Obtenemos el estado del usuario',
'IF vExiste = ''S'' THEN',
':P2_CONTROLA_ALERTA := ''N'';',
':P2_ALERTA := NULL;',
'ELSE',
':P2_CONTROLA_ALERTA := ''S'';',
':P2_ALERTA := ''Usuario no Existe... por favor validar.'';',
'END IF;',
'END;'))
,p_attribute_02=>'P2_USUARIO,P2_CONTROLA_ALERTA,P2_ALERTA'
,p_attribute_03=>'P2_CONTROLA_ALERTA,P2_ALERTA'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(261070209683918852)
,p_name=>'DAC_MUESTRA_ALERTA'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P2_CONTROLA_ALERTA'
,p_condition_element=>'P2_CONTROLA_ALERTA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'S'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(261070286011918853)
,p_event_id=>wwv_flow_api.id(261070209683918852)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P2_ALERTA'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(261070375543918854)
,p_event_id=>wwv_flow_api.id(261070209683918852)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P2_ALERTA'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(185254163139129753)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_OLVIDO_PWD'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vMensaje_Retorno VARCHAR2(200);',
'vRetorno boolean;',
'BEGIN',
'  PKG_ENVIO_NOTIF_ICT_CONTRIB.NOTIF_OLVIDO_PWD_USR_EXT (:P2_USUARIO, 1,:P2_USUARIO,vMensaje_Retorno,vRetorno);',
' --NULL;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
