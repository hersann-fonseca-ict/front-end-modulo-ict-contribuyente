prompt --application/pages/page_00128
begin
--   Manifest
--     PAGE: 00128
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>108
,p_default_id_offset=>149139848948344617
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>128
,p_user_interface_id=>wwv_flow_api.id(154283420613688838)
,p_name=>'128-Recomendaciones COT'
,p_alias=>'128-RECOMENDACIONES-COT'
,p_step_title=>'Recomendaciones'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'KIMBERLYN.SOLANO'
,p_last_upd_yyyymmddhh24miss=>'20230502125207'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(282942140768487552)
,p_plug_name=>'Principal'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(282943357549487564)
,p_plug_name=>'Titulo Requisitos'
,p_parent_plug_id=>wwv_flow_api.id(282942140768487552)
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_source=>'<center><h3>Requisitos</h3></center>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P128_MOSTRAR_RECOMEN'
,p_plug_display_when_cond2=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(174900324956154111)
,p_name=>'Requisitos'
,p_parent_plug_id=>wwv_flow_api.id(282943357549487564)
,p_template=>wwv_flow_api.id(154198847510688906)
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--textContent:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_region_attributes=>'style="width: 1070px;"'
,p_display_column=>3
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_REQUISITOS_INS,',
'       NOMBRE_REQUISITO',
'  from TIPO_REQUISITOS',
'  where ID_TIPO_CONTRIBUYENTE = :P128_TTR',
'  and  CODIGO_ESTADO = ''AC''',
'  and  TIPO_REQUISTO = ''I''',
'  order by ID_REQUISITOS_INS'))
,p_display_when_condition=>'P128_TTR'
,p_display_when_cond2=>'17'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P128_TTR'
,p_query_row_template=>wwv_flow_api.id(154225098567688891)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(174900644957154114)
,p_query_column_id=>1
,p_column_alias=>'ID_REQUISITOS_INS'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(174900757653154115)
,p_query_column_id=>2
,p_column_alias=>'NOMBRE_REQUISITO'
,p_column_display_sequence=>2
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(282942312465487554)
,p_name=>'Requisitos'
,p_parent_plug_id=>wwv_flow_api.id(282943357549487564)
,p_template=>wwv_flow_api.id(154198847510688906)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--textContent:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_region_attributes=>'style="width: 1070px;"'
,p_display_column=>3
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_REQUISITOS_INS,',
'       NOMBRE_REQUISITO',
'  from TIPO_REQUISITOS',
'  where ID_TIPO_CONTRIBUYENTE = :GLOBAL_TIPO_CONTRIBUYENTE',
'  and  CODIGO_ESTADO = ''AC''',
'  and  TIPO_REQUISTO = ''I''',
'  order by ID_REQUISITOS_INS'))
,p_display_when_condition=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_display_when_cond2=>'8'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(154225098567688891)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(152824762878706424)
,p_query_column_id=>1
,p_column_alias=>'ID_REQUISITOS_INS'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(152825134447706423)
,p_query_column_id=>2
,p_column_alias=>'NOMBRE_REQUISITO'
,p_column_display_sequence=>2
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(282943397355487565)
,p_plug_name=>'Titulo Recomendaciones'
,p_parent_plug_id=>wwv_flow_api.id(282942140768487552)
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_source=>'<center><h3>Recomendaciones</h3></center>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P128_MOSTRAR_RECOMEN'
,p_plug_display_when_cond2=>'S'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(174899834676154106)
,p_name=>'Tipo Recomendacion'
,p_parent_plug_id=>wwv_flow_api.id(282943397355487565)
,p_template=>wwv_flow_api.id(154198847510688906)
,p_display_sequence=>60
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--textContent:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_region_attributes=>'style="width: 1090px;"'
,p_display_column=>3
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_RECOMENDACION,',
'       DESCRIPCION',
'  from TIPO_RECOMENDACION',
'  where ID_TIPO_CONTRIBUYENTE = :P128_TTR',
'  and   CODIGO_ESTADO = ''AC'''))
,p_display_when_condition=>'P128_TTR'
,p_display_when_cond2=>'17'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P128_TTR'
,p_query_row_template=>wwv_flow_api.id(154225098567688891)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(174900150103154109)
,p_query_column_id=>1
,p_column_alias=>'ID_RECOMENDACION'
,p_column_display_sequence=>1
,p_default_sort_column_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(174900224725154110)
,p_query_column_id=>2
,p_column_alias=>'DESCRIPCION'
,p_column_display_sequence=>2
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(283369283762390171)
,p_name=>'Tipo Recomendacion'
,p_parent_plug_id=>wwv_flow_api.id(282943397355487565)
,p_template=>wwv_flow_api.id(154198847510688906)
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--textContent:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_region_attributes=>'style="width: 1090px;"'
,p_display_column=>3
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_RECOMENDACION,',
'       DESCRIPCION',
'  from TIPO_RECOMENDACION',
'  where ID_TIPO_CONTRIBUYENTE = :GLOBAL_TIPO_CONTRIBUYENTE',
'  and   CODIGO_ESTADO = ''AC'''))
,p_display_when_condition=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_display_when_cond2=>'8'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(154225098567688891)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(152826949242706421)
,p_query_column_id=>1
,p_column_alias=>'ID_RECOMENDACION'
,p_column_display_sequence=>1
,p_default_sort_column_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(152827392662706421)
,p_query_column_id=>2
,p_column_alias=>'DESCRIPCION'
,p_column_display_sequence=>2
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(444174071231969280)
,p_plug_name=>'Titulo'
,p_parent_plug_id=>wwv_flow_api.id(282942140768487552)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>'<center><h2>Instituto Costarricense de Turismo</h2></center>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(152825547825706423)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(282942312465487554)
,p_button_name=>'BTN_CONTINUA'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Continuar'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:128:&SESSION.::&DEBUG.::P128_MOSTRAR_RECOMEN:S'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(152828166732706420)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(283369283762390171)
,p_button_name=>'BTN_CONTINUAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Continuar'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:127:&SESSION.::&DEBUG.::P127_CLEAR:S'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(174899989418154107)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(174899834676154106)
,p_button_name=>'BTN_CANCELAR_1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cancelar'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(174900482766154112)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(174900324956154111)
,p_button_name=>'BTN_CONTINUA_1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Continuar'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:128:&SESSION.::&DEBUG.::P128_MOSTRAR_RECOMEN:S'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(152825987270706422)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(282942312465487554)
,p_button_name=>'BTN_CANCELA'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cancelar'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(152827744238706421)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(283369283762390171)
,p_button_name=>'BTN_CANCELAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cancelar'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(174900062936154108)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(174899834676154106)
,p_button_name=>'BTN_CONTINUAR_1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Continuar'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:127:&SESSION.::&DEBUG.::P127_CLEAR:S'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(174900585157154113)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(174900324956154111)
,p_button_name=>'BTN_CANCELA_1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cancelar'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152823793182706431)
,p_name=>'P128_MOSTRAR_RECOMEN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(282942140768487552)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174899784852154105)
,p_name=>'P128_TTR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(282942140768487552)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.component_end;
end;
/
