prompt --application/pages/page_00205
begin
--   Manifest
--     PAGE: 00205
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>108
,p_default_id_offset=>149139848948344617
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>205
,p_user_interface_id=>wwv_flow_api.id(154283420613688838)
,p_name=>'205 - Consulta Intereses Tributarios'
,p_alias=>'205-CONSULTA-INTERESES-TRIBUTARIOS'
,p_step_title=>'205 - Consulta Intereses Tributarios'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js'
,p_page_template_options=>'#DEFAULT#'
,p_browser_cache=>'N'
,p_last_updated_by=>'KIMBERLYN.SOLANO'
,p_last_upd_yyyymmddhh24miss=>'20221121125614'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(185589131088305351)
,p_plug_name=>unistr('C\00E1lculo de Intereses Tributarios')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(192293312429753456)
,p_plug_name=>'Nota'
,p_parent_plug_id=>wwv_flow_api.id(185589131088305351)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<justify><h5><b><i>Esta consulta aplica para pagos tard\00EDos del impuesto, sin previos abonos aplicados '),
unistr('al principal; caso contrario favor comunicarse con esta Administraci\00F3n Tributaria.</i></b></h5></justify>')))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(186089523820837720)
,p_button_sequence=>110
,p_button_plug_id=>wwv_flow_api.id(185589131088305351)
,p_button_name=>'BTN_CALCULO'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Calcular'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(185589151683305352)
,p_name=>'P205_FECHA_PAGO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(185589131088305351)
,p_prompt=>'Fecha Pago:'
,p_format_mask=>'DD/MM/YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(185589280633305353)
,p_name=>'P205_TIPO_IMPUESTO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(185589131088305351)
,p_prompt=>'Tipo Impuesto:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_IMPUESTO'
,p_lov=>'.'||wwv_flow_api.id(161518516720599275)||'.'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(185751774346092124)
,p_name=>'P205_TIPO_DOCUMENTO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(185589131088305351)
,p_prompt=>'Tipo Documento:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION, ID_TIPO_DOCUMENTO       ',
'FROM TIPOS_DOCUMENTOS_CXC@consulta_ictx ',
'WHERE ID_TIPO_IMPUESTO = :P205_TIPO_IMPUESTO AND',
'      TIPO_FUENTE = 3 AND',
'      INDICADOR_DECLARACION = 1;'))
,p_lov_cascade_parent_items=>'P205_TIPO_IMPUESTO'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(185751893999092125)
,p_name=>'P205_PERIODO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(185589131088305351)
,p_prompt=>'Periodo:'
,p_placeholder=>'MM/AAAA'
,p_format_mask=>'MM/YYYY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(185752041522092126)
,p_name=>'P205_QUINCENA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(185589131088305351)
,p_prompt=>'Quincena:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Primera;1,Segunda;2,Mensual;0'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(185752346448092129)
,p_name=>'P205_MONTO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(185589131088305351)
,p_prompt=>'Monto:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'data-type="currency"'
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(185752445493092130)
,p_name=>'P205_INTERESES_TRIB'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(185589131088305351)
,p_prompt=>'Intereses Tributarios:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'data-type="currency"'
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(185752522199092131)
,p_name=>'P205_DEUDA_TOTAL'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(185589131088305351)
,p_prompt=>'Deuda Total:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'data-type="currency"'
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(186089809893837723)
,p_name=>'P205_TIPO_MONEDA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(185589131088305351)
,p_prompt=>'Tipo Moneda:'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:Colones;1,Dolares;2'
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'2'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(186089896062837724)
,p_name=>'P205_MENSAJE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(185589131088305351)
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(186089641302837721)
,p_name=>'DAC_CALCULO'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(186089523820837720)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186089727099837722)
,p_event_id=>wwv_flow_api.id(186089641302837721)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'V_INTERESES NUMBER;',
'BEGIN',
':P205_MENSAJE := null;',
'IF :P205_TIPO_MONEDA = 1 THEN',
'V_INTERESES := PKG_CTASCOB.F_INT_PROYECTADOS@CONSULTA_ICTX(TO_DATE(:P205_PERIODO,''MM/DD/RRRR''),',
'                                                           :P205_QUINCENA,',
'                                                           :P205_TIPO_IMPUESTO,',
'											               :P205_TIPO_DOCUMENTO, ',
'											               TO_DATE(:P205_FECHA_PAGO,''DD/MM/RRRR''),													                                            ',
'                                                           REPLACE( :P205_MONTO, '','', '''' )); ',
'      IF v_intereses = 0 THEN	',
'           :P205_INTERESES_TRIB := V_INTERESES; ',
'           :P205_DEUDA_TOTAL := REPLACE( :P205_MONTO, '','', '''' ) + V_INTERESES;',
'	  END IF; ',
'      ',
'      IF V_INTERESES < 0.50 THEN',
unistr('	     :P205_MENSAJE := (''Intereses Generados: \00A2''||ltrim(rtrim(to_char(v_intereses,''99.99'')))||'),
'	                   '' .Por politica de Administracion Tributaria los''|| ',
unistr('	                   '' montos menores a \00A20.50, se redondean a 0.'');'),
'	          v_intereses := 0;',
'      ELSE',
'         SELECT round(v_intereses,0.5) INTO V_INTERESES FROM dual;',
'  		:P205_INTERESES_TRIB := V_INTERESES; ',
'',
'        :P205_MENSAJE := null;',
'END IF;	',
'ELSIF :P205_TIPO_MONEDA = 2 THEN --dolares manual	',
'	    V_INTERESES := PKG_CTASCOB.F_INT_PROYECTADOS@CONSULTA_ICTX(TO_DATE(:P205_PERIODO,''MM/DD/RRRR''),',
'                                                     :P205_QUINCENA,',
'                                                     :P205_TIPO_IMPUESTO,',
'											         :P205_TIPO_DOCUMENTO, ',
'											          TO_DATE(:P205_FECHA_PAGO,''DD/MM/RRRR''),													                                            ',
'                                                     REPLACE( :P205_MONTO, '','', '''' )); ',
'			     ',
'	   IF V_INTERESES = 0 THEN	',
'           :P205_INTERESES_TRIB := V_INTERESES;',
'           :P205_DEUDA_TOTAL :=  REPLACE( :P205_MONTO, '','', '''' ) + V_INTERESES;',
'	   END IF;',
'',
'	  IF v_intereses < 0.50 THEN',
'	    :P205_MENSAJE := (''Intereses Generados: $''||ltrim(rtrim(to_char(v_intereses,''99.99'')))||',
'	                  '' .Por politica de Administracion Tributaria los''|| ',
'	                  '' montos menores a $0.50, se redondean a 0.'');',
'	          v_intereses := 0;',
'        END IF;  ',
'   	   ',
'  	  	   SELECT round(v_intereses,0.5) INTO v_intereses FROM dual;',
'',
'		  :P205_INTERESES_TRIB := V_INTERESES;',
'END IF;',
'	:P205_DEUDA_TOTAL := REPLACE( :P205_MONTO, '','', '''' ) + V_INTERESES;',
'END;'))
,p_attribute_02=>'P205_FECHA_PAGO,P205_TIPO_IMPUESTO,P205_TIPO_DOCUMENTO,P205_PERIODO,P205_QUINCENA,P205_MONTO,P205_MENSAJE,P205_TIPO_MONEDA'
,p_attribute_03=>'P205_INTERESES_TRIB,P205_DEUDA_TOTAL,P205_MENSAJE'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186201401129847825)
,p_event_id=>wwv_flow_api.id(186089641302837721)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_FOCUS'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P205_INTERESES_TRIB'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186201498376847826)
,p_event_id=>wwv_flow_api.id(186089641302837721)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P205_DEUDA_TOTAL,P205_INTERESES_TRIB'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186201619132847827)
,p_event_id=>wwv_flow_api.id(186089641302837721)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_FOCUS'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P205_DEUDA_TOTAL'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186201728095847828)
,p_event_id=>wwv_flow_api.id(186089641302837721)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P205_DEUDA_TOTAL'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186201764555847829)
,p_event_id=>wwv_flow_api.id(186089641302837721)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_FOCUS'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P205_FECHA_PAGO'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(186093504022837760)
,p_name=>'DAC_FORMATO_MONTO'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P205_MONTO'
,p_bind_type=>'bind'
,p_bind_event_type=>'keypress'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186093602504837761)
,p_event_id=>wwv_flow_api.id(186093504022837760)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Jquery Dependency',
'',
'$("input[data-type=''currency'']").on({',
'    keyup: function() {',
'      formatCurrency($(this));',
'    },',
'    blur: function() { ',
'      formatCurrency($(this), "blur");',
'    }',
'});',
'',
'',
'function formatNumber(n) {',
unistr('  // formato del n\00FAmero de 1000000 a 1,234,567'),
'  return n.replace(/\D/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")',
'}',
'',
'',
'function formatCurrency(input, blur) {',
'  var input_val = input.val();',
'',
'  if (input_val === "") { return; }',
'',
'  var original_len = input_val.length;',
'',
'  var caret_pos = input.prop("selectionStart");',
' ',
'  if (input_val.indexOf(".") >= 0) {',
'',
'    var decimal_pos = input_val.indexOf(".");',
'',
'    var left_side = input_val.substring(0, decimal_pos);',
'    var right_side = input_val.substring(decimal_pos);',
'',
unistr('    // A\00F1ade comas a la derecha de los n\00FAmeros'),
'    left_side = formatNumber(left_side);',
'',
'    // Valida el valor del lado derecho',
'    right_side = formatNumber(right_side);',
'    ',
unistr('    // Indicamos que los decimales sean 2 n\00FAmeros siempre'),
'    if (blur === "blur") {',
'      right_side += "00";',
'    }',
'    ',
unistr('    // Indicamos el l\00EDmite de decimales'),
'    right_side = right_side.substring(0, 2);',
'    input_val = left_side + "." + right_side;',
'',
'  } else {',
unistr('    // removemos todos los valores que no son n\00FAmeros'),
'    input_val = formatNumber(input_val);',
'    input_val = input_val;',
'    ',
'    // indicamos la cantidad de decimales',
'    if (blur === "blur") {',
'      input_val += ".00";',
'    }',
'  }',
'  ',
unistr('  // env\00EDamos la actualizaci\00F3n al campo'),
'  input.val(input_val);',
'',
unistr('  // Lo colocamos en la posici\00F3n izquierda del campo'),
'  var updated_len = input_val.length;',
'  caret_pos = updated_len - original_len + caret_pos;',
'  input[0].setSelectionRange(caret_pos, caret_pos);',
'}'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(186093693468837762)
,p_name=>'DAC_FORMATO_INTERESES'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P205_INTERESES_TRIB'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186093768222837763)
,p_event_id=>wwv_flow_api.id(186093693468837762)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Jquery Dependency',
'',
'$("input[data-type=''currency'']").on({',
'    keyup: function() {',
'      formatCurrency($(this));',
'    },',
'    blur: function() { ',
'      formatCurrency($(this), "blur");',
'    }',
'});',
'',
'',
'function formatNumber(n) {',
unistr('  // formato del n\00FAmero de 1000000 a 1,234,567'),
'  return n.replace(/\D/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")',
'}',
'',
'',
'function formatCurrency(input, blur) {',
'  var input_val = input.val();',
'',
'  if (input_val === "") { return; }',
'',
'  var original_len = input_val.length;',
'',
'  var caret_pos = input.prop("selectionStart");',
' ',
'  if (input_val.indexOf(".") >= 0) {',
'',
'    var decimal_pos = input_val.indexOf(".");',
'',
'    var left_side = input_val.substring(0, decimal_pos);',
'    var right_side = input_val.substring(decimal_pos);',
'',
unistr('    // A\00F1ade comas a la derecha de los n\00FAmeros'),
'    left_side = formatNumber(left_side);',
'',
'    // Valida el valor del lado derecho',
'    right_side = formatNumber(right_side);',
'    ',
unistr('    // Indicamos que los decimales sean 2 n\00FAmeros siempre'),
'    if (blur === "blur") {',
'      right_side += "00";',
'    }',
'    ',
unistr('    // Indicamos el l\00EDmite de decimales'),
'    right_side = right_side.substring(0, 2);',
'    input_val = left_side + "." + right_side;',
'',
'  } else {',
unistr('    // removemos todos los valores que no son n\00FAmeros'),
'    input_val = formatNumber(input_val);',
'    input_val = input_val;',
'    ',
'    // indicamos la cantidad de decimales',
'    if (blur === "blur") {',
'      input_val += ".00";',
'    }',
'  }',
'  ',
unistr('  // env\00EDamos la actualizaci\00F3n al campo'),
'  input.val(input_val);',
'',
unistr('  // Lo colocamos en la posici\00F3n izquierda del campo'),
'  var updated_len = input_val.length;',
'  caret_pos = updated_len - original_len + caret_pos;',
'  input[0].setSelectionRange(caret_pos, caret_pos);',
'}'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(186093869468837764)
,p_name=>'DAC_FORMATO_DEUDA'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P205_DEUDA_TOTAL'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186094015400837765)
,p_event_id=>wwv_flow_api.id(186093869468837764)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Jquery Dependency',
'',
'$("input[data-type=''currency'']").on({',
'    keyup: function() {',
'      formatCurrency($(this));',
'    },',
'    blur: function() { ',
'      formatCurrency($(this), "blur");',
'    }',
'});',
'',
'',
'function formatNumber(n) {',
unistr('  // formato del n\00FAmero de 1000000 a 1,234,567'),
'  return n.replace(/\D/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")',
'}',
'',
'',
'function formatCurrency(input, blur) {',
'  var input_val = input.val();',
'',
'  if (input_val === "") { return; }',
'',
'  var original_len = input_val.length;',
'',
'  var caret_pos = input.prop("selectionStart");',
' ',
'  if (input_val.indexOf(".") >= 0) {',
'',
'    var decimal_pos = input_val.indexOf(".");',
'',
'    var left_side = input_val.substring(0, decimal_pos);',
'    var right_side = input_val.substring(decimal_pos);',
'',
unistr('    // A\00F1ade comas a la derecha de los n\00FAmeros'),
'    left_side = formatNumber(left_side);',
'',
'    // Valida el valor del lado derecho',
'    right_side = formatNumber(right_side);',
'    ',
unistr('    // Indicamos que los decimales sean 2 n\00FAmeros siempre'),
'    if (blur === "blur") {',
'      right_side += "00";',
'    }',
'    ',
unistr('    // Indicamos el l\00EDmite de decimales'),
'    right_side = right_side.substring(0, 2);',
'    input_val = left_side + "." + right_side;',
'',
'  } else {',
unistr('    // removemos todos los valores que no son n\00FAmeros'),
'    input_val = formatNumber(input_val);',
'    input_val = input_val;',
'    ',
'    // indicamos la cantidad de decimales',
'    if (blur === "blur") {',
'      input_val += ".00";',
'    }',
'  }',
'  ',
unistr('  // env\00EDamos la actualizaci\00F3n al campo'),
'  input.val(input_val);',
'',
unistr('  // Lo colocamos en la posici\00F3n izquierda del campo'),
'  var updated_len = input_val.length;',
'  caret_pos = updated_len - original_len + caret_pos;',
'  input[0].setSelectionRange(caret_pos, caret_pos);',
'}'))
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(186094142642837766)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_DATOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
':P205_INTERESES_TRIB := 0;',
':P205_DEUDA_TOTAL := 0;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
