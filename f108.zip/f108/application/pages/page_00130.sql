prompt --application/pages/page_00130
begin
--   Manifest
--     PAGE: 00130
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>108
,p_default_id_offset=>149139848948344617
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>130
,p_user_interface_id=>wwv_flow_api.id(154283420613688838)
,p_name=>unistr('130-Genera PDF Declaraci\00F3n Jurada COT')
,p_alias=>unistr('130-GENERA-PDF-DECLARACI\00D3N-JURADA-COT')
,p_page_mode=>'NON_MODAL'
,p_step_title=>unistr('Genera PDF Declaraci\00F3n Jurada COT')
,p_reload_on_submit=>'A'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'JORGE.ROJAS'
,p_last_upd_yyyymmddhh24miss=>'20240808151109'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(413577777941515825)
,p_plug_name=>'Principal'
,p_region_template_options=>'#DEFAULT#:i-h640:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(167974328025571034)
,p_name=>'P130_ID_DECLARA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(413577777941515825)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152868162475670808)
,p_name=>'DAC_SUBMIT_PAGE'
,p_event_sequence=>110
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152868628344670805)
,p_event_id=>wwv_flow_api.id(152868162475670808)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(167974475465571035)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_DATOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    vID NUMBER;',
'    ',
'    CURSOR C_ID IS',
'    SELECT MAX(ID_DECLARA_CTO)',
'    FROM DECLARA_CHARTER_TERRESTRE_O;',
'   ',
'BEGIN',
'    OPEN  C_ID;',
'    FETCH C_ID INTO vID;',
'    CLOSE C_ID;',
'    ',
'    vID := vID +1;',
'    :P130_ID_DECLARA := vID;',
'END ;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(152867304909670811)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_DECLA_PDF_CONCONTRATO_COT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'CURSOR crReport IS',
'SELECT JRD_NAME',
'FROM JRXML_REPORT_DEFINITIONS',
'WHERE JRD_ID = :P127_ID_REPORTE;',
'',
'vcName VARCHAR2(1000);',
'rParam PK_JRXML2PDF_REPGEN.tParameter;',
'lParams PK_JRXML2PDF_REPGEN.tParamlist;',
'v_periodo date;',
'bl BLOB;',
'BEGIN',
'',
'OPEN crReport;',
'FETCH crReport Into vcName;',
'CLOSE crReport;',
'',
'rParam.vcName := ''pID_DECLARA_CTO'';',
'rParam.vcValue := :P130_ID_DECLARA;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pNUMERO_PLACA'';',
'rParam.vcValue := :P127_NUMERO_PLACA;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pNOMBRE_ENTIDAD'';',
'rParam.vcValue := :P127_NOMBRE_ENTIDAD;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pID_TIPO_IDENTIFICACION'';',
'rParam.vcValue := :P127_ID_TIPO_IDENTIFICACION;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pCEDULA'';',
'rParam.vcValue := :P127_CEDULA;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pNOMBRE_ARRENDA'';',
'rParam.vcValue := :P127_NOMBRE_ARRENDA;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pID_TIPO_IDENTIFICA'';',
'rParam.vcValue := :P127_ID_TIPO_IDENTIFICA;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pCEDULA_ARRE'';',
'rParam.vcValue := :P127_CEDULA_ARRE;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pFECHA_INI_EXCUSION'';',
'rParam.vcValue := :P127_FECHA_INI_EXCUSION;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pFECHA_FIN_EXCUSION'';',
'rParam.vcValue := :P127_FECHA_FIN_EXCUSION;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pDESTINO_VIAJE'';',
'rParam.vcValue := :P127_DESTINO_VIAJE;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pID_TIPO_PUESTO'';',
'rParam.vcValue := :P127_ID_TIPO_PUESTO;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pTOTAL_PASAJEROS'';',
'rParam.vcValue := :P127_TOTAL_PASAJEROS;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pCODIGO_MONEDA'';',
'rParam.vcValue := :P127_CODIGO_MONEDA;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pMONTO_TOTAL_TRANS'';',
'rParam.vcValue := :P127_MONTO_TOTAL_TRANS;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pIMPUESTO_PAGAR'';',
'rParam.vcValue := :P127_IMPUESTO_PAGAR;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pNOMBRE_CHOFER'';',
'rParam.vcValue := :P127_NOMBRE_CHOFER;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pNOMBRE_GUIA'';',
'rParam.vcValue := :P127_NOMBRE_GUIA;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pCORREO_NOTIFICA1'';',
'rParam.vcValue := :P127_CORREO_NOTIFICA1;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pCORREO_NOTIFICA2'';',
'rParam.vcValue := :P127_CORREO_NOTIFICA2;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pTELEFONO1'';',
'rParam.vcValue := :P127_TELEFONO1;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pTELEFONO2'';',
'rParam.vcValue := :P127_TELEFONO2;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pID_OFICINA'';',
'rParam.vcValue := :P127_ID_OFICINA;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pUsuario'';',
'rParam.vcValue := :APP_USER;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'bl := PK_JRXML2PDF_REPGEN.FK_RUN(i_vcName=>vcName,i_lParams=>lParams);',
'COMMIT;',
'PK_JRXML2PDF_REPGEN.PR_SHOW_REPORT(bl);',
'APEX_APPLICATION.STOP_APEX_ENGINE;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P127_ID_REPORTE'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'1220'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(152867746291670809)
,p_process_sequence=>20
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_DECLA_PDF_SINCONTRATO_COT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'CURSOR crReport IS',
'SELECT JRD_NAME',
'FROM JRXML_REPORT_DEFINITIONS',
'WHERE JRD_ID = :P127_ID_REPORTE;',
'',
'vcName VARCHAR2(1000);',
'rParam PK_JRXML2PDF_REPGEN.tParameter;',
'lParams PK_JRXML2PDF_REPGEN.tParamlist;',
'v_periodo date;',
'bl BLOB;',
'BEGIN',
'',
'OPEN crReport;',
'FETCH crReport Into vcName;',
'CLOSE crReport;',
'',
'rParam.vcName := ''pID_DECLARA_CTO'';',
'rParam.vcValue := :P130_ID_DECLARA;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pNUMERO_PLACA'';',
'rParam.vcValue := :P127_NUMERO_PLACA;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pNOMBRE_ENTIDAD'';',
'rParam.vcValue := :P127_NOMBRE_ENTIDAD;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pID_TIPO_IDENTIFICACION'';',
'rParam.vcValue := :P127_ID_TIPO_IDENTIFICACION;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pCEDULA'';',
'rParam.vcValue := :P127_CEDULA;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'/*rParam.vcName := ''pNOMBRE_ARRENDA'';',
'rParam.vcValue := :P130_NOMBRE_ARRENDA;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pID_TIPO_IDENTIFICA'';',
'rParam.vcValue := :P130_ID_TIPO_IDENTIFICA;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pCEDULA_ARRE'';',
'rParam.vcValue := :P130_CEDULA_ARRE;',
'lParams(lParams.COUNT+1):=rParam;*/',
'',
'rParam.vcName := ''pFECHA_INI_EXCUSION'';',
'rParam.vcValue := :P127_FECHA_INI_EXCUSION;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pFECHA_FIN_EXCUSION'';',
'rParam.vcValue := :P127_FECHA_FIN_EXCUSION;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pDESTINO_VIAJE'';',
'rParam.vcValue := :P127_DESTINO_VIAJE;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pID_TIPO_PUESTO'';',
'rParam.vcValue := :P127_ID_TIPO_PUESTO;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pTOTAL_PASAJEROS'';',
'rParam.vcValue := :P127_TOTAL_PASAJEROS;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pCODIGO_MONEDA'';',
'rParam.vcValue := :P127_CODIGO_MONEDA;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pMONTO_TOTAL_TRANS'';',
'rParam.vcValue := :P127_MONTO_TOTAL_TRANS;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pIMPUESTO_PAGAR'';',
'rParam.vcValue := :P127_IMPUESTO_PAGAR;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pNOMBRE_CHOFER'';',
'rParam.vcValue := :P127_NOMBRE_CHOFER;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pNOMBRE_GUIA'';',
'rParam.vcValue := :P127_NOMBRE_GUIA;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pCORREO_NOTIFICA1'';',
'rParam.vcValue := :P127_CORREO_NOTIFICA1;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pCORREO_NOTIFICA2'';',
'rParam.vcValue := :P127_CORREO_NOTIFICA2;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pTELEFONO1'';',
'rParam.vcValue := :P127_TELEFONO1;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pTELEFONO2'';',
'rParam.vcValue := :P127_TELEFONO2;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pID_OFICINA'';',
'rParam.vcValue := :P127_ID_OFICINA;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pUsuario'';',
'rParam.vcValue := :APP_USER;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'bl := PK_JRXML2PDF_REPGEN.FK_RUN(i_vcName=>vcName,i_lParams=>lParams);',
'COMMIT;',
'PK_JRXML2PDF_REPGEN.PR_SHOW_REPORT(bl);',
'APEX_APPLICATION.STOP_APEX_ENGINE;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P127_ID_REPORTE'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'1240'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(167971321073571004)
,p_process_sequence=>40
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_DECLA_PDF_CONCONTRATO_TTR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'CURSOR crReport IS',
'SELECT JRD_NAME',
'FROM JRXML_REPORT_DEFINITIONS',
'WHERE JRD_ID = :P127_ID_REPORTE;',
'',
'vcName VARCHAR2(1000);',
'rParam PK_JRXML2PDF_REPGEN.tParameter;',
'lParams PK_JRXML2PDF_REPGEN.tParamlist;',
'v_periodo date;',
'bl BLOB;',
'BEGIN',
'',
'OPEN crReport;',
'FETCH crReport Into vcName;',
'CLOSE crReport;',
'',
'rParam.vcName := ''pID_DECLARA_CTO'';',
'rParam.vcValue := :P130_ID_DECLARA;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pNUMERO_PLACA'';',
'rParam.vcValue := :P127_NUMERO_PLACA;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pNOMBRE_ENTIDAD'';',
'rParam.vcValue := :P127_NOMBRE_ENTIDAD;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pID_TIPO_IDENTIFICACION'';',
'rParam.vcValue := :P127_ID_TIPO_IDENTIFICACION;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pCEDULA'';',
'rParam.vcValue := :P127_CEDULA;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pNOMBRE_ARRENDA'';',
'rParam.vcValue := :P127_NOMBRE_ARRENDA;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pID_TIPO_IDENTIFICA'';',
'rParam.vcValue := :P127_ID_TIPO_IDENTIFICA;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pCEDULA_ARRE'';',
'rParam.vcValue := :P127_CEDULA_ARRE;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pFECHA_INI_EXCUSION'';',
'rParam.vcValue := :P127_FECHA_INI_EXCUSION;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pFECHA_FIN_EXCUSION'';',
'rParam.vcValue := :P127_FECHA_FIN_EXCUSION;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pDESTINO_VIAJE'';',
'rParam.vcValue := :P127_DESTINO_VIAJE;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pID_TIPO_PUESTO'';',
'rParam.vcValue := :P127_ID_TIPO_PUESTO;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pTOTAL_PASAJEROS'';',
'rParam.vcValue := :P127_TOTAL_PASAJEROS;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pCODIGO_MONEDA'';',
'rParam.vcValue := :P127_CODIGO_MONEDA;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pMONTO_TOTAL_TRANS'';',
'rParam.vcValue := :P127_MONTO_TOTAL_TRANS;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pIMPUESTO_PAGAR'';',
'rParam.vcValue := :P127_IMPUESTO_PAGAR;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pNOMBRE_CHOFER'';',
'rParam.vcValue := :P127_NOMBRE_CHOFER;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pNOMBRE_GUIA'';',
'rParam.vcValue := :P127_NOMBRE_GUIA;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pCORREO_NOTIFICA1'';',
'rParam.vcValue := :P127_CORREO_NOTIFICA1;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pCORREO_NOTIFICA2'';',
'rParam.vcValue := :P127_CORREO_NOTIFICA2;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pTELEFONO1'';',
'rParam.vcValue := :P127_TELEFONO1;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pTELEFONO2'';',
'rParam.vcValue := :P127_TELEFONO2;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pID_OFICINA'';',
'rParam.vcValue := :P127_ID_OFICINA;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pUsuario'';',
'rParam.vcValue := :APP_USER;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'bl := PK_JRXML2PDF_REPGEN.FK_RUN(i_vcName=>vcName,i_lParams=>lParams);',
'COMMIT;',
'PK_JRXML2PDF_REPGEN.PR_SHOW_REPORT(bl);',
'APEX_APPLICATION.STOP_APEX_ENGINE;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P127_ID_REPORTE'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'1282'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(167971706563571008)
,p_process_sequence=>50
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_DECLA_PDF_SINCONTRATO_TTR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'CURSOR crReport IS',
'SELECT JRD_NAME',
'FROM JRXML_REPORT_DEFINITIONS',
'WHERE JRD_ID = :P127_ID_REPORTE;',
'',
'vcName VARCHAR2(1000);',
'rParam PK_JRXML2PDF_REPGEN.tParameter;',
'lParams PK_JRXML2PDF_REPGEN.tParamlist;',
'v_periodo date;',
'bl BLOB;',
'BEGIN',
'',
'OPEN crReport;',
'FETCH crReport Into vcName;',
'CLOSE crReport;',
'',
'rParam.vcName := ''pID_DECLARA_CTO'';',
'rParam.vcValue := :P130_ID_DECLARA;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pNUMERO_PLACA'';',
'rParam.vcValue := :P127_NUMERO_PLACA;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pNOMBRE_ENTIDAD'';',
'rParam.vcValue := :P127_NOMBRE_ENTIDAD;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pID_TIPO_IDENTIFICACION'';',
'rParam.vcValue := :P127_ID_TIPO_IDENTIFICACION;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pCEDULA'';',
'rParam.vcValue := :P127_CEDULA;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pCORREO_NOTIFICA1'';',
'rParam.vcValue := :P127_CORREO_NOTIFICA1;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pCORREO_NOTIFICA2'';',
'rParam.vcValue := :P127_CORREO_NOTIFICA2;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pTELEFONO1'';',
'rParam.vcValue := :P127_TELEFONO1;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pTELEFONO2'';',
'rParam.vcValue := :P127_TELEFONO2;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pID_OFICINA'';',
'rParam.vcValue := :P127_ID_OFICINA;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'rParam.vcName := ''pUsuario'';',
'rParam.vcValue := :APP_USER;',
'lParams(lParams.COUNT+1):=rParam;',
'',
'bl := PK_JRXML2PDF_REPGEN.FK_RUN(i_vcName=>vcName,i_lParams=>lParams);',
'COMMIT;',
'PK_JRXML2PDF_REPGEN.PR_SHOW_REPORT(bl);',
'APEX_APPLICATION.STOP_APEX_ENGINE;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P127_ID_REPORTE'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'1302'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(225650643966525109)
,p_process_sequence=>60
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'CURSOR crReport IS',
'SELECT JRD_NAME',
'FROM JRXML_REPORT_DEFINITIONS',
'WHERE JRD_ID = 1366;',
' ',
'vcName VARCHAR2(1000);',
'rParam PK_JRXML2PDF_REPGEN.tParameter;',
'lParams PK_JRXML2PDF_REPGEN.tParamlist;',
'v_periodo date;',
'bl BLOB;',
'BEGIN',
' ',
'OPEN crReport;',
'FETCH crReport Into vcName;',
'CLOSE crReport;',
' ',
'rParam.vcName := ''p_id_declara'';',
'rParam.vcValue := 28;',
'lParams(lParams.COUNT+1):=rParam;',
' ',
'bl := PK_JRXML2PDF_REPGEN.FK_RUN(i_vcName=>vcName,i_lParams=>lParams);',
'',
'COMMIT;',
'PK_JRXML2PDF_REPGEN.PR_SHOW_REPORT(bl);',
'APEX_APPLICATION.STOP_APEX_ENGINE;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
