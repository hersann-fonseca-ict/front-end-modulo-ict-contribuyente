prompt --application/pages/page_00108
begin
--   Manifest
--     PAGE: 00108
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>108
,p_default_id_offset=>149139848948344617
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>108
,p_user_interface_id=>wwv_flow_api.id(154283420613688838)
,p_name=>unistr('VI. Autorizaci\00F3n Uso Firma Digital')
,p_alias=>unistr('VI-AUTORIZACI\00D3N-USO-FIRMA-DIGITAL')
,p_step_title=>unistr('Autorizaci\00F3n Uso Firma Digital')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_browser_cache=>'N'
,p_last_updated_by=>'KIMBERLYN.SOLANO'
,p_last_upd_yyyymmddhh24miss=>'20230216161406'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(154571795684707948)
,p_plug_name=>unistr('VI. Autorizaci\00F3n Uso Firma Digital')
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(154209205076688900)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(154546934337707973)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(154238115289688884)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(154571938403707948)
,p_plug_name=>unistr('VI. Autorizaci\00F3n Uso Firma Digital')
,p_parent_plug_id=>wwv_flow_api.id(154571795684707948)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(154171394141688918)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(155625412845298253)
,p_plug_name=>unistr('Autorizaci\00F3n Uso Firma Digital en declaraciones juradas')
,p_parent_plug_id=>wwv_flow_api.id(154571938403707948)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(252734568962454960)
,p_plug_name=>'Apoderado1'
,p_parent_plug_id=>wwv_flow_api.id(155625412845298253)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(252734690663454961)
,p_plug_name=>'Apoderado2'
,p_parent_plug_id=>wwv_flow_api.id(155625412845298253)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(252734821763454962)
,p_plug_name=>'Apoderado3'
,p_parent_plug_id=>wwv_flow_api.id(155625412845298253)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(155625466715298254)
,p_plug_name=>'Autorizo a terceras personas'
,p_parent_plug_id=>wwv_flow_api.id(154571938403707948)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(154573770304707947)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(154571795684707948)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Regresar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-angle-double-left'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(154573875593707947)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(154571795684707948)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Siguiente'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-angle-double-right'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(154573606290707947)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(154571795684707948)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(154575330717707946)
,p_branch_name=>'Go To Page 109'
,p_branch_action=>'f?p=&APP_ID.:109:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(154573875593707947)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(154574634529707947)
,p_branch_action=>'f?p=&APP_ID.:107:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(154573770304707947)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(154573255317707947)
,p_name=>'P108_NOM_APODERADO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(252734568962454960)
,p_prompt=>'Nombre Completo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155624375384298243)
,p_name=>'P108_CEDULA_APRODERADO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(252734568962454960)
,p_prompt=>unistr('N\00B0 C\00E9dula/ID:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333).')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155624495192298244)
,p_name=>'P108_IMPUESTO_FIRMAR'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(252734568962454960)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155624602470298245)
,p_name=>'P108_EMAIL_APODERADO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(252734568962454960)
,p_prompt=>unistr('Correo electr\00F3nico:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155624694618298246)
,p_name=>'P108_NOM_APODERADO_1'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(252734690663454961)
,p_prompt=>'Nombre Completo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155624800850298247)
,p_name=>'P108_CEDULA_APRODERADO_1'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(252734690663454961)
,p_prompt=>unistr('N\00B0 C\00E9dula/ID:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155624868684298248)
,p_name=>'P108_EMAIL_APODERADO_1'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(252734690663454961)
,p_prompt=>unistr('Correo electr\00F3nico:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155625043862298249)
,p_name=>'P108_NOM_APODERADO_2'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(252734821763454962)
,p_prompt=>'Nombre Completo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155625111176298250)
,p_name=>'P108_CEDULA_APRODERADO_2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(252734821763454962)
,p_prompt=>unistr('N\00B0 C\00E9dula/ID:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155625211509298251)
,p_name=>'P108_EMAIL_APODERADO_2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(252734821763454962)
,p_prompt=>unistr('Correo electr\00F3nico:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155625647400298255)
,p_name=>'P108_FIRMA_APODERADO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(252734568962454960)
,p_prompt=>unistr('Firma solo apoderado (s) o Due\00F1o:')
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:Si;S'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155625924999298258)
,p_name=>'P108_TERCEROS'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_api.id(252734821763454962)
,p_prompt=>'Autorizo a terceras personas y adjunto el poder legal correspondiente'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:Si;S'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155626330442298262)
,p_name=>'P108_IMP_FIRMAR_T'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155626370419298263)
,p_name=>'P108_NOM_APO_T'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Nombre Completo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155626477111298264)
,p_name=>'P108_CED_APO_T'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>unistr('N\00B0 C\00E9dula/ID:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_help_text=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333).')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155626604211298265)
,p_name=>'P108_EMAIL_APO_T'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>unistr('Correo electr\00F3nico:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>6
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155626721692298266)
,p_name=>'P108_NOM_APO_T_1'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Nombre Completo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155626756694298267)
,p_name=>'P108_CED_APO_T_1'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>unistr('N\00B0 C\00E9dula/ID:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155744593539273518)
,p_name=>'P108_EMAIL_APO_T_1'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>unistr('Correo electr\00F3nico:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>6
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155744702078273519)
,p_name=>'P108_IMP_FIRMAR_T_1'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155744836882273520)
,p_name=>'P108_NOM_APO_T_2'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Nombre Completo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155744938947273521)
,p_name=>'P108_CED_APO_T_2'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>unistr('N\00B0 C\00E9dula/ID:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155744989358273522)
,p_name=>'P108_EMAIL_APO_T_2'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>unistr('Correo electr\00F3nico:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>6
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155745075395273523)
,p_name=>'P108_IMP_FIRMAR_T_2'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155745225371273524)
,p_name=>'P108_NOM_APO_T_3'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Nombre Completo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155745282072273525)
,p_name=>'P108_CED_APO_T_3'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>unistr('N\00B0 C\00E9dula/ID:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155745434620273526)
,p_name=>'P108_EMAIL_APO_T_3'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>unistr('Correo electr\00F3nico:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>6
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155745485434273527)
,p_name=>'P108_IMP_FIRMAR_T_3'
,p_item_sequence=>350
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155745597154273528)
,p_name=>'P108_IMPUESTO_FIRMAR_1'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(252734690663454961)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155745670738273529)
,p_name=>'P108_IMPUESTO_FIRMAR_2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(252734821763454962)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155745827843273530)
,p_name=>'P108_NOM_APO_T_4'
,p_item_sequence=>380
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Nombre Completo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155745942686273531)
,p_name=>'P108_CED_APO_T_4'
,p_item_sequence=>390
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>unistr('N\00B0 C\00E9dula/ID:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155746011748273532)
,p_name=>'P108_EMAIL_APO_T_4'
,p_item_sequence=>400
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>unistr('Correo electr\00F3nico:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>6
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155746134613273533)
,p_name=>'P108_IMP_FIRMAR_T_4'
,p_item_sequence=>430
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155746150207273534)
,p_name=>'P108_NOM_APO_T_5'
,p_item_sequence=>460
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Nombre Completo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155746337504273535)
,p_name=>'P108_CED_APO_T_5'
,p_item_sequence=>470
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>unistr('N\00B0 C\00E9dula/ID:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155746395152273536)
,p_name=>'P108_EMAIL_APO_T_5'
,p_item_sequence=>480
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>unistr('Correo electr\00F3nico:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>6
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(155746511050273537)
,p_name=>'P108_IMP_FIRMAR_T_5'
,p_item_sequence=>520
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(162392502066194832)
,p_name=>'P108_PODER_LEGAL'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Cedula'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>15
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_begin_on_new_line=>'N'
,p_grid_column=>8
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(162392597768194833)
,p_name=>'P108_PODER_LEGAL_1'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Cedula'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_begin_on_new_line=>'N'
,p_grid_column=>8
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(162392695163194834)
,p_name=>'P108_PODER_LEGAL_2'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Cedula'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_begin_on_new_line=>'N'
,p_grid_column=>8
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(162392848503194835)
,p_name=>'P108_PODER_LEGAL_3'
,p_item_sequence=>330
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Cedula'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_begin_on_new_line=>'N'
,p_grid_column=>8
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(162392925887194836)
,p_name=>'P108_PODER_LEGAL_4'
,p_item_sequence=>410
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Cedula'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_begin_on_new_line=>'N'
,p_grid_column=>8
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(162393023948194837)
,p_name=>'P108_PODER_LEGAL_5'
,p_item_sequence=>500
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Cedula'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_begin_on_new_line=>'N'
,p_grid_column=>8
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(183627014734852844)
,p_name=>'P108_PODER_ESPECIAL'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Poder Especial'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_begin_on_new_line=>'N'
,p_grid_column=>11
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>108
,p_default_id_offset=>149139848948344617
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(183627147334852845)
,p_name=>'P108_PODER_ESPECIAL_1'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Poder Especial'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_begin_on_new_line=>'N'
,p_grid_column=>11
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(183627186553852846)
,p_name=>'P108_PODER_ESPECIAL_2'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Poder Especial'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_begin_on_new_line=>'N'
,p_grid_column=>11
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(183627260352852847)
,p_name=>'P108_PODER_ESPECIAL_3'
,p_item_sequence=>340
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Poder Especial'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_begin_on_new_line=>'N'
,p_grid_column=>11
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(183627386841852848)
,p_name=>'P108_PODER_ESPECIAL_4'
,p_item_sequence=>420
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Poder Especial'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_begin_on_new_line=>'N'
,p_grid_column=>11
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(183627478387852849)
,p_name=>'P108_PODER_ESPECIAL_5'
,p_item_sequence=>510
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Poder Especial'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_begin_on_new_line=>'N'
,p_grid_column=>11
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(192175179257286665)
,p_name=>'P108_TEXTO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(252734568962454960)
,p_item_default=>unistr('El suscrito como due\00F1o (a) o apoderado (a) y con facultades suficientes para este acto, solicit\00F3 firmar digitalmente las declaraciones juradas de impuestos del ICT conforme se\00F1alo a continuaci\00F3n:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(154259822246688872)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252734391835454958)
,p_name=>'P108_IMPUESTO_FIRMAR_3'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(252734568962454960)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>5
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252734547957454959)
,p_name=>'P108_IMPUESTO_FIRMAR_4'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(252734568962454960)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'3'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252734975444454964)
,p_name=>'P108_IMPUESTO_FIRMAR_5'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(252734690663454961)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>5
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252735078845454965)
,p_name=>'P108_IMPUESTO_FIRMAR_6'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(252734690663454961)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'3'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252735216221454966)
,p_name=>'P108_IMPUESTO_FIRMAR_7'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_api.id(252734821763454962)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>5
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(252735340540454967)
,p_name=>'P108_IMPUESTO_FIRMAR_8'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(252734821763454962)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'3'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(259747789607541918)
,p_name=>'P108_IMP_FIRMAR_T_6'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>6
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'3'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(259747937544541919)
,p_name=>'P108_IMP_FIRMAR_T_7'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(259748007822541920)
,p_name=>'P108_IMP_FIRMAR_T_8'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(259748074839541921)
,p_name=>'P108_IMP_FIRMAR_T_9'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>6
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'3'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(259748153056541922)
,p_name=>'P108_IMP_FIRMAR_T_10'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(259748321078541923)
,p_name=>'P108_IMP_FIRMAR_T_11'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>6
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'3'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(259748360959541924)
,p_name=>'P108_IMP_FIRMAR_T_12'
,p_item_sequence=>360
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(259748477101541925)
,p_name=>'P108_IMP_FIRMAR_T_13'
,p_item_sequence=>370
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>6
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'3'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(259748571787541926)
,p_name=>'P108_IMP_FIRMAR_T_14'
,p_item_sequence=>440
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(259748715738541927)
,p_name=>'P108_IMP_FIRMAR_T_15'
,p_item_sequence=>450
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>6
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'3'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(259748774930541928)
,p_name=>'P108_IMP_FIRMAR_T_16'
,p_item_sequence=>530
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>4
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(259748917016541929)
,p_name=>'P108_IMP_FIRMAR_T_17'
,p_item_sequence=>540
,p_item_plug_id=>wwv_flow_api.id(155625466715298254)
,p_prompt=>'Impuesto a firmar:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P102_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (:P104_TIP_IMPUESTO,:P104_TIP_IMPUESTO_1,:P104_TIP_IMPUESTO_2)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_column=>6
,p_display_when=>'P108_CANT_IMPUESTO'
,p_display_when2=>'3'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(259749038480541930)
,p_name=>'P108_CANT_IMPUESTO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(155625412845298253)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(259749388182541934)
,p_name=>'P108_ALERTA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(155625412845298253)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(160761625115823256)
,p_validation_name=>'VAL_FORMATO_EMAIL'
,p_validation_sequence=>10
,p_validation=>'P108_EMAIL_APODERADO'
,p_validation2=>'@'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Formato del email no valido'
,p_validation_condition=>'P108_EMAIL_APODERADO'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(155624602470298245)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(160761679707823257)
,p_validation_name=>'VAL_FORMATO_EMAIL1'
,p_validation_sequence=>20
,p_validation=>'P108_EMAIL_APODERADO_1'
,p_validation2=>'@'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Formato del email no valido'
,p_validation_condition=>'P108_EMAIL_APODERADO_1'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(155624868684298248)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(160761839258823258)
,p_validation_name=>'VAL_FORMATO_EMAIL2'
,p_validation_sequence=>30
,p_validation=>'P108_EMAIL_APODERADO_2'
,p_validation2=>'@'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Formato del email no valido'
,p_validation_condition=>'P108_EMAIL_APODERADO_2'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(155625211509298251)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(160761855015823259)
,p_validation_name=>'VAL_FORMAT_EMAIL'
,p_validation_sequence=>40
,p_validation=>'P108_EMAIL_APO_T'
,p_validation2=>'@'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Formato del email no valido'
,p_validation_condition=>'P108_EMAIL_APO_T'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(155626604211298265)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(160761998924823260)
,p_validation_name=>'VAL_FORMAT_EMAIL1'
,p_validation_sequence=>50
,p_validation=>'P108_EMAIL_APO_T_1'
,p_validation2=>'@'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Formato del email no valido'
,p_validation_condition=>'P108_EMAIL_APO_T_1'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(155744593539273518)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(160762134987823261)
,p_validation_name=>'VAL_FORMAT_EMAIL2'
,p_validation_sequence=>60
,p_validation=>'P108_EMAIL_APO_T_2'
,p_validation2=>'@'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Formato del email no valido'
,p_validation_condition=>'P108_EMAIL_APO_T_2'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(155744989358273522)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(160762214351823262)
,p_validation_name=>'VAL_FORMAT_EMAIL3'
,p_validation_sequence=>70
,p_validation=>'P108_EMAIL_APO_T_3'
,p_validation2=>'@'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Formato del email no valido'
,p_validation_condition=>'P108_EMAIL_APO_T_3'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(155745434620273526)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(160762250788823263)
,p_validation_name=>'VAL_FORMAT_EMAIL4'
,p_validation_sequence=>80
,p_validation=>'P108_EMAIL_APO_T_4'
,p_validation2=>'@'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Formato del email no valido'
,p_validation_condition=>'P108_EMAIL_APO_T_4'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(155746011748273532)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(160762375009823264)
,p_validation_name=>'VAL_FORMAT_EMAIL5'
,p_validation_sequence=>90
,p_validation=>'P108_EMAIL_APO_T_5'
,p_validation2=>'@'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Formato del email no valido'
,p_validation_condition=>'P108_EMAIL_APO_T_5'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(155746395152273536)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(161445890831269646)
,p_validation_name=>'VAL_CED_APO_T_4'
,p_validation_sequence=>230
,p_validation=>'P108_CED_APO_T_4'
,p_validation_type=>'ITEM_IS_ALPHANUMERIC'
,p_error_message=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_validation_condition=>'P108_TERCEROS'
,p_validation_condition2=>'S'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_associated_item=>wwv_flow_api.id(155745942686273531)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(161446321040269650)
,p_validation_name=>'VAL_CED_APO_T_5'
,p_validation_sequence=>240
,p_validation=>'P108_CED_APO_T_5'
,p_validation_type=>'ITEM_IS_ALPHANUMERIC'
,p_error_message=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_validation_condition=>'P108_TERCEROS'
,p_validation_condition2=>'S'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_associated_item=>wwv_flow_api.id(155746337504273535)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(174796699318155857)
,p_validation_name=>'VAL_CEDULA_APO'
,p_validation_sequence=>250
,p_validation=>'P108_CEDULA_APRODERADO'
,p_validation_type=>'ITEM_IS_ALPHANUMERIC'
,p_error_message=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_associated_item=>wwv_flow_api.id(155624375384298243)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(174796810838155858)
,p_validation_name=>'VAL_CEDULA_APO_1'
,p_validation_sequence=>260
,p_validation=>'P108_CEDULA_APRODERADO_1'
,p_validation_type=>'ITEM_IS_ALPHANUMERIC'
,p_error_message=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_associated_item=>wwv_flow_api.id(155624800850298247)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(174796906736155859)
,p_validation_name=>'VAL_CEDULA_APO_2'
,p_validation_sequence=>270
,p_validation=>'P108_CEDULA_APRODERADO_2'
,p_validation_type=>'ITEM_IS_ALPHANUMERIC'
,p_error_message=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_associated_item=>wwv_flow_api.id(155625111176298250)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(174797031658155860)
,p_validation_name=>'VAL_CED_APO_T1'
,p_validation_sequence=>280
,p_validation=>'P108_CED_APO_T'
,p_validation_type=>'ITEM_IS_ALPHANUMERIC'
,p_error_message=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_associated_item=>wwv_flow_api.id(155626477111298264)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(174797094701155861)
,p_validation_name=>'VAL_CED_APO_T3'
,p_validation_sequence=>290
,p_validation=>'P108_CED_APO_T_3'
,p_validation_type=>'ITEM_IS_ALPHANUMERIC'
,p_error_message=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_associated_item=>wwv_flow_api.id(155745282072273525)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(174797258971155863)
,p_validation_name=>'VAL_CED_APOT1'
,p_validation_sequence=>300
,p_validation=>'P108_CED_APO_T_1'
,p_validation_type=>'ITEM_IS_ALPHANUMERIC'
,p_error_message=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_associated_item=>wwv_flow_api.id(155626756694298267)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(174797408124155864)
,p_validation_name=>'VAL_CED_APO_T2'
,p_validation_sequence=>310
,p_validation=>'P108_CED_APO_T_2'
,p_validation_type=>'ITEM_IS_ALPHANUMERIC'
,p_error_message=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_associated_item=>wwv_flow_api.id(155744938947273521)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(185589369088305354)
,p_validation_name=>'VAL_PODER_LEGAL'
,p_validation_sequence=>320
,p_validation=>'P108_PODER_LEGAL'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe Adjuntar un Archivo.'
,p_validation_condition=>'P108_NOM_APO_T'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(162392502066194832)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(185589494159305355)
,p_validation_name=>'VAL_PODER_ESPECIAL'
,p_validation_sequence=>330
,p_validation=>'P108_PODER_ESPECIAL'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe Adjuntar un Archivo.'
,p_validation_condition=>'P108_NOM_APO_T'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(183627014734852844)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(185589673593305357)
,p_validation_name=>'VAL_PODER_ESPECIAL_1'
,p_validation_sequence=>340
,p_validation=>'P108_PODER_ESPECIAL_1'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe Adjuntar un Archivo.'
,p_validation_condition=>'P108_NOM_APO_T_1'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(183627147334852845)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>108
,p_default_id_offset=>149139848948344617
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(185589905372305359)
,p_validation_name=>'VAL_PODER_ESPECIAL_2'
,p_validation_sequence=>350
,p_validation=>'P108_PODER_ESPECIAL_21'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe Adjuntar un Archivo.'
,p_validation_condition=>'P108_NOM_APO_T_2'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(183627186553852846)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(185590136623305361)
,p_validation_name=>'VAL_PODER_ESPECIAL_3'
,p_validation_sequence=>370
,p_validation=>'P108_PODER_ESPECIAL_3'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe Adjuntar un Archivo.'
,p_validation_condition=>'P108_NOM_APO_T_3'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(183627260352852847)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(185590529206305365)
,p_validation_name=>'VAL_PODER_ESPECIAL_4'
,p_validation_sequence=>380
,p_validation=>'P108_PODER_ESPECIAL_4'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe Adjuntar un Archivo.'
,p_validation_condition=>'P108_NOM_APO_T_4'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(183627386841852848)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(185590657943305367)
,p_validation_name=>'VAL_PODER_ESPECIAL_5'
,p_validation_sequence=>390
,p_validation=>'P108_PODER_ESPECIAL_5'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe Adjuntar un Archivo.'
,p_validation_condition=>'P108_NOM_APO_T_5'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(183627478387852849)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(185589632835305356)
,p_validation_name=>'VAL_PODER_LEGAL_1'
,p_validation_sequence=>400
,p_validation=>'P108_PODER_LEGAL_1'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe Adjuntar un Archivo.'
,p_validation_condition=>'P108_NOM_APO_T_1'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(162392597768194833)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(185589808273305358)
,p_validation_name=>'VAL_PODER_LEGAL_2'
,p_validation_sequence=>410
,p_validation=>'P108_PODER_LEGAL_2'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe Adjuntar un Archivo.'
,p_validation_condition=>'P108_NOM_APO_T_2'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(162392695163194834)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(185590039193305360)
,p_validation_name=>'VAL_PODER_LEGAL_3'
,p_validation_sequence=>420
,p_validation=>'P108_PODER_LEGAL_3'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe Adjuntar un Archivo.'
,p_validation_condition=>'P108_NOM_APO_T_3'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(162392848503194835)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(185590289167305363)
,p_validation_name=>'VAL_PODER_LEGAL_4'
,p_validation_sequence=>430
,p_validation=>'P108_PODER_LEGAL_4'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe Adjuntar un Archivo.'
,p_validation_condition=>'P108_NOM_APO_T_4'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(162392925887194836)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(185590604285305366)
,p_validation_name=>'VAL_PODER_LEGAL_5'
,p_validation_sequence=>440
,p_validation=>'P108_PODER_LEGAL_5'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe Adjuntar un Archivo.'
,p_validation_condition=>'P108_NOM_APO_T_5'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(162393023948194837)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(159909176664794910)
,p_validation_name=>'VAL_COMAS_APO1'
,p_validation_sequence=>450
,p_validation=>'P108_EMAIL_APODERADO'
,p_validation2=>','
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_NO_CHAR_IN_STRING2'
,p_error_message=>'Formato de correo no valido, por favor verificar'
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(158828356628968235)
,p_validation_name=>'VAL_COMAS_APO2'
,p_validation_sequence=>460
,p_validation=>'P108_EMAIL_APODERADO_1'
,p_validation2=>','
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_NO_CHAR_IN_STRING2'
,p_error_message=>'Formato de correo no valido, por favor verificar'
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(158828482586968236)
,p_validation_name=>'VAL_COMAS_APO3'
,p_validation_sequence=>470
,p_validation=>'P108_EMAIL_APODERADO_2'
,p_validation2=>','
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_NO_CHAR_IN_STRING2'
,p_error_message=>'Formato de correo no valido, por favor verificar'
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(158828547674968237)
,p_validation_name=>'VAL_COMAS_TER'
,p_validation_sequence=>480
,p_validation=>'P108_EMAIL_APO_T'
,p_validation2=>','
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_NO_CHAR_IN_STRING2'
,p_error_message=>'Formato de correo no valido, por favor verificar'
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(158828691564968238)
,p_validation_name=>'VAL_COMAS_TER_2'
,p_validation_sequence=>490
,p_validation=>'P108_EMAIL_APO_T_1'
,p_validation2=>','
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_NO_CHAR_IN_STRING2'
,p_error_message=>'Formato de correo no valido, por favor verificar'
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(158828778578968239)
,p_validation_name=>'VAL_COMAS_TER_3'
,p_validation_sequence=>500
,p_validation=>'P108_EMAIL_APO_T_2'
,p_validation2=>','
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_NO_CHAR_IN_STRING2'
,p_error_message=>'Formato de correo no valido, por favor verificar'
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(158828823119968240)
,p_validation_name=>'VAL_COMAS_TER_4'
,p_validation_sequence=>510
,p_validation=>'P108_EMAIL_APO_T_3'
,p_validation2=>','
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_NO_CHAR_IN_STRING2'
,p_error_message=>'Formato de correo no valido, por favor verificar'
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(158828923425968241)
,p_validation_name=>'VAL_COMAS_TER_5'
,p_validation_sequence=>520
,p_validation=>'P108_EMAIL_APO_T_4'
,p_validation2=>','
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_NO_CHAR_IN_STRING2'
,p_error_message=>'Formato de correo no valido, por favor verificar'
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(158829023550968242)
,p_validation_name=>'VAL_COMAS_TER_6'
,p_validation_sequence=>530
,p_validation=>'P108_EMAIL_APO_T_5'
,p_validation2=>','
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_NO_CHAR_IN_STRING2'
,p_error_message=>'Formato de correo no valido, por favor verificar'
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(155626010098298259)
,p_name=>'DAC_TERCEROS'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_TERCEROS'
,p_condition_element=>'P108_TERCEROS'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'S'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(155626139719298260)
,p_event_id=>wwv_flow_api.id(155626010098298259)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(155625466715298254)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(155626183959298261)
,p_event_id=>wwv_flow_api.id(155626010098298259)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(155625466715298254)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(192274611918450519)
,p_event_id=>wwv_flow_api.id(155626010098298259)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'IF :P102_TIPO_CONTRIBUYENTE = 2 THEN ',
'   :P108_IMP_FIRMAR_T := 1;',
'END IF;',
'END;'))
,p_attribute_03=>'P108_IMP_FIRMAR_T'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(192274695381450520)
,p_event_id=>wwv_flow_api.id(155626010098298259)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'IF :P102_TIPO_CONTRIBUYENTE = 2 THEN ',
'   :P108_IMP_FIRMAR_T := NULL;',
'END IF;',
'END;'))
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(192171868117286632)
,p_name=>'DAC_UPPER_NOM_APODERADO'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_NOM_APODERADO'
,p_bind_type=>'bind'
,p_bind_event_type=>'focusout'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(192171986979286633)
,p_event_id=>wwv_flow_api.id(192171868117286632)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P108_NOM_APODERADO").val($("#P108_NOM_APODERADO").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(192172111222286634)
,p_name=>'DAC_UPPER_NOM_APO1'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_NOM_APODERADO_1'
,p_bind_type=>'bind'
,p_bind_event_type=>'focusout'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(192172208881286635)
,p_event_id=>wwv_flow_api.id(192172111222286634)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P108_NOM_APODERADO_1").val($("#P108_NOM_APODERADO_1").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(192172307690286636)
,p_name=>'DAC_UPPER_NOM_APO2'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_NOM_APODERADO_2'
,p_bind_type=>'bind'
,p_bind_event_type=>'focusout'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(192172364288286637)
,p_event_id=>wwv_flow_api.id(192172307690286636)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P108_NOM_APODERADO_2").val($("#P108_NOM_APODERADO_2").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(192172459898286638)
,p_name=>'DAC_UPPER_NOM_APOT'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_NOM_APO_T'
,p_bind_type=>'bind'
,p_bind_event_type=>'focusout'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(192172647697286639)
,p_event_id=>wwv_flow_api.id(192172459898286638)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P108_NOM_APO_T").val($("#P108_NOM_APO_T").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(192172735805286640)
,p_name=>'DAC_UPPER_NOM_APOT1'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_NOM_APO_T_1'
,p_bind_type=>'bind'
,p_bind_event_type=>'focusout'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(192172810745286641)
,p_event_id=>wwv_flow_api.id(192172735805286640)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P108_NOM_APO_T_1").val($("#P108_NOM_APO_T_1").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(192172865293286642)
,p_name=>'DAC_UPPER_NOM_APOT2'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_NOM_APO_T_2'
,p_bind_type=>'bind'
,p_bind_event_type=>'focusout'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(192172950669286643)
,p_event_id=>wwv_flow_api.id(192172865293286642)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P108_NOM_APO_T_2").val($("#P108_NOM_APO_T_2").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(192173118787286644)
,p_name=>'DAC_NOM_APOT3'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_NOM_APO_T_3'
,p_bind_type=>'bind'
,p_bind_event_type=>'focusout'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(192173201045286645)
,p_event_id=>wwv_flow_api.id(192173118787286644)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P108_NOM_APO_T_3").val($("#P108_NOM_APO_T_3").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(192173261697286646)
,p_name=>'DAC_UPPER_NOM_APOT4'
,p_event_sequence=>90
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_NOM_APO_T_4'
,p_bind_type=>'bind'
,p_bind_event_type=>'focusout'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(192173366564286647)
,p_event_id=>wwv_flow_api.id(192173261697286646)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P108_NOM_APO_T_4").val($("#P108_NOM_APO_T_4").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(192173528493286648)
,p_name=>'DAC_UPPER_NOM_APOT5'
,p_event_sequence=>100
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_NOM_APO_T_5'
,p_bind_type=>'bind'
,p_bind_event_type=>'focusout'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(192173589468286649)
,p_event_id=>wwv_flow_api.id(192173528493286648)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P108_NOM_APO_T_5").val($("#P108_NOM_APO_T_5").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(259749486144541935)
,p_name=>'DAC_ALERTA_IMP'
,p_event_sequence=>120
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_ALERTA'
,p_condition_element=>'P108_ALERTA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'N'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(259749634827541936)
,p_event_id=>wwv_flow_api.id(259749486144541935)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'No se puede seleccionar el mismo impuesto mas de una vez, por favor valide.'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(259749706704541937)
,p_name=>'DAC_REPITE_IMP_APO1'
,p_event_sequence=>130
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_IMPUESTO_FIRMAR,P108_IMPUESTO_FIRMAR_3,P108_IMPUESTO_FIRMAR_4'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(259749822902541938)
,p_event_id=>wwv_flow_api.id(259749706704541937)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P108_IMPUESTO_FIRMAR = :P108_IMPUESTO_FIRMAR_3  OR :P108_IMPUESTO_FIRMAR = :P108_IMPUESTO_FIRMAR_4 OR :P108_IMPUESTO_FIRMAR_3 = :P108_IMPUESTO_FIRMAR_4 THEN',
'    :P108_ALERTA := ''N'';',
'ELSE',
' :P108_ALERTA := ''S'';',
'END IF;            '))
,p_attribute_02=>'P108_IMPUESTO_FIRMAR,P108_IMPUESTO_FIRMAR_3,P108_IMPUESTO_FIRMAR_4'
,p_attribute_03=>'P108_ALERTA'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(259749109857541931)
,p_name=>'DAC_REPITE_IMP_APO2'
,p_event_sequence=>131
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_IMPUESTO_FIRMAR_1,P108_IMPUESTO_FIRMAR_5,P108_IMPUESTO_FIRMAR_6'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(259749225968541932)
,p_event_id=>wwv_flow_api.id(259749109857541931)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P108_IMPUESTO_FIRMAR_1= :P108_IMPUESTO_FIRMAR_5 OR :P108_IMPUESTO_FIRMAR_1= :P108_IMPUESTO_FIRMAR_6 OR :P108_IMPUESTO_FIRMAR_5 = :P108_IMPUESTO_FIRMAR_6 THEN',
'    :P108_ALERTA := ''N'';',
'ELSE',
' :P108_ALERTA := ''S'';',
'END IF;          '))
,p_attribute_02=>'P108_IMPUESTO_FIRMAR_1,P108_IMPUESTO_FIRMAR_5,P108_IMPUESTO_FIRMAR_6'
,p_attribute_03=>'P108_ALERTA'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(259750050805541941)
,p_name=>'DAC_REPITE_IMP_APO3'
,p_event_sequence=>132
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_IMPUESTO_FIRMAR_2,P108_IMPUESTO_FIRMAR_7,P108_IMPUESTO_FIRMAR_8'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(259750201094541942)
,p_event_id=>wwv_flow_api.id(259750050805541941)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P108_IMPUESTO_FIRMAR_2 = :P108_IMPUESTO_FIRMAR_7 OR :P108_IMPUESTO_FIRMAR_2 = :P108_IMPUESTO_FIRMAR_8 OR :P108_IMPUESTO_FIRMAR_7 = :P108_IMPUESTO_FIRMAR_8 THEN',
'    :P108_ALERTA := ''N'';',
'ELSE',
' :P108_ALERTA := ''S'';',
'END IF; '))
,p_attribute_02=>'P108_IMPUESTO_FIRMAR_2,P108_IMPUESTO_FIRMAR_7,P108_IMPUESTO_FIRMAR_8'
,p_attribute_03=>'P108_ALERTA'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(259750521757541945)
,p_name=>'DAC_REPITE_IMP_TERC1'
,p_event_sequence=>140
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_IMP_FIRMAR_T,P108_IMP_FIRMAR_T_7,P108_IMP_FIRMAR_T_6'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(259750565569541946)
,p_event_id=>wwv_flow_api.id(259750521757541945)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P108_IMP_FIRMAR_T = :P108_IMP_FIRMAR_T_7 OR :P108_IMP_FIRMAR_T = :P108_IMP_FIRMAR_T_6 OR :P108_IMP_FIRMAR_T_7 = :P108_IMP_FIRMAR_T_6 THEN',
'    :P108_ALERTA := ''N'';',
'ELSE',
' :P108_ALERTA := ''S'';',
'END IF;             '))
,p_attribute_02=>'P108_IMP_FIRMAR_T,P108_IMP_FIRMAR_T_6 ,P108_IMP_FIRMAR_T_7'
,p_attribute_03=>'P108_ALERTA'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(259750683224541947)
,p_name=>'DAC_REPITE_IMP_TERC2'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_IMP_FIRMAR_T_1,P108_IMP_FIRMAR_T_8,P108_IMP_FIRMAR_T_9'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(259750785661541948)
,p_event_id=>wwv_flow_api.id(259750683224541947)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P108_IMP_FIRMAR_T_1 = :P108_IMP_FIRMAR_T_8 OR :P108_IMP_FIRMAR_T_1 = :P108_IMP_FIRMAR_T_9 OR :P108_IMP_FIRMAR_T_8 = :P108_IMP_FIRMAR_T_9 THEN',
'    :P108_ALERTA := ''N'';',
'ELSE',
' :P108_ALERTA := ''S'';',
'END IF;            '))
,p_attribute_02=>'P108_IMP_FIRMAR_T_1,P108_IMP_FIRMAR_T_8,P108_IMP_FIRMAR_T_9'
,p_attribute_03=>'P108_ALERTA'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(259750895431541949)
,p_name=>'DAC_REPITE_IMP_TERC3'
,p_event_sequence=>160
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_IMP_FIRMAR_T_2,P108_IMP_FIRMAR_T_10,P108_IMP_FIRMAR_T_11'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(259750963435541950)
,p_event_id=>wwv_flow_api.id(259750895431541949)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P108_IMP_FIRMAR_T_2 = :P108_IMP_FIRMAR_T_10 OR :P108_IMP_FIRMAR_T_2 = :P108_IMP_FIRMAR_T_11 OR :P108_IMP_FIRMAR_T_10 = :P108_IMP_FIRMAR_T_11 THEN',
'    :P108_ALERTA := ''N'';',
'ELSE',
' :P108_ALERTA := ''S'';',
'END IF;             '))
,p_attribute_02=>'P108_IMP_FIRMAR_T_2,P108_IMP_FIRMAR_T_10,P108_IMP_FIRMAR_T_11'
,p_attribute_03=>'P108_ALERTA'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(259751258113541953)
,p_name=>'DAC_REPITE_IMP_TERC4'
,p_event_sequence=>170
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_IMP_FIRMAR_T_3,P108_IMP_FIRMAR_T_12,P108_IMP_FIRMAR_T_13'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(259751429593541954)
,p_event_id=>wwv_flow_api.id(259751258113541953)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P108_IMP_FIRMAR_T_3 = :P108_IMP_FIRMAR_T_12 OR :P108_IMP_FIRMAR_T_3 = :P108_IMP_FIRMAR_T_13 OR :P108_IMP_FIRMAR_T_12 = :P108_IMP_FIRMAR_T_13 THEN',
'    :P108_ALERTA := ''N'';',
'ELSE',
' :P108_ALERTA := ''S'';',
'END IF;             '))
,p_attribute_02=>'P108_IMP_FIRMAR_T_3,P108_IMP_FIRMAR_T_12,P108_IMP_FIRMAR_T_13'
,p_attribute_03=>'P108_ALERTA'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(259751542850541955)
,p_name=>'DAC_REPITE_IMP_TERC5'
,p_event_sequence=>180
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_IMP_FIRMAR_T_4,P108_IMP_FIRMAR_T_14,P108_IMP_FIRMAR_T_15'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(259751581885541956)
,p_event_id=>wwv_flow_api.id(259751542850541955)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P108_IMP_FIRMAR_T_4 = :P108_IMP_FIRMAR_T_14 OR :P108_IMP_FIRMAR_T_4 = :P108_IMP_FIRMAR_T_15 OR :P108_IMP_FIRMAR_T_14 = :P108_IMP_FIRMAR_T_15 THEN',
'    :P108_ALERTA := ''N'';',
'ELSE',
' :P108_ALERTA := ''S'';',
'END IF;             '))
,p_attribute_02=>'P108_IMP_FIRMAR_T_4,P108_IMP_FIRMAR_T_14,P108_IMP_FIRMAR_T_15'
,p_attribute_03=>'P108_ALERTA'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(259751718965541957)
,p_name=>'DAC_REPITE_IMP_TERC6'
,p_event_sequence=>190
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_IMP_FIRMAR_T_5,P108_IMP_FIRMAR_T_16,P108_IMP_FIRMAR_T_17'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(259751838114541958)
,p_event_id=>wwv_flow_api.id(259751718965541957)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P108_IMP_FIRMAR_T_5 = :P108_IMP_FIRMAR_T_16 OR :P108_IMP_FIRMAR_T_5 = :P108_IMP_FIRMAR_T_17 OR :P108_IMP_FIRMAR_T_16 = :P108_IMP_FIRMAR_T_17 THEN',
'    :P108_ALERTA := ''N'';',
'ELSE',
' :P108_ALERTA := ''S'';',
'END IF;             '))
,p_attribute_02=>'P108_IMP_FIRMAR_T_5,P108_IMP_FIRMAR_T_16,P108_IMP_FIRMAR_T_17'
,p_attribute_03=>'P108_ALERTA'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(192274490071450518)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_DATOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'/*IF :P102_TIPO_CONTRIBUYENTE = 2 THEN',
'   :P108_IMPUESTO_FIRMAR := 1; ',
'END IF;*/',
'',
':P108_CANT_IMPUESTO := PKG_MAESTRO_CONTRIBUYENTE.CANT_IMPUESTO_TIP_CONTRIB (:P102_TIPO_CONTRIBUYENTE);',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
