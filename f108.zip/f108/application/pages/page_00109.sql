prompt --application/pages/page_00109
begin
--   Manifest
--     PAGE: 00109
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>108
,p_default_id_offset=>149139848948344617
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>109
,p_user_interface_id=>wwv_flow_api.id(154283420613688838)
,p_name=>'VII. Observaciones de la empresa:'
,p_alias=>'VII-OBSERVACIONES-DE-LA-EMPRESA'
,p_step_title=>'Observaciones'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_browser_cache=>'N'
,p_last_updated_by=>'KIMBERLYN.SOLANO'
,p_last_upd_yyyymmddhh24miss=>'20221121125124'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(154575996715707946)
,p_plug_name=>'VII. Observaciones de la empresa:'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall'
,p_plug_template=>wwv_flow_api.id(154209205076688900)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(154546934337707973)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(154238115289688884)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(154576072961707946)
,p_plug_name=>'VII. Observaciones de la empresa:'
,p_parent_plug_id=>wwv_flow_api.id(154575996715707946)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(154171394141688918)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(155091021605138839)
,p_plug_name=>' Observaciones del Administrado:'
,p_parent_plug_id=>wwv_flow_api.id(154576072961707946)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(154578018888707945)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(154575996715707946)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Regresar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-angle-double-left'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(183170330648227462)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(154575996715707946)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Siguiente'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_icon_css_classes=>'fa-angle-double-right'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(154577904628707945)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(154575996715707946)
,p_button_name=>'FINISH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260245196688872)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Finish'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_condition_type=>'NEVER'
,p_icon_css_classes=>'fa-angle-double-right'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(154577816827707945)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(154575996715707946)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(154579456967707945)
,p_branch_name=>'Go To Page 111'
,p_branch_action=>'f?p=&APP_ID.:111:&SESSION.::&DEBUG.::P111_NUM_SOLICITUD:&P109_ID_NUM_SOLICITUD.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(183170330648227462)
,p_branch_sequence=>1
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(154578841559707945)
,p_branch_name=>'Go To Page 108'
,p_branch_action=>'f?p=&APP_ID.:108:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(154578018888707945)
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(154577518576707945)
,p_name=>'P109_OBS_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(155091021605138839)
,p_prompt=>'Observaciones:'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>150
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(160757948555823219)
,p_name=>'P109_ID_NUM_SOLICITUD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(155091021605138839)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(192173744790286650)
,p_name=>'DAC_UPPER_OBSERV'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P109_OBS_EMPRESA'
,p_bind_type=>'bind'
,p_bind_event_type=>'focusout'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(192173769696286651)
,p_event_id=>wwv_flow_api.id(192173744790286650)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P109_OBS_EMPRESA").val($("#P109_OBS_EMPRESA").val().toUpperCase());'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(234078903065206266)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_DATOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vExiste VARCHAR2(1);',
'BEGIN',
'    IF :P109_ID_NUM_SOLICITUD IS NOT NULL THEN',
'        SELECT ''S'' INTO vExiste FROM SOLICITUD_INSCRIPCION WHERE ID_NUM_INSCRIPCION= :P109_ID_NUM_SOLICITUD;',
'            IF vExiste = ''S'' THEN',
'             :P109_ID_NUM_SOLICITUD := NULL;',
'            END IF;',
'    END IF;',
'END;',
''))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(156942729422980165)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERTA_SOLICITUD'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vId_Num_Inscripcion NUMBER;',
'vIdApoderado NUMBER;',
'vIdApoderadoAut NUMBER;',
'v_retorno_boolean   boolean;',
'v_mensaje_retorno   varchar2(2000);',
'',
'vArchivo BLOB;',
'vMimetype VARCHAR2(255);',
'vFilename VARCHAR2(255);',
'vArchivo1 BLOB;',
'vMimetype1 VARCHAR2(255);',
'vFilename1 VARCHAR2(255);',
'vCed_Fisica VARCHAR2(20);',
'vCed_Juridica VARCHAR2(20);',
'vFechaOperaciones DATE;',
'BEGIN',
'    IF :P103_ID_TIPO_IDENTIFICACION = 1 THEN',
'        vCed_Juridica:= :P103_CEDULA;',
'    ELSE',
'        vCed_Fisica := :P103_CEDULA;',
'    END IF;',
'    ',
'   -- RAISE_APPLICATION_ERROR(-20000,:P103_FECHA_INICIO_OPERA);',
'    vFechaOperaciones := TO_DATE(:P103_FECHA_INICIO_OPERA,''DD/MM/YYYY'');',
'    ',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_SOLICITUD_INSCRIP(vId_Num_Inscripcion,',
'                                                       :P103_NOMBRE_ENTIDAD,',
'                                                       :P103_ID_TIPO_IDENTIFICACION,',
'                                                       :P103_RAZON_SOCIAL,',
'                                                       :P103_PERSONA_FISICA,',
'                                                       vCed_Juridica,',
'                                                       vCed_Fisica,',
'                                                       :P103_TIPO_FUENTE,',
'                                                       :P103_COD_IATA,',
'                                                       NULL,',
'                                                       vFechaOperaciones,',
'                                                       :P104_DIRECCION_FISCAL,',
'                                                       :P104_PROV_FISCAL,',
'                                                       :P104_CANTON_FISCAL,',
'                                                       :P104_DIST_FISCAL,',
'                                                       :P105_DIRECCION_NOTIF,',
'                                                       :P105_PROV_NOTIF,',
'                                                       :P105_CANTON_NOTIF,',
'                                                       :P105_DIST_NOTF, ',
'                                                       :P106_CED_GERENTE,',
'                                                       :P106_NOM_GERENTE,',
'                                                       :P106_EMAIL_GERENTE,                                  ',
'                                                       :P106_NOM_LEGAL,',
'                                                       :P106_CED_LEGAL,',
'                                                       :P106_EMAIL_LEGAL,',
'                                                       ''RG'',',
'                                                       SYSDATE,--pFECHA_INSCRIPCION,',
'                                                       :P109_OBS_EMPRESA,--pOBSERVA_EMPRESA,',
'                                                       NULL,--pOBSERVA_ADM_TRIBUTA,    ',
'                                                       NULL,--pFECHA_SUSCRITO,',
'                                                       NULL,--pLUGAR_SUSCRITO,',
'                                                       NULL,--pUSUARIO_INTERNO,',
'                                                       NULL,--ID_CHARTER',
'                                                       NULL,--ID_REQUISITOS_INS',
'                                                       NULL,',
'                                                       NULL,',
'                                                       NULL,',
'                                                       NULL,',
'                                                       NULL,',
'                                                       :APP_USER,',
'                                                       v_mensaje_retorno,',
'                                                       v_retorno_boolean);',
'                                                       COMMIT;',
'',
'    :P109_ID_NUM_SOLICITUD := vId_Num_Inscripcion;',
'    ',
'--Insertamos tipo venta',
'IF :P103_ID_TIPO_VENTAS1 IS NOT NULL THEN',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_TIPO_VENTAS_INSCRIP (vId_Num_Inscripcion,',
'                                                          :P103_ID_TIPO_VENTAS1,',
'                                                          :APP_USER,',
'                                                          v_mensaje_retorno,',
'                                                          v_retorno_boolean);',
'END IF;',
'IF :P103_ID_TIPO_VENTAS2 IS NOT NULL THEN',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_TIPO_VENTAS_INSCRIP (vId_Num_Inscripcion,',
'                                                          :P103_ID_TIPO_VENTAS2,',
'                                                          :APP_USER,',
'                                                          v_mensaje_retorno,',
'                                                          v_retorno_boolean);',
'END IF;',
'--Insertamos el archivo del representante legal',
'IF :P106_PODER_LEGAL IS NOT NULL THEN',
'SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P106_PODER_LEGAL;',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_ARCHI_REPRE_LEGAL_IR (vArchivo,',
'                                                           vFilename,',
'                                                           vMimetype,',
'                                                           vId_Num_Inscripcion,',
'                                                           :APP_USER);',
'END IF;',
'--Insertamos los datos en la tabla TELEFONO_X_SOLICITUD_INSCRIP-----------------',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_TEL_SOLIC_INSCRIP (vId_Num_Inscripcion,',
'                                                        :P103_TEL_OFICINA1,',
'                                                        :P103_CELULAR,',
'                                                        :APP_USER,',
'                                                        v_mensaje_retorno,',
'                                                        v_retorno_boolean);',
'    IF :P103_TEL_OFICINA2 IS NOT NULL THEN                                        ',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_TEL_SOLIC_INSCRIP (vId_Num_Inscripcion,',
'                                                        :P103_TEL_OFICINA2,',
'                                                        :P103_CELULAR2,',
'                                                        :APP_USER,',
'                                                         v_mensaje_retorno,',
'                                                         v_retorno_boolean);',
'    END IF;                                         ',
'--Insertamos los datos en la tabla IMPUESTO_X_SOLICITUD_INSCRI------------------                                        ',
'    IF :P104_TIP_IMPUESTO IS NOT NULL THEN',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_IMP_SOLIC_INSCRIP (vId_Num_Inscripcion,',
'                                                        :P104_TIP_IMPUESTO,',
'                                                        :P104_NOM_ENC_IMP,',
'                                                        :P104_CED_ENC_IMP,',
'                                                        :P104_EMAIL_ENC_IMP,',
'                                                        :APP_USER,',
'                                                        v_mensaje_retorno,',
'                                                        v_retorno_boolean); ',
'    END IF;',
'    IF :P104_TIP_IMPUESTO_1 IS NOT NULL THEN ',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_IMP_SOLIC_INSCRIP (vId_Num_Inscripcion,',
'                                                        :P104_TIP_IMPUESTO_1,',
'                                                        :P104_NOM_ENC_IMP,',
'                                                        :P104_CED_ENC_IMP,',
'                                                        :P104_EMAIL_ENC_IMP,',
'                                                        :APP_USER,',
'                                                        v_mensaje_retorno,',
'                                                        v_retorno_boolean); ',
'    END IF;',
'    IF :P104_TIP_IMPUESTO_2 IS NOT NULL THEN',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_IMP_SOLIC_INSCRIP (vId_Num_Inscripcion,',
'                                                        :P104_TIP_IMPUESTO_2,',
'                                                        :P104_NOM_ENC_IMP,',
'                                                        :P104_CED_ENC_IMP,',
'                                                        :P104_EMAIL_ENC_IMP,',
'                                                        :APP_USER,',
'                                                        v_mensaje_retorno,',
'                                                        v_retorno_boolean);',
'    END IF;                              ',
'                                              ',
'--Inserta datos en la tabla CORREO_NOTIFICA_INSCRIP-----------------------------                                          ',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_CORREO_NOT_INSCRIP (vId_Num_Inscripcion,',
'                                                         :P105_EMAIL1_NOTIF,',
'                                                         :P105_EMAIL2_NOTIF,',
'                                                         :APP_USER,',
'                                                         v_mensaje_retorno,',
'                                                         v_retorno_boolean);',
'                                           ',
'--Inserta datos en la tabla APODERADOS_SOLICITUD--------------------------------',
'   IF :P107_PODER_LEGAL IS NOT NULL THEN',
'   SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P107_PODER_LEGAL;',
'   PKG_INSCRIPCION_REGULAR.P_INSERT_APODERADOS_SOLICITUD (vIdApoderado,',
'                                                          vId_Num_Inscripcion,',
'                                                          :P107_TIPO_APODERADO,',
'                                                          :P107_NOM_APO_GEN,',
'                                                          :P107_CED_APO_GEN,',
'                                                          :P107_EMAIL_APO_GEN,',
'                                                          ''A'',',
'                                                           vArchivo,',
'                                                           vFilename,',
'                                                           vMimetype,',
'                                                           :APP_USER,',
'                                                           v_mensaje_retorno,',
'                                                           v_retorno_boolean);',
'    END IF;                             ',
'    IF :P107_PODER_LEGAL_1 IS NOT NULL THEN',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P107_PODER_LEGAL_1;',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_APODERADOS_SOLICITUD (vIdApoderado,',
'                                                           vId_Num_Inscripcion,',
'                                                           :P107_TIPO_APODERADO_1,',
'                                                           :P107_NOM_APO_GEN_1,',
'                                                           :P107_CED_APO_GEN_1,',
'                                                           :P107_EMAIL_APO_GEN_1,',
'                                                           ''A'',',
'                                                           vArchivo,',
'                                                           vFilename,',
'                                                           vMimetype,',
'                                                           :APP_USER,',
'                                                           v_mensaje_retorno,',
'                                                           v_retorno_boolean);',
'    END IF;                              ',
'    IF :P107_PODER_LEGAL_2 IS NOT NULL THEN',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P107_PODER_LEGAL_2;',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_APODERADOS_SOLICITUD (vIdApoderado,',
'                                                           vId_Num_Inscripcion,',
'                                                           :P107_TIPO_APODERADO_2,',
'                                                           :P107_NOM_APO_GEN_2,',
'                                                           :P107_CED_APO_GEN_2,',
'                                                           :P107_EMAIL_APO_GEN_2,',
'                                                           ''A'',',
'                                                           vArchivo,',
'                                                           vFilename,',
'                                                           vMimetype,',
'                                                           :APP_USER,',
'                                                           v_mensaje_retorno,',
'                                                           v_retorno_boolean);',
'    END IF;                            ',
unistr('--Inserta datos en la tabla APODERADOS_SOLICITUD, Autorizaci\00F3n Uso Firma Digital--------------------------------                                               '),
'    IF :P108_NOM_APODERADO IS NOT NULL THEN',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_APODERADOS_AUT_FIRMA (vIdApoderadoAut,',
'                                                           vId_Num_Inscripcion,',
'                                                           :P108_NOM_APODERADO,',
'                                                           :P108_CEDULA_APRODERADO,',
'                                                           :P108_EMAIL_APODERADO,',
'                                                           NULL,',
'                                                           ''F'',',
'                                                           NULL,',
'                                                           NULL,',
'                                                           NULL,',
'                                                           NULL,',
'                                                           NULL,',
'                                                           NULL,',
'                                                           :APP_USER,',
'                                                           :P108_IMPUESTO_FIRMAR,',
'                                                           :P108_IMPUESTO_FIRMAR_3,',
'                                                           :P108_IMPUESTO_FIRMAR_4,                        ',
'                                                           v_mensaje_retorno,',
'                                                           v_retorno_boolean); ',
'    END IF;',
'    IF :P108_NOM_APODERADO_1 IS NOT NULL THEN',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_APODERADOS_AUT_FIRMA (vIdApoderadoAut,',
'                                                           vId_Num_Inscripcion,',
'                                                           :P108_NOM_APODERADO_1,',
'                                                           :P108_CEDULA_APRODERADO_1,',
'                                                           :P108_EMAIL_APODERADO_1,',
'                                                           NULL,',
'                                                           ''F'',',
'                                                           NULL,',
'                                                           NULL,',
'                                                           NULL,',
'                                                           NULL,',
'                                                           NULL,',
'                                                           NULL,',
'                                                           :APP_USER,',
'                                                           :P108_IMPUESTO_FIRMAR_1,',
'                                                           :P108_IMPUESTO_FIRMAR_5,',
'                                                           :P108_IMPUESTO_FIRMAR_6,',
'                                                           v_mensaje_retorno,',
'                                                           v_retorno_boolean); ',
'    END IF;',
'    IF :P108_NOM_APODERADO_2 IS NOT NULL THEN',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_APODERADOS_AUT_FIRMA (vIdApoderadoAut,',
'                                                           vId_Num_Inscripcion,',
'                                                           :P108_NOM_APODERADO_2,',
'                                                           :P108_CEDULA_APRODERADO_2,',
'                                                           :P108_EMAIL_APODERADO_2,',
'                                                           NULL,',
'                                                           ''F'',',
'                                                           NULL,',
'                                                           NULL,',
'                                                           NULL,',
'                                                           NULL,',
'                                                           NULL,',
'                                                           NULL,',
'                                                           :APP_USER,',
'                                                           :P108_IMPUESTO_FIRMAR_2,',
'                                                           :P108_IMPUESTO_FIRMAR_7,',
'                                                           :P108_IMPUESTO_FIRMAR_8,',
'                                                           v_mensaje_retorno,',
'                                                           v_retorno_boolean); ',
'     END IF;                              ',
unistr('--Inserta datos en la tabla APODERADOS_SOLICITUD, Autorizaci\00F3n Uso Firma Digital Terceros--------------------------------  '),
'   IF :P108_TERCEROS = ''S'' THEN',
'   IF :P108_PODER_LEGAL IS NOT NULL THEN',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P108_PODER_LEGAL;',
'    END IF;',
'    IF :P108_PODER_ESPECIAL IS NOT NULL THEN',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo1,vMimetype1, vFilename1 FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P108_PODER_ESPECIAL;',
'    END IF;',
'    IF :P108_NOM_APO_T IS NOT NULL THEN',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_APODERADOS_AUT_FIRMA (vIdApoderadoAut,',
'                                                           vId_Num_Inscripcion,',
'                                                           :P108_NOM_APO_T,',
'                                                           :P108_CED_APO_T,',
'                                                           :P108_EMAIL_APO_T,',
'                                                           NULL,',
'                                                           ''T'',',
'                                                           vArchivo,',
'                                                           vFilename,',
'                                                           vMimetype,',
'                                                           vArchivo1,',
'                                                           vFilename1,',
'                                                           vMimetype1,',
'                                                           :APP_USER,',
'                                                           :P108_IMP_FIRMAR_T,',
'                                                           :P108_IMP_FIRMAR_T_7,',
'                                                           :P108_IMP_FIRMAR_T_6,',
'                                                           v_mensaje_retorno,',
'                                                           v_retorno_boolean);',
'    END IF;                               ',
'    IF :P108_PODER_LEGAL_1 IS NOT NULL THEN',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P108_PODER_LEGAL_1;                             ',
'    END IF;',
'    IF :P108_PODER_ESPECIAL_1 IS NOT NULL THEN',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo1,vMimetype1, vFilename1 FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P108_PODER_ESPECIAL_1;                             ',
'    END IF;',
'    IF :P108_NOM_APO_T_1 IS NOT NULL THEN',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_APODERADOS_AUT_FIRMA (vIdApoderadoAut,',
'                                   vId_Num_Inscripcion,',
'                                   :P108_NOM_APO_T_1,',
'                                   :P108_CED_APO_T_1,',
'                                   :P108_EMAIL_APO_T_1,',
'                                   NULL,',
'                                   ''T'',',
'                                   vArchivo,',
'                                   vFilename,',
'                                   vMimetype,',
'                                   vArchivo1,',
'                                   vFilename1,',
'                                   vMimetype1,',
'                                   :APP_USER,',
'                                   :P108_IMP_FIRMAR_T_1,',
'                                   :P108_IMP_FIRMAR_T_8,',
'                                   :P108_IMP_FIRMAR_T_9,                        ',
'                                   v_mensaje_retorno,',
'                                   v_retorno_boolean);  ',
'    END IF;                               ',
'    IF :P108_PODER_LEGAL_2 IS NOT NULL THEN',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P108_PODER_LEGAL_2;                               ',
'    END IF;',
'    IF :P108_PODER_ESPECIAL_2 IS NOT NULL THEN',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo1,vMimetype1, vFilename1 FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P108_PODER_ESPECIAL_2;                               ',
'    END IF;',
'    IF :P108_NOM_APO_T_2 IS NOT NULL THEN',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_APODERADOS_AUT_FIRMA (vIdApoderadoAut,',
'                                   vId_Num_Inscripcion,',
'                                   :P108_NOM_APO_T_2,',
'                                   :P108_CED_APO_T_2,',
'                                   :P108_EMAIL_APO_T_2,',
'                                   NULL,',
'                                   ''T'',',
'                                   vArchivo,',
'                                   vFilename,',
'                                   vMimetype,',
'                                   vArchivo1,',
'                                   vFilename1,',
'                                   vMimetype1,',
'                                   :APP_USER,',
'                                   :P108_IMP_FIRMAR_T_2,',
'                                   :P108_IMP_FIRMAR_T_10,',
'                                   :P108_IMP_FIRMAR_T_11,                        ',
'                                   v_mensaje_retorno,',
'                                   v_retorno_boolean);  ',
'    END IF;                              ',
'    IF :P108_PODER_LEGAL_3 IS NOT NULL THEN',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P108_PODER_LEGAL_3;                               ',
'    END IF;',
'    IF :P108_PODER_ESPECIAL_3 IS NOT NULL THEN',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo1,vMimetype1, vFilename1 FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P108_PODER_ESPECIAL_3;                               ',
'    END IF;',
'    IF :P108_NOM_APO_T_3 IS NOT NULL THEN',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_APODERADOS_AUT_FIRMA (vIdApoderadoAut,',
'                                   vId_Num_Inscripcion,',
'                                   :P108_NOM_APO_T_3,',
'                                   :P108_CED_APO_T_3,',
'                                   :P108_EMAIL_APO_T_3,',
'                                   NULL,',
'                                   ''T'',',
'                                   vArchivo,',
'                                   vFilename,',
'                                   vMimetype,',
'                                   vArchivo1,',
'                                   vFilename1,',
'                                   vMimetype1,',
'                                   :APP_USER,',
'                                   :P108_IMP_FIRMAR_T_3,',
'                                   :P108_IMP_FIRMAR_T_12,',
'                                   :P108_IMP_FIRMAR_T_13,                        ',
'                                   v_mensaje_retorno,',
'                                   v_retorno_boolean);',
'    END IF;                               ',
'    IF :P108_PODER_LEGAL_4 IS NOT NULL THEN',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P108_PODER_LEGAL_4;                               ',
'    END IF; ',
'    IF :P108_PODER_ESPECIAL_4 IS NOT NULL THEN',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo1,vMimetype1, vFilename1 FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P108_PODER_ESPECIAL_4;                               ',
'    END IF;',
'    IF :P108_NOM_APO_T_4 IS NOT NULL THEN',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_APODERADOS_AUT_FIRMA (vIdApoderadoAut,',
'                                   vId_Num_Inscripcion,',
'                                   :P108_NOM_APO_T_4,',
'                                   :P108_CED_APO_T_4,',
'                                   :P108_EMAIL_APO_T_4,',
'                                   NULL,',
'                                   ''T'',',
'                                   vArchivo,',
'                                   vFilename,',
'                                   vMimetype,',
'                                   vArchivo1,',
'                                   vFilename1,',
'                                   vMimetype1,',
'                                   :APP_USER,',
'                                   :P108_IMP_FIRMAR_T_4,',
'                                   :P108_IMP_FIRMAR_T_14,',
'                                   :P108_IMP_FIRMAR_T_15,                        ',
'                                   v_mensaje_retorno,',
'                                   v_retorno_boolean);   ',
'    END IF;                               ',
'    IF :P108_PODER_LEGAL_5 IS NOT NULL THEN',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P108_PODER_LEGAL_5;',
'    END IF;',
'    IF :P108_PODER_ESPECIAL_5 IS NOT NULL THEN',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo1,vMimetype1, vFilename1 FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P108_PODER_ESPECIAL_5;',
'    END IF;',
'    IF :P108_NOM_APO_T_5 IS NOT NULL THEN',
'    PKG_INSCRIPCION_REGULAR.P_INSERT_APODERADOS_AUT_FIRMA (vIdApoderadoAut,',
'                                   vId_Num_Inscripcion,',
'                                   :P108_NOM_APO_T_5,',
'                                   :P108_CED_APO_T_5,',
'                                   :P108_EMAIL_APO_T_5,',
'                                   NULL,',
'                                   ''T'',',
'                                   vArchivo,',
'                                   vFilename,',
'                                   vMimetype,',
'                                   vArchivo1,',
'                                   vFilename1,',
'                                   vMimetype1,',
'                                   :APP_USER,',
'                                   :P108_IMP_FIRMAR_T_5,',
'                                   :P108_IMP_FIRMAR_T_16,',
'                                   :P108_IMP_FIRMAR_T_17,                        ',
'                                   v_mensaje_retorno,',
'                                   v_retorno_boolean);',
'    END IF;',
'END IF;',
'IF NOT v_retorno_boolean  ',
'   THEN',
'     RAISE_APPLICATION_ERROR(-20000,v_mensaje_retorno);',
'     rollback;',
'     return; ',
'   else ',
'      commit;',
'   end if;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(183170330648227462)
,p_process_when=>'P109_ID_NUM_SOLICITUD'
,p_process_when_type=>'ITEM_IS_NULL'
);
wwv_flow_api.component_end;
end;
/
