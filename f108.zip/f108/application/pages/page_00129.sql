prompt --application/pages/page_00129
begin
--   Manifest
--     PAGE: 00129
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>108
,p_default_id_offset=>149139848948344617
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>129
,p_user_interface_id=>wwv_flow_api.id(154283420613688838)
,p_name=>'129-Documentos requeridos COT'
,p_alias=>'129-DOCUMENTOS-REQUERIDOS-COT'
,p_step_title=>'Documentos requeridos'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'JORGE.ROJAS'
,p_last_upd_yyyymmddhh24miss=>'20240731150158'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(410096834161328033)
,p_plug_name=>'Principal'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(291049914920566689)
,p_plug_name=>'Obligaciones'
,p_parent_plug_id=>wwv_flow_api.id(410096834161328033)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>60
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P129_ARC_COMPLETOS'
,p_plug_display_when_cond2=>'S'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(290955219270576032)
,p_plug_name=>'Acepta terminos'
,p_parent_plug_id=>wwv_flow_api.id(291049914920566689)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>70
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<center><h4>Declaro bajo fe de juramento que la informaci\00F3n'),
'consignada en este documento es cierta, asumo las responsabilidades y',
unistr('consecuencias legales que correspondan en caso de omisi\00F3n, falsedad o'),
'inexactitud.</h4></center>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(414969159263621051)
,p_name=>'Indicaciones'
,p_parent_plug_id=>wwv_flow_api.id(410096834161328033)
,p_template=>wwv_flow_api.id(154198847510688906)
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_column=>10
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Archivo ya fue adjuntado''descripcion,',
'      ''S'' SI,    ',
'      case ''S''',
'      when ''S'' then ''far fa-check-circle''',
'       end as icon_class1,       ',
'       case ''S''',
'           when ''S'' then ''#7AFF33''',
'       end as color_class1',
'  from DUAL',
'  UNION',
'  select ''Archivo pendiente de adjuntar''descripcion,',
'      ''N'' SI,    ',
'      case ''N''',
'      when ''N'' then ''fas fa-times-circle''',
'       end as icon_class2,       ',
'       case ''N''',
'           when ''N'' then ''#FF5733''',
'       end as color_class2',
'  from DUAL',
'    UNION',
unistr('  select ''Administraci\00F3n Tributaria verificar\00E1''descripcion,'),
'      ''C'' SI,    ',
'      case ''C''',
'      when ''C'' then ''fas fa-question-circle''',
'       end as icon_class3,       ',
'       case ''C''',
'           when ''C'' then ''#F7DC6F''',
'       end as color_class3',
'  from DUAL'))
,p_display_when_condition=>'P129_ID_DECLARA_CTO'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(154225098567688891)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(152839823732685152)
,p_query_column_id=>1
,p_column_alias=>'DESCRIPCION'
,p_column_display_sequence=>3
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(152841048829685151)
,p_query_column_id=>2
,p_column_alias=>'SI'
,p_column_display_sequence=>4
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="fa #ICON_CLASS1#" style="color: #COLOR_CLASS1#;">',
'    <spam class="visuallyhidden">#SI#</spam>',
'</span>'))
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(152840205530685152)
,p_query_column_id=>3
,p_column_alias=>'ICON_CLASS1'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(152840640773685151)
,p_query_column_id=>4
,p_column_alias=>'COLOR_CLASS1'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(434451996102751868)
,p_name=>'Reporte Documentos'
,p_parent_plug_id=>wwv_flow_api.id(410096834161328033)
,p_template=>wwv_flow_api.id(154198847510688906)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_REQUISITOS_INS,',
'       TIPO_REQUISTO,',
'       NOMBRE_REQUISITO,',
'       ID_TIPO_CONTRIBUYENTE,',
'       PKG_TRAMITE_COT.EXISTE_ARCHI_REQUI_COT (ID_REQUISITOS_INS,:P129_ID_DECLARA_CTO,:GLOBAL_TIPO_CONTRIBUYENTE)EXISTE_ARCHIVO,',
'       case PKG_TRAMITE_COT.EXISTE_ARCHI_REQUI_COT (ID_REQUISITOS_INS,:P129_ID_DECLARA_CTO,:P129_TIPO_CONTRIB)',
'           when ''S'' then ''far fa-check-circle''',
'           when ''N'' then ''fas fa-times-circle''',
'           when ''C'' then ''fas fa-question-circle''',
'       end as icon_class,       ',
'       case PKG_TRAMITE_COT.EXISTE_ARCHI_REQUI_COT (ID_REQUISITOS_INS,:P129_ID_DECLARA_CTO,:P129_TIPO_CONTRIB)',
'           when ''S'' then ''#7AFF33''',
'           when ''N'' then ''#FF5733''',
'           when ''C'' then ''#F7DC6F''',
'       end as color_class,',
'       case PKG_TRAMITE_COT.EXISTE_ARCHI_REQUI_COT (ID_REQUISITOS_INS,:P129_ID_DECLARA_CTO,:P129_TIPO_CONTRIB) ',
'           when ''N'' then ''javascript:$s("P129_ID_REQUISITO",''||ID_REQUISITOS_INS||'');javascript:openModal("ID"); $("#ID").trigger("apexrefresh");''',
'           when ''S'' then ''#''',
'           when ''C'' then ''#''',
'       end as link',
'  from TIPO_REQUISITOS',
'  where ID_TIPO_CONTRIBUYENTE = :P129_TIPO_CONTRIB',
'  and   TIPO_REQUISTO = ''I''',
'  and CODIGO_ESTADO = ''AC''',
'  ORDER BY ID_REQUISITOS_INS ASC'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P129_TIPO_CONTRIB'
,p_query_row_template=>wwv_flow_api.id(154225098567688891)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(152836029543685160)
,p_query_column_id=>1
,p_column_alias=>'ID_REQUISITOS_INS'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(152837284818685159)
,p_query_column_id=>2
,p_column_alias=>'TIPO_REQUISTO'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(152836867076685160)
,p_query_column_id=>3
,p_column_alias=>'NOMBRE_REQUISITO'
,p_column_display_sequence=>3
,p_column_heading=>'Requisitos'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(152836419500685160)
,p_query_column_id=>4
,p_column_alias=>'ID_TIPO_CONTRIBUYENTE'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(152834074780685163)
,p_query_column_id=>5
,p_column_alias=>'EXISTE_ARCHIVO'
,p_column_display_sequence=>5
,p_column_heading=>'Existe Archivo'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="fa #ICON_CLASS#" style="color: #COLOR_CLASS#;">',
'    <spam class="visuallyhidden">#EXISTE_ARCHIVO#</spam>',
'</span>'))
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(152834416173685161)
,p_query_column_id=>6
,p_column_alias=>'ICON_CLASS'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(152834857683685161)
,p_query_column_id=>7
,p_column_alias=>'COLOR_CLASS'
,p_column_display_sequence=>8
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(152835202323685161)
,p_query_column_id=>8
,p_column_alias=>'LINK'
,p_column_display_sequence=>9
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(152835679738685160)
,p_query_column_id=>9
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>6
,p_column_heading=>'Adjuntar'
,p_use_as_row_header=>'N'
,p_column_link=>'#LINK#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-page.png" class="apex-edit-page" alt="">'
,p_column_alignment=>'CENTER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(435024504804806685)
,p_plug_name=>'Adjuntar Archivos'
,p_region_name=>'ID'
,p_parent_plug_id=>wwv_flow_api.id(434451996102751868)
,p_region_template_options=>'#DEFAULT#:js-dialog-size480x320'
,p_plug_template=>wwv_flow_api.id(154191258258688908)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(445106349371616238)
,p_plug_name=>'Titulo'
,p_parent_plug_id=>wwv_flow_api.id(410096834161328033)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
'<center><h4>Documentos requeridos</h4></center>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(152846374048685146)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(290955219270576032)
,p_button_name=>'BTN_ACEPTAR_COT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Aceptar y Continuar'
,p_button_position=>'BELOW_BOX'
,p_button_condition=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_button_condition2=>'8'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(166182766893266340)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(290955219270576032)
,p_button_name=>'BTN_ACEPTAR_TTR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Aceptar y Continuar'
,p_button_position=>'BELOW_BOX'
,p_button_condition=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_button_condition2=>'4'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(152837963627685159)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(435024504804806685)
,p_button_name=>'BTN_GUARDAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(152860164784685118)
,p_branch_name=>'Go To Page 131'
,p_branch_action=>'f?p=&APP_ID.:131:&SESSION.::&DEBUG.::P131_ID_DECLARA_CTO:&P129_ID_DECLARA_CTO.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(152846374048685146)
,p_branch_sequence=>10
,p_branch_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_branch_condition=>'P129_AVANZAR'
,p_branch_condition_text=>'S'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(166182830176266341)
,p_branch_name=>'Go To Page 110'
,p_branch_action=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.::P110_TIPO_INSCRIPCION:TTR&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(166182766893266340)
,p_branch_sequence=>20
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152838342939685157)
,p_name=>'P129_ID_REQUISITO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(435024504804806685)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152838705978685153)
,p_name=>'P129_ARCHIVO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(435024504804806685)
,p_prompt=>'Seleccionar Archivo:'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_field_template=>wwv_flow_api.id(154259822246688872)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152839133535685153)
,p_name=>'P129_NOTIFICACION'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(435024504804806685)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152841764376685151)
,p_name=>'P129_ID_DECLARA_CTO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(445106349371616238)
,p_item_default=>'SEQ_DECLARA_CHARTER_TO'
,p_item_default_type=>'SEQUENCE'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152842160936685150)
,p_name=>'P129_ARC_COMPLETOS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(445106349371616238)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152842553238685150)
,p_name=>'P129_AVANZAR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(445106349371616238)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152843298610685150)
,p_name=>'P129_OBLIGACIONES'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(291049914920566689)
,p_prompt=>unistr('Estoy al d\00EDa con las obligaciones de:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152843674552685149)
,p_name=>'P129_AL_DIA_CCSS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(291049914920566689)
,p_prompt=>'La CCSS'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'LOV_SI_NO'
,p_lov=>'.'||wwv_flow_api.id(152784941721926735)||'.'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'2'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152844021358685149)
,p_name=>'P129_AL_DIA_MH'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(291049914920566689)
,p_prompt=>'Ministerio de Hacienda:'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'LOV_SI_NO'
,p_lov=>'.'||wwv_flow_api.id(152784941721926735)||'.'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'2'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152844470635685148)
,p_name=>'P129_AL_DIA_FODESAF'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(291049914920566689)
,p_prompt=>'FODESAF:'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'LOV_SI_NO'
,p_lov=>'.'||wwv_flow_api.id(152784941721926735)||'.'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'2'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152844846352685148)
,p_name=>'P129_VAL_OBLIGACIONES'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(291049914920566689)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152845230804685148)
,p_name=>'P129_MENSAJE1'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(291049914920566689)
,p_item_default=>unistr('Para continuar con el tr\00E1mite de Ch\00E1rter Ocasional Terrestre, primero debe estar al d\00EDa la obligaci\00F3n tributaria ante la entidad correspondiente.')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>135
,p_tag_attributes=>'style="color:red;"'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(152845682010685147)
,p_name=>'P129_MENSAJE2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(291049914920566689)
,p_item_default=>unistr('Requisitos ser\00E1n verificados ante la entidad respectiva.')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_tag_attributes=>'style="color:green;"'
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174900847699154116)
,p_name=>'P129_MOSTRAR_REGION'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(445106349371616238)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174901913181154127)
,p_name=>'P129_TIPO_CONTRIB'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(445106349371616238)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152857238189685120)
,p_name=>'DAC_MUESTRA_ARRENDAT'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P129_CONTRATO_ARRENDA'
,p_condition_element=>'P129_CONTRATO_ARRENDA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'S'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152857767507685120)
,p_event_id=>wwv_flow_api.id(152857238189685120)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P129_NOMBRE_ARRENDA,P129_ID_TIPO_IDENTIFICA,P129_CEDULA_ARRE'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152858226379685120)
,p_event_id=>wwv_flow_api.id(152857238189685120)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P129_NOMBRE_ARRENDA,P129_ID_TIPO_IDENTIFICA,P129_CEDULA_ARRE'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152856359796685121)
,p_name=>'DAC_VALIDA_MC'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P129_CEDULA'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152856838858685120)
,p_event_id=>wwv_flow_api.id(152856359796685121)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vExiste VARCHAR2(1);',
'BEGIN',
':P129_VALID_MC:= PKG_MAESTRO_CONTRIBUYENTE.VALIDA_EXISTE_MC (:P129_CEDULA);',
'END;'))
,p_attribute_02=>'P129_CEDULA'
,p_attribute_03=>'P129_VALID_MC'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152858646339685120)
,p_name=>'DAC_MSJ_MC'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P129_VALID_MC'
,p_condition_element=>'P129_VALID_MC'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'S'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152859154611685119)
,p_event_id=>wwv_flow_api.id(152858646339685120)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P129_VALID_MC_MSJ'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152859635526685119)
,p_event_id=>wwv_flow_api.id(152858646339685120)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P129_VALID_MC_MSJ'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152853998439685121)
,p_name=>'New'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(152837963627685159)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152854492288685121)
,p_event_id=>wwv_flow_api.id(152853998439685121)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P129_NOTIFICACION:= ''S'';'
,p_attribute_02=>'P129_NOTIFICACION'
,p_attribute_03=>'P129_NOTIFICACION'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152854980122685121)
,p_event_id=>wwv_flow_api.id(152853998439685121)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P129_NOTIFICACION'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152855991942685121)
,p_event_id=>wwv_flow_api.id(152853998439685121)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
,p_attribute_01=>'P129_NOTIFICACION'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152855496474685121)
,p_event_id=>wwv_flow_api.id(152853998439685121)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152847865850685126)
,p_name=>'DAC_CCSS'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P129_AL_DIA_CCSS'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152848367029685124)
,p_event_id=>wwv_flow_api.id(152847865850685126)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    ',
'    IF :P129_AL_DIA_CCSS = ''S'' AND :P129_AL_DIA_MH = ''S'' AND :P129_AL_DIA_FODESAF = ''S'' THEN',
'        :P129_VAL_OBLIGACIONES := ''S'';',
unistr('       -- :P129_MENSAJE2 :=''Requisitos ser\00E1n verificados ante la entidad respectiva.'';'),
'    ELSIF :P129_AL_DIA_CCSS = ''N'' OR :P129_AL_DIA_MH = ''N'' OR :P129_AL_DIA_FODESAF = ''N'' THEN',
'        :P129_VAL_OBLIGACIONES := ''N'';',
unistr('        --:P129_MENSAJE1 :=''Para continuar con el tr\00E1mite de Ch\00E1rter Ocasional Terrestre, primero debe estar al d\00EDa la obligaci\00F3n tributaria ante la entidad correspondiente.'';'),
'    ELSIF ',
'        :P129_AL_DIA_CCSS IS NULL AND :P129_AL_DIA_MH IS NULL AND :P129_AL_DIA_FODESAF IS NULL THEN',
'        :P129_VAL_OBLIGACIONES := ''N'';',
'        :P129_MENSAJE1 := NULL;',
'        :P129_MENSAJE2 := NULL;',
'    END IF;',
'END;'))
,p_attribute_02=>'P129_AL_DIA_CCSS,P129_AL_DIA_MH,P129_AL_DIA_FODESAF'
,p_attribute_03=>'P129_VAL_OBLIGACIONES'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152849698691685123)
,p_name=>'DAC_FODESAF'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P129_AL_DIA_FODESAF'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152850134276685123)
,p_event_id=>wwv_flow_api.id(152849698691685123)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    ',
'    IF :P129_AL_DIA_CCSS = ''S'' AND :P129_AL_DIA_MH = ''S'' AND :P129_AL_DIA_FODESAF = ''S'' THEN',
'        :P129_VAL_OBLIGACIONES := ''S'';',
unistr('        --:P129_MENSAJE2 :=''Requisitos ser\00E1n verificados ante la entidad respectiva.'';'),
'    ELSIF :P129_AL_DIA_CCSS = ''N'' OR :P129_AL_DIA_MH = ''N'' OR :P129_AL_DIA_FODESAF = ''N'' THEN',
'        :P129_VAL_OBLIGACIONES := ''N'';',
unistr('        --:P129_MENSAJE1 :=''Para continuar con el tr\00E1mite de Ch\00E1rter Ocasional Terrestre, primero debe estar al d\00EDa la obligaci\00F3n tributaria ante la entidad correspondiente.'';'),
'    ELSIF ',
'        :P129_AL_DIA_CCSS IS NULL AND :P129_AL_DIA_MH IS NULL AND :P129_AL_DIA_FODESAF IS NULL THEN',
'        :P129_VAL_OBLIGACIONES := ''N'';',
'        :P129_MENSAJE1 := NULL;',
'        :P129_MENSAJE2 := NULL;',
'    END IF;',
'END;'))
,p_attribute_02=>'P129_AL_DIA_CCSS,P129_AL_DIA_MH,P129_AL_DIA_FODESAF'
,p_attribute_03=>'P129_VAL_OBLIGACIONES'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152848791858685124)
,p_name=>'DAC_MH'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P129_AL_DIA_MH'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152849210540685124)
,p_event_id=>wwv_flow_api.id(152848791858685124)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    ',
'    IF :P129_AL_DIA_CCSS = ''S'' AND :P129_AL_DIA_MH = ''S'' AND :P129_AL_DIA_FODESAF = ''S'' THEN',
'        :P129_VAL_OBLIGACIONES := ''S'';',
unistr('        --:P129_MENSAJE2 :=''Requisitos ser\00E1n verificados ante la entidad respectiva.'';'),
'    ELSIF :P129_AL_DIA_CCSS = ''N'' OR :P129_AL_DIA_MH = ''N'' OR :P129_AL_DIA_FODESAF = ''N'' THEN',
'        :P129_VAL_OBLIGACIONES := ''N'';',
unistr('       -- :P129_MENSAJE1 :=''Para continuar con el tr\00E1mite de Ch\00E1rter Ocasional Terrestre, primero debe estar al d\00EDa la obligaci\00F3n tributaria ante la entidad correspondiente.'';'),
'    ELSIF ',
'        :P129_AL_DIA_CCSS IS NULL AND :P129_AL_DIA_MH IS NULL AND :P129_AL_DIA_FODESAF IS NULL THEN',
'        :P129_VAL_OBLIGACIONES := ''N'';',
'        :P129_MENSAJE1 := NULL;',
'        :P129_MENSAJE2 := NULL;',
'    END IF;',
'END;'))
,p_attribute_02=>'P129_AL_DIA_CCSS,P129_AL_DIA_MH,P129_AL_DIA_FODESAF'
,p_attribute_03=>'P129_VAL_OBLIGACIONES'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(152850571903685123)
,p_name=>'DAC_MUESTRA_MENSAJES'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P129_VAL_OBLIGACIONES'
,p_condition_element=>'P129_VAL_OBLIGACIONES'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'S'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152851518881685122)
,p_event_id=>wwv_flow_api.id(152850571903685123)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P129_MENSAJE2'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152852527560685122)
,p_event_id=>wwv_flow_api.id(152850571903685123)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P129_MENSAJE1'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152852005487685122)
,p_event_id=>wwv_flow_api.id(152850571903685123)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P129_MENSAJE1'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152853023937685122)
,p_event_id=>wwv_flow_api.id(152850571903685123)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P129_MENSAJE2'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152851032900685123)
,p_event_id=>wwv_flow_api.id(152850571903685123)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(290955219270576032)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(152853541938685122)
,p_event_id=>wwv_flow_api.id(152850571903685123)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(290955219270576032)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(152847099225685127)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_DATOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'BEGIN',
'',
'',
'    IF :P129_ARC_COMPLETOS = ''S'' THEN',
'    :P129_NOTIFICACION := ''N'';',
'    END IF;',
'    ',
'    IF :P129_ID_DECLARA_CTO IS NOT NULL AND :GLOBAL_TIPO_CONTRIBUYENTE = 8 THEN ',
'        :P129_MOSTRAR_REGION := ''S'';',
'        :P129_TIPO_CONTRIB := 8;',
'    ELSE',
'        :P129_MOSTRAR_REGION := ''N'';',
'    END IF;',
'    ',
'     IF :P129_ID_DECLARA_CTO IS NOT NULL AND :GLOBAL_TIPO_CONTRIBUYENTE = 4 THEN ',
'        :P129_MOSTRAR_REGION := ''S'';',
'        :P129_TIPO_CONTRIB := 17;',
'     ELSE',
'        :P129_MOSTRAR_REGION := ''N'';',
'    END IF;',
'    ',
'    :P129_ARC_COMPLETOS := PKG_TRAMITE_COT.VALIDA_EXIST_ARCH_INSCRIP (:P129_TIPO_CONTRIB,:P129_ID_DECLARA_CTO);',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(167213467376655789)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_ENVIA_CORREOS_TTR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_retorno_boolean   boolean;',
'v_mensaje_retorno   varchar2(2000);',
'vArchivo BLOB;',
'vMimetype VARCHAR2(255);',
'vFilename VARCHAR2(255);',
'',
'BEGIN',
'       PKG_ENVIO_NOTIF_ICT_CONTRIB.NOTIFICA_INSCRIPCION_COT(:P129_ID_DECLARA_CTO,17,''E'',''I'');',
'       PKG_ENVIO_NOTIF_ICT_CONTRIB.NOTIFICA_INSCRIPCION_COT(:P129_ID_DECLARA_CTO,17,''I'',''I'');',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(166182766893266340)
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>108
,p_default_id_offset=>149139848948344617
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(152846741827685127)
,p_process_sequence=>30
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_ADJUNTAR_ARCHIVOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_retorno_boolean   boolean;',
'v_mensaje_retorno   varchar2(2000);',
'vArchivo BLOB;',
'vMimetype VARCHAR2(255);',
'vFilename VARCHAR2(255);',
'',
'BEGIN',
'  ',
'  --Insertamos documentos requeridos',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P129_ARCHIVO;',
'    -- raise_application_error(-20000, :P129_ARCHIVO);',
'  ',
' PKG_TRAMITE_COT.P_INSERT_ARCHIVO_REQUI_COT (:P129_ID_REQUISITO,',
'                                             :P129_ID_DECLARA_CTO,',
'                                              vFilename,',
'                                              vArchivo,',
'                                              vMimetype,',
'                                              :APP_USER,',
'                                              v_mensaje_retorno,',
'                                              v_retorno_boolean); ',
'IF NOT v_retorno_boolean  ',
'   THEN',
'     RAISE_APPLICATION_ERROR(-20000,v_mensaje_retorno);',
'     rollback;',
'     return; ',
'   else ',
'      commit;',
'   end if;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P129_NOTIFICACION'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'S'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(152847427616685126)
,p_process_sequence=>40
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_GUARDA_CHECK'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'',
'UPDATE DECLARA_CHARTER_TERRESTRE_O SET CHECK_ACEPTA = ''S''WHERE ID_DECLARA_CTO = :P129_ID_DECLARA_CTO;',
'COMMIT;',
'',
':P129_AVANZAR := ''S'';',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(228238723177860020)
,p_process_sequence=>50
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_GUARDA_CHECK_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'',
'UPDATE DECLARA_CHARTER_TERRESTRE_O SET CHECK_ACEPTA = ''S''WHERE ID_DECLARA_CTO = :P129_ID_DECLARA_CTO;',
'COMMIT;',
'',
':P129_AVANZAR := ''S'';',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(166182766893266340)
);
wwv_flow_api.component_end;
end;
/
