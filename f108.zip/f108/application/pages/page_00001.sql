prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>108
,p_default_id_offset=>149139848948344617
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>1
,p_user_interface_id=>wwv_flow_api.id(154283420613688838)
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'Home'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Cards--featured .t-Card-titleWrap h3 {',
'/* font-size: inherit; */',
'font-size: 19px;',
'margin-bottom: 0;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_last_updated_by=>'KIMBERLYN.SOLANO'
,p_last_upd_yyyymmddhh24miss=>'20230321111846'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(154294253304688768)
,p_plug_name=>'Front_End'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(154171394141688918)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(247516998182378027)
,p_plug_name=>'Principal'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(148046088830686133)
,p_plug_name=>'Menu COT'
,p_parent_plug_id=>wwv_flow_api.id(247516998182378027)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--featured force-fa-lg:t-Cards--displayIcons:t-Cards--cols:t-Cards--desc-2ln:t-Cards--iconsSquare:t-Cards--animColorFill'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(190028168275699893)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(154250312940688877)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P1_MUESTRA_MENU_COT'
,p_plug_display_when_cond2=>'S'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(189387293726377666)
,p_plug_name=>unistr('Men\00FA')
,p_parent_plug_id=>wwv_flow_api.id(247516998182378027)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--featured force-fa-lg:t-Cards--displayIcons:t-Cards--cols:t-Cards--desc-2ln:t-Cards--iconsSquare:t-Cards--animColorFill'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_list_id=>wwv_flow_api.id(154145289518688954)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(154250312940688877)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_plug_display_when_condition=>'P1_MUESTRA_MENU_COT'
,p_plug_display_when_cond2=>'S'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(192687942430652326)
,p_plug_name=>'Titulo'
,p_parent_plug_id=>wwv_flow_api.id(247516998182378027)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<center><h2>Instituto Costarricense de Turismo</h2></center>',
unistr('<center><h3>El Departamento de Administraci\00F3n Tributaria le da la bienvenida al portal ICT CONTRIBUYENTE.</h3></center>')))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(195739899155376121)
,p_plug_name=>unistr('Informaci\00F3n ')
,p_parent_plug_id=>wwv_flow_api.id(247516998182378027)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'GLOBAL_USUARIO'
,p_plug_display_when_cond2=>'nobody'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(195739795070376120)
,p_plug_name=>unistr('En este portal el usuario podr\00E1 realizar:')
,p_parent_plug_id=>wwv_flow_api.id(195739899155376121)
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154181813833688913)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P1_MUESTRA_PORTAL_U'
,p_plug_display_when_cond2=>'S'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(148046153362686134)
,p_name=>'Manual de usuario'
,p_parent_plug_id=>wwv_flow_api.id(195739795070376120)
,p_template=>wwv_flow_api.id(154198847510688906)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--accent5:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_DOCUMENTO,',
'       NOMBRE_ARCHIVO,',
'       sys.dbms_lob.getlength("ARCHIVO")ARCHIVO,',
'       MIMETYPE,',
'       TIPO_ARCHIVO,',
'       DESCRIPCION',
'  from DOCTOS_ICT_CONTRIB_SIT',
'  where TIPO_ARCHIVO = ''ME'''))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(154225098567688891)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(148046233799686135)
,p_query_column_id=>1
,p_column_alias=>'ID_DOCUMENTO'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(148046382214686136)
,p_query_column_id=>2
,p_column_alias=>'NOMBRE_ARCHIVO'
,p_column_display_sequence=>2
,p_column_heading=>'Nombre'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(148046488027686137)
,p_query_column_id=>3
,p_column_alias=>'ARCHIVO'
,p_column_display_sequence=>3
,p_column_heading=>'Archivo'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:DOCTOS_ICT_CONTRIB_SIT:ARCHIVO:ID_DOCUMENTO::MIMETYPE:NOMBRE_ARCHIVO:::attachment:Descargar:'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(148046588230686138)
,p_query_column_id=>4
,p_column_alias=>'MIMETYPE'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(148046683427686139)
,p_query_column_id=>5
,p_column_alias=>'TIPO_ARCHIVO'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(148046703588686140)
,p_query_column_id=>6
,p_column_alias=>'DESCRIPCION'
,p_column_display_sequence=>6
,p_column_heading=>unistr('Descripci\00F3n')
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(195741490855376137)
,p_name=>'Reporte Portal usuario'
,p_parent_plug_id=>wwv_flow_api.id(195739795070376120)
,p_template=>wwv_flow_api.id(154198847510688906)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--noBorder:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--staticRowColors:t-Report--rowHighlightOff:t-Report--noBorders'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_NOTICIA,',
'       DESCRIPCION',
'  from NOTICIAS_SIT',
'where ID_TIPO_NOTICIA = 2',
'and CODIGO_ESTADO = ''AC''',
'ORDER BY ORDEN'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(154225098567688891)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(235574935533418860)
,p_query_column_id=>1
,p_column_alias=>'ID_NOTICIA'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(235575144047418862)
,p_query_column_id=>2
,p_column_alias=>'DESCRIPCION'
,p_column_display_sequence=>2
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(195741677942376139)
,p_plug_name=>'IMG1'
,p_parent_plug_id=>wwv_flow_api.id(195739795070376120)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_region_image=>'#APP_IMAGES#PuntaUva.jpg'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(195739996356376122)
,p_plug_name=>unistr('Informaci\00F3n importante:')
,p_parent_plug_id=>wwv_flow_api.id(195739899155376121)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154181813833688913)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P1_MUESTRA_INFO_IMPORT'
,p_plug_display_when_cond2=>'S'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(195741840503376140)
,p_name=>unistr('Reporte Informaci\00F3n Importante')
,p_parent_plug_id=>wwv_flow_api.id(195739996356376122)
,p_template=>wwv_flow_api.id(154198847510688906)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--noBorder:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--staticRowColors:t-Report--rowHighlightOff:t-Report--noBorders'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_NOTICIA,',
'       DESCRIPCION',
'  from NOTICIAS_SIT',
'where ID_TIPO_NOTICIA = 3',
'and CODIGO_ESTADO = ''AC''',
'ORDER BY ORDEN'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(154225098567688891)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(235575500917418866)
,p_query_column_id=>1
,p_column_alias=>'ID_NOTICIA'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(235575581957418867)
,p_query_column_id=>2
,p_column_alias=>'DESCRIPCION'
,p_column_display_sequence=>2
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(195741930213376141)
,p_plug_name=>'IMG2'
,p_parent_plug_id=>wwv_flow_api.id(195739996356376122)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_region_image=>'#APP_IMAGES#barco.JPG'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(195740054730376123)
,p_plug_name=>unistr('Horario de atenci\00F3n al p\00FAblico:')
,p_parent_plug_id=>wwv_flow_api.id(195739899155376121)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154181813833688913)
,p_plug_display_sequence=>60
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P1_MUESTRA_HORARIO'
,p_plug_display_when_cond2=>'S'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(234074396110206221)
,p_name=>unistr('Reporte Horario de Atenci\00F3n')
,p_parent_plug_id=>wwv_flow_api.id(195740054730376123)
,p_template=>wwv_flow_api.id(154198847510688906)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--noBorder:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--staticRowColors:t-Report--rowHighlightOff:t-Report--noBorders'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_NOTICIA,',
'       DESCRIPCION',
'  from NOTICIAS_SIT',
'where ID_TIPO_NOTICIA = 1',
'and CODIGO_ESTADO = ''AC''',
'ORDER BY ORDEN'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(154225098567688891)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(247516093415378018)
,p_query_column_id=>1
,p_column_alias=>'ID_NOTICIA'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(247516154564378019)
,p_query_column_id=>2
,p_column_alias=>'DESCRIPCION'
,p_column_display_sequence=>2
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(234074540165206222)
,p_plug_name=>'IMG3'
,p_parent_plug_id=>wwv_flow_api.id(195740054730376123)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_region_image=>'#APP_IMAGES#volcan.jpg'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(195740221826376124)
,p_plug_name=>unistr('Comunicados de la Administraci\00F3n Tributaria:')
,p_parent_plug_id=>wwv_flow_api.id(195739899155376121)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154181813833688913)
,p_plug_display_sequence=>70
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P1_MUESTRA_COMUNI'
,p_plug_display_when_cond2=>'S'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(234074562146206223)
,p_name=>'Reporte Comunicados'
,p_parent_plug_id=>wwv_flow_api.id(195740221826376124)
,p_template=>wwv_flow_api.id(154198847510688906)
,p_display_sequence=>60
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--noBorder:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--staticRowColors:t-Report--rowHighlightOff:t-Report--noBorders'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_NOTICIA,',
'       DESCRIPCION',
'  from NOTICIAS_SIT',
'where ID_TIPO_NOTICIA = 4',
'and CODIGO_ESTADO = ''AC''',
'ORDER BY ORDEN'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(154225098567688891)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(247516256504378020)
,p_query_column_id=>1
,p_column_alias=>'ID_NOTICIA'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(247516352758378021)
,p_query_column_id=>2
,p_column_alias=>'DESCRIPCION'
,p_column_display_sequence=>2
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(234074696236206224)
,p_plug_name=>'IMG4'
,p_parent_plug_id=>wwv_flow_api.id(195740221826376124)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_region_image=>'#APP_IMAGES#turismo10.jpg'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(160425659996431042)
,p_branch_name=>'Go To Page 132'
,p_branch_action=>'f?p=&APP_ID.:132:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_COMPUTATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_branch_condition=>'P1_ACEPTO_TPC'
,p_branch_condition_text=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(156424285517818448)
,p_name=>'P1_APP_CALLING'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(154294253304688768)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(160425275765431038)
,p_name=>'P1_ACEPTO_TPC'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(154294253304688768)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(160425395879431039)
,p_name=>'P1_IR_POLITICAS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(154294253304688768)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(166182237281266335)
,p_name=>'P1_MUESTRA_MENU_COT'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(154294253304688768)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(192276688998450540)
,p_name=>'P1_CANCELO_CAMBIO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(154294253304688768)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(247516524022378022)
,p_name=>'P1_MUESTRA_PORTAL_U'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(195739899155376121)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(247516617595378023)
,p_name=>'P1_MUESTRA_INFO_IMPORT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(195739899155376121)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(247516652846378024)
,p_name=>'P1_MUESTRA_HORARIO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(195739899155376121)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(247516808251378025)
,p_name=>'P1_MUESTRA_COMUNI'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(195739899155376121)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(160425502292431040)
,p_name=>'DAC_IR_TPC'
,p_event_sequence=>10
,p_condition_element=>'P1_ACEPTO_TPC'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'N'
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(160425598430431041)
,p_event_id=>wwv_flow_api.id(160425502292431040)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(192276780776450541)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_CANCELA_CAMBIO_PWD'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'IF :P1_CANCELO_CAMBIO = ''S'' THEN',
'UPDATE USUARIOS_EXTERNOS SET ESTADO = 1 WHERE ID_USUARIO = :APP_USER;',
'COMMIT;',
'END IF;',
'',
':P1_MUESTRA_PORTAL_U := PKG_INSCRIPCION_REGULAR.VALIDA_TIPO_NOTICIA (2);',
':P1_MUESTRA_INFO_IMPORT := PKG_INSCRIPCION_REGULAR.VALIDA_TIPO_NOTICIA (3);',
':P1_MUESTRA_HORARIO := PKG_INSCRIPCION_REGULAR.VALIDA_TIPO_NOTICIA (1);',
':P1_MUESTRA_COMUNI := PKG_INSCRIPCION_REGULAR.VALIDA_TIPO_NOTICIA (4);',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P1_CANCELO_CAMBIO'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'S'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(247516920022378026)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_DATOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
':P1_MUESTRA_PORTAL_U := PKG_INSCRIPCION_REGULAR.VALIDA_TIPO_NOTICIA (2);',
':P1_MUESTRA_INFO_IMPORT := PKG_INSCRIPCION_REGULAR.VALIDA_TIPO_NOTICIA (3);',
':P1_MUESTRA_HORARIO := PKG_INSCRIPCION_REGULAR.VALIDA_TIPO_NOTICIA (1);',
':P1_MUESTRA_COMUNI := PKG_INSCRIPCION_REGULAR.VALIDA_TIPO_NOTICIA (4);',
'IF :GLOBAL_USUARIO <> ''nobody'' THEN',
':P1_ACEPTO_TPC := PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ACEPTA_TPC (:GLOBAL_USUARIO);',
'END IF;',
'',
'--cOMDICION PARA MOSTRAR O NO MENU DE COT',
'IF :GLOBAL_TIPO_CONTRIBUYENTE IN (8,17) THEN',
'    :P1_MUESTRA_MENU_COT := ''S'';',
'ELSE',
'    :P1_MUESTRA_MENU_COT := ''N'';',
'END IF;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
