prompt --application/pages/page_00112
begin
--   Manifest
--     PAGE: 00112
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>108
,p_default_id_offset=>149139848948344617
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>112
,p_user_interface_id=>wwv_flow_api.id(154283420613688838)
,p_name=>'112-Datos Maestro Contribuyente'
,p_alias=>'112-DATOS-MAESTRO-CONTRIBUYENTE'
,p_step_title=>'Datos Maestro Contribuyente'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_browser_cache=>'N'
,p_last_updated_by=>'KIMBERLYN.SOLANO'
,p_last_upd_yyyymmddhh24miss=>'20230707161627'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(169242037425244047)
,p_plug_name=>'Tabs'
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:t-TabsRegion-mod--fillLabels:t-TabsRegion-mod--pill:t-TabsRegion-mod--large'
,p_plug_template=>wwv_flow_api.id(154205642281688902)
,p_plug_display_sequence=>5
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'STANDARD'
,p_attribute_02=>'Y'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(171608724738930424)
,p_plug_name=>unistr('Informaci\00F3n General')
,p_parent_plug_id=>wwv_flow_api.id(169242037425244047)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'MAESTRO_CONTRIBUYENTE'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(169242203248244049)
,p_plug_name=>unistr('Informaci\00F3n')
,p_parent_plug_id=>wwv_flow_api.id(171608724738930424)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(169242342984244050)
,p_plug_name=>'&P112_NOMBRE_REGION.'
,p_parent_plug_id=>wwv_flow_api.id(171608724738930424)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_plug_display_when_condition=>'P112_TIPO_INSCRIPCION'
,p_plug_display_when_cond2=>'IVC'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(169243278177244060)
,p_plug_name=>unistr('Direcci\00F3n para Notificaciones')
,p_parent_plug_id=>wwv_flow_api.id(171608724738930424)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P112_TIPO_INSCRIPCION'
,p_plug_display_when_cond2=>'IR'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(172408322532123127)
,p_plug_name=>unistr('Informaci\00F3n Gerente')
,p_parent_plug_id=>wwv_flow_api.id(171608724738930424)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>80
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P112_TIPO_INSCRIPCION'
,p_plug_display_when_cond2=>'IR'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(172408378443123128)
,p_plug_name=>'Representante Legal'
,p_parent_plug_id=>wwv_flow_api.id(171608724738930424)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>90
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(218772808805933950)
,p_plug_name=>'Actualizar Representante Legal'
,p_region_name=>'ID_REP_LEG'
,p_parent_plug_id=>wwv_flow_api.id(172408378443123128)
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(154191258258688908)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(172408528637123129)
,p_plug_name=>unistr('Informaci\00F3n Asistente en Tierra en Costa Rica')
,p_parent_plug_id=>wwv_flow_api.id(171608724738930424)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>100
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P112_TIPO_INSCRIPCION'
,p_plug_display_when_cond2=>'IVC'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(178157572055038555)
,p_name=>'Impuesto a Declarar'
,p_parent_plug_id=>wwv_flow_api.id(171608724738930424)
,p_template=>wwv_flow_api.id(154198847510688906)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_TIPO_IMPUESTO,',
'       ID_CONTRIBUYENTE,',
'       NOMBRE_ENCARGADO_IMP,',
'       CEDULA_ENCARGADO_IMP,',
'       CORREO_ENCARGADO_IMP',
'  from IMPUESTO_X_MAESTRO_CONTRIBUYE',
'  where ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE',
'  and   CODIGO_ESTADO = ''AC'''))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(154225098567688891)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(178157707544038556)
,p_query_column_id=>1
,p_column_alias=>'ID_TIPO_IMPUESTO'
,p_column_display_sequence=>1
,p_column_heading=>'Tipo Impuesto'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(161518516720599275)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(178157827705038557)
,p_query_column_id=>2
,p_column_alias=>'ID_CONTRIBUYENTE'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(178157855706038558)
,p_query_column_id=>3
,p_column_alias=>'NOMBRE_ENCARGADO_IMP'
,p_column_display_sequence=>3
,p_column_heading=>'Encargado'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P112_TIPO_INSCRIPCION'
,p_display_when_condition2=>'IR'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(178157993699038559)
,p_query_column_id=>4
,p_column_alias=>'CEDULA_ENCARGADO_IMP'
,p_column_display_sequence=>4
,p_column_heading=>'Cedula'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P112_TIPO_INSCRIPCION'
,p_display_when_condition2=>'IR'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(178158069644038560)
,p_query_column_id=>5
,p_column_alias=>'CORREO_ENCARGADO_IMP'
,p_column_display_sequence=>5
,p_column_heading=>'Correo'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P112_TIPO_INSCRIPCION'
,p_display_when_condition2=>'IR'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(230637671914413665)
,p_query_column_id=>6
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>6
,p_column_heading=>'Inactivar'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:$s(''P112_ID_IMPUESTO'',''#ID_TIPO_IMPUESTO#'');javascript:openModal(''ID_INAC_IMP''); $("#ID_INAC_IMP").trigger("apexrefresh");'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P112_CANT_IMPUESTOS'
,p_display_when_condition2=>'S'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(218774368162933966)
,p_plug_name=>'Agregar Impuesto'
,p_region_name=>'ID_IMPUESTO'
,p_parent_plug_id=>wwv_flow_api.id(178157572055038555)
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(154191258258688908)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(230637816555413666)
,p_plug_name=>'Inactivar Impuesto'
,p_region_name=>'ID_INAC_IMP'
,p_parent_plug_id=>wwv_flow_api.id(178157572055038555)
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size480x320'
,p_plug_template=>wwv_flow_api.id(154191258258688908)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(178158158427038561)
,p_name=>unistr('Tel\00E9fonos ')
,p_parent_plug_id=>wwv_flow_api.id(171608724738930424)
,p_template=>wwv_flow_api.id(154198847510688906)
,p_display_sequence=>60
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_region_attributes=>'style="height: 300px"'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_TELEFONO,',
'       ID_CONTRIBUYENTE,',
'       ID_TIPO_TELEFONO,',
'       TELEFONO',
'  from TELEFONO_X_MAESTRO_CONTRIBU',
'  where ID_CONTRIBUYENTE= :P112_ID_CONTRIBUYENTE'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(154225098567688891)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(178158306244038562)
,p_query_column_id=>1
,p_column_alias=>'ID_TELEFONO'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(178158357029038563)
,p_query_column_id=>2
,p_column_alias=>'ID_CONTRIBUYENTE'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(178158529190038564)
,p_query_column_id=>3
,p_column_alias=>'ID_TIPO_TELEFONO'
,p_column_display_sequence=>3
,p_column_heading=>unistr('Tipo Tel\00E9fono')
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(174475070475657271)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(178158612170038565)
,p_query_column_id=>4
,p_column_alias=>'TELEFONO'
,p_column_display_sequence=>4
,p_column_heading=>'Telefono'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(180215994574062921)
,p_query_column_id=>5
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>5
,p_column_heading=>'Editar'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:$s(''P112_ID_TEL'',''#ID_TELEFONO#'');javascript:openModal(''TEL_ID''); $("#TEL_ID").trigger("apexrefresh");'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(180215895587062920)
,p_plug_name=>unistr('Actualizar Tel\00E9fono ')
,p_region_name=>'TEL_ID'
,p_parent_plug_id=>wwv_flow_api.id(178158158427038561)
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size480x320'
,p_plug_template=>wwv_flow_api.id(154191258258688908)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(186204155828847853)
,p_plug_name=>unistr('Agregar Tel\00E9fono ')
,p_region_name=>'NEWTEL_ID'
,p_parent_plug_id=>wwv_flow_api.id(178158158427038561)
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size480x320'
,p_plug_template=>wwv_flow_api.id(154191258258688908)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(178158734041038566)
,p_name=>'Correos para Notificaciones'
,p_parent_plug_id=>wwv_flow_api.id(171608724738930424)
,p_template=>wwv_flow_api.id(154198847510688906)
,p_display_sequence=>70
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_region_attributes=>'style="height: 300px"'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_CORREO_NOTIFICA,',
'       ID_CONTRIBUYENTE,',
'       CORREO_NOTIFICA,',
'       CODIGO_ESTADO',
'  from CORREO_NOTIFICACIONES',
'  where ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE',
'  and   CODIGO_ESTADO = ''AC'''))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(154225098567688891)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(178158790453038567)
,p_query_column_id=>1
,p_column_alias=>'ID_CORREO_NOTIFICA'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(180215662755062918)
,p_query_column_id=>2
,p_column_alias=>'ID_CONTRIBUYENTE'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(180215837010062919)
,p_query_column_id=>3
,p_column_alias=>'CORREO_NOTIFICA'
,p_column_display_sequence=>3
,p_column_heading=>'Correo'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(234074175699206219)
,p_query_column_id=>4
,p_column_alias=>'CODIGO_ESTADO'
,p_column_display_sequence=>4
,p_column_heading=>'Estado'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(179410871321546613)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(180216809842062929)
,p_query_column_id=>5
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>5
,p_column_heading=>'Editar'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:$s(''P112_NEW_CORREO'',''#CORREO_NOTIFICA#'');javascript:$s(''P112_ID_CORREO'',''#ID_CORREO_NOTIFICA#'');javascript:openModal(''ID_CORREO''); $("#ID_CORREO").trigger("apexrefresh");'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_column_alignment=>'CENTER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(180216740300062928)
,p_plug_name=>'Actualizar Correos'
,p_region_name=>'ID_CORREO'
,p_parent_plug_id=>wwv_flow_api.id(178158734041038566)
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size480x320'
,p_plug_template=>wwv_flow_api.id(154191258258688908)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(186205017476847861)
,p_plug_name=>'Agregar Correos'
,p_region_name=>'ID_CORREONEW'
,p_parent_plug_id=>wwv_flow_api.id(178158734041038566)
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size480x320'
,p_plug_template=>wwv_flow_api.id(154191258258688908)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(183625243344852826)
,p_name=>'Tipo Ventas'
,p_parent_plug_id=>wwv_flow_api.id(171608724738930424)
,p_template=>wwv_flow_api.id(154198847510688906)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_VENTAS,',
'       ID_CONTRIBUYENTE,',
'       ID_TIPO_VENTAS',
'  from VENTAS_X_MAESTRO_CONTRIBU',
'  where ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE'))
,p_display_when_condition=>'P112_TIPO_INSCRIPCION'
,p_display_when_cond2=>'IR'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(154225098567688891)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(183625274180852827)
,p_query_column_id=>1
,p_column_alias=>'ID_VENTAS'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(183625573218852830)
,p_query_column_id=>2
,p_column_alias=>'ID_CONTRIBUYENTE'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(183625471666852829)
,p_query_column_id=>3
,p_column_alias=>'ID_TIPO_VENTAS'
,p_column_display_sequence=>2
,p_column_heading=>'Tipo Ventas'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(161408845678960746)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(192276891235450542)
,p_query_column_id=>4
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>4
,p_column_heading=>'Editar'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:$s(''P112_ID_VENTA'',''#ID_VENTAS#'');javascript:openModal(''VENTA''); $("#VENTA").trigger("apexrefresh");'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(192277037893450543)
,p_plug_name=>'Actualizar Tipo venta'
,p_region_name=>'VENTA'
,p_parent_plug_id=>wwv_flow_api.id(183625243344852826)
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size480x320'
,p_plug_template=>wwv_flow_api.id(154191258258688908)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(192277631031450549)
,p_plug_name=>'Agregar Tipo venta'
,p_region_name=>'NUEVA_VENTA'
,p_parent_plug_id=>wwv_flow_api.id(183625243344852826)
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size480x320'
,p_plug_template=>wwv_flow_api.id(154191258258688908)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(172409960603123144)
,p_plug_name=>unistr('Informaci\00F3n Apoderados')
,p_parent_plug_id=>wwv_flow_api.id(169242037425244047)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(169242109070244048)
,p_name=>'Apoderados'
,p_parent_plug_id=>wwv_flow_api.id(172409960603123144)
,p_template=>wwv_flow_api.id(154198847510688906)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_APODERADO,',
'       ID_CONTRIBUYENTE,',
'       ID_TIPO_APODERADO,',
'       NOMBRE_APODERADO,',
'       CEDULA_APODERADO,',
'       CORREO_APODERADO,',
'       ID_TIPO_IMPUESTO,',
'       INDICA_AUTORIZO,',
'       FECHA_INICIO_AUTORIZA,',
'       FECHA_FIN_AUTORIZA',
'  from APODERADOS',
'  where ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE',
'  and  ID_TIPO_APODERADO IS NOT NULL',
'  and  FECHA_FIN_AUTORIZA IS NULL',
'  and  INDICA_AUTORIZO = ''A''',
'  and  CODIGO_ESTADO = ''AC'''))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(154225098567688891)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(172409007061123134)
,p_query_column_id=>1
,p_column_alias=>'ID_APODERADO'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(172409077953123135)
,p_query_column_id=>2
,p_column_alias=>'ID_CONTRIBUYENTE'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(172409189987123136)
,p_query_column_id=>3
,p_column_alias=>'ID_TIPO_APODERADO'
,p_column_display_sequence=>3
,p_column_heading=>'Tipo Apoderado'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(161507669448901775)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(172409312903123137)
,p_query_column_id=>4
,p_column_alias=>'NOMBRE_APODERADO'
,p_column_display_sequence=>4
,p_column_heading=>'Nombre'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(172409403726123138)
,p_query_column_id=>5
,p_column_alias=>'CEDULA_APODERADO'
,p_column_display_sequence=>5
,p_column_heading=>unistr('C\00E9dula ')
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(172409502148123139)
,p_query_column_id=>6
,p_column_alias=>'CORREO_APODERADO'
,p_column_display_sequence=>6
,p_column_heading=>'Correo'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_display_when_condition=>'P112_TIPO_INSCRIPCION'
,p_display_when_condition2=>'ANRI'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(172409598292123140)
,p_query_column_id=>7
,p_column_alias=>'ID_TIPO_IMPUESTO'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(172409714986123141)
,p_query_column_id=>8
,p_column_alias=>'INDICA_AUTORIZO'
,p_column_display_sequence=>8
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(172409833201123142)
,p_query_column_id=>9
,p_column_alias=>'FECHA_INICIO_AUTORIZA'
,p_column_display_sequence=>9
,p_column_heading=>unistr('Fecha Inicio Autorizaci\00F3n ')
,p_use_as_row_header=>'N'
,p_column_format=>'DD/MM/YYYY'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(172409884492123143)
,p_query_column_id=>10
,p_column_alias=>'FECHA_FIN_AUTORIZA'
,p_column_display_sequence=>10
,p_column_heading=>unistr('Fecha Fin Autorizaci\00F3n')
,p_use_as_row_header=>'N'
,p_column_format=>'DD/MM/YYYY'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'NEVER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(172411199593123156)
,p_query_column_id=>11
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>11
,p_column_heading=>'Inactivar'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:$s(''P112_ID_APODERADO'',''#ID_APODERADO#'');javascript:openModal(''APO_ID''); $("#APO_ID").trigger("apexrefresh");'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P112_VAL_CANT_APO'
,p_display_when_condition2=>'N'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(172411596331123160)
,p_plug_name=>'Inactivar Apoderado'
,p_region_name=>'APO_ID'
,p_parent_plug_id=>wwv_flow_api.id(169242109070244048)
,p_region_template_options=>'#DEFAULT#:js-dialog-size480x320:t-Form--large'
,p_plug_template=>wwv_flow_api.id(154191258258688908)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(174043435122863231)
,p_plug_name=>'Agregar Apoderado'
,p_region_name=>'AGREGAR_APO_ID'
,p_parent_plug_id=>wwv_flow_api.id(169242109070244048)
,p_region_template_options=>'#DEFAULT#:js-dialog-size720x480'
,p_plug_template=>wwv_flow_api.id(154191258258688908)
,p_plug_display_sequence=>50
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(189980202214808218)
,p_name=>unistr('Autorizaci\00F3n Uso Firma Digital a Terceros (Autorizados por Apoderado/ Due\00F1o)')
,p_parent_plug_id=>wwv_flow_api.id(172409960603123144)
,p_template=>wwv_flow_api.id(154198847510688906)
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_APODERADO,',
'       ID_CONTRIBUYENTE,',
'       ID_TIPO_APODERADO,',
'       NOMBRE_APODERADO,',
'       CEDULA_APODERADO,',
'       CORREO_APODERADO,',
'       --ID_TIPO_IMPUESTO,',
'       INDICA_AUTORIZO,',
'       FECHA_INICIO_AUTORIZA,',
'       FECHA_FIN_AUTORIZA',
'  from APODERADOS',
'  where ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE',
'  and   ID_TIPO_APODERADO IS NULL',
'  and  FECHA_FIN_AUTORIZA IS NULL ',
'  and  INDICA_AUTORIZO IN (''T'')',
'  and  CODIGO_ESTADO = ''AC'''))
,p_display_when_condition=>'P112_TIPO_INSCRIPCION'
,p_display_when_cond2=>'IR'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(154225098567688891)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(189980528678808221)
,p_query_column_id=>1
,p_column_alias=>'ID_APODERADO'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(189980595221808222)
,p_query_column_id=>2
,p_column_alias=>'ID_CONTRIBUYENTE'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(189980690570808223)
,p_query_column_id=>3
,p_column_alias=>'ID_TIPO_APODERADO'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(189980770127808224)
,p_query_column_id=>4
,p_column_alias=>'NOMBRE_APODERADO'
,p_column_display_sequence=>4
,p_column_heading=>'Nombre'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(189980897885808225)
,p_query_column_id=>5
,p_column_alias=>'CEDULA_APODERADO'
,p_column_display_sequence=>5
,p_column_heading=>unistr('C\00E9dula ')
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(189980994095808226)
,p_query_column_id=>6
,p_column_alias=>'CORREO_APODERADO'
,p_column_display_sequence=>6
,p_column_heading=>'Correo'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(189981188051808228)
,p_query_column_id=>7
,p_column_alias=>'INDICA_AUTORIZO'
,p_column_display_sequence=>7
,p_column_heading=>'Indica Autorizo'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>unistr('STATIC:Autorizaci\00F3n Uso Firma Digital;F,Autorizaci\00F3n a terceras personas;T')
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(189981284776808229)
,p_query_column_id=>8
,p_column_alias=>'FECHA_INICIO_AUTORIZA'
,p_column_display_sequence=>8
,p_column_heading=>unistr('Fecha Inicio Autorizaci\00F3n ')
,p_use_as_row_header=>'N'
,p_column_format=>'DD/MM/YYYY'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(189981411233808230)
,p_query_column_id=>9
,p_column_alias=>'FECHA_FIN_AUTORIZA'
,p_column_display_sequence=>9
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>108
,p_default_id_offset=>149139848948344617
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(189980385504808220)
,p_query_column_id=>10
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>11
,p_column_heading=>'Inactivar'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:$s(''P112_ID_APO_TER'',''#ID_APODERADO#'');javascript:openModal(''AUT_ID''); $("#AUT_ID").trigger("apexrefresh");'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_column_alignment=>'CENTER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(261066878226918819)
,p_query_column_id=>11
,p_column_alias=>'DERIVED$02'
,p_column_display_sequence=>10
,p_column_heading=>'Impuestos'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:208:&SESSION.::&DEBUG.::P208_ID_APODERADO:#ID_APODERADO#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_column_alignment=>'CENTER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(192278710945450560)
,p_plug_name=>'Mensaje'
,p_parent_plug_id=>wwv_flow_api.id(189980202214808218)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>unistr('En mi condici\00F3n de Apoderado/Due\00F1o con facultades para otorgar el poder especial que se adjunta, autorizo a las personas abajo indicadas en el apartado \201CAutorizaci\00F3n Uso Firma Digital a Terceros (Autorizados por Apoderado/ Due\00F1o)\201D, para que firmen di')
||unistr('gitalmente en mi nombre, cualquier declaraci\00F3n jurada de impuestos sobre pasajes internacionales que recauda mi representada a favor del ICT, de conformidad con la Ley N\00B08454 de Certificados, Firmas Digitales y Documentos Electr\00F3nicos, y su Reglament')
||'o.'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(194259855309050360)
,p_plug_name=>unistr('Autorizaci\00F3n Uso Firma Digital en declaraciones juradas (Apoderado o Due\00F1o)')
,p_parent_plug_id=>wwv_flow_api.id(172409960603123144)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_source=>unistr('El suscrito en mi condici\00F3n de Due\00F1o/Apoderado con facultades solicito firmar digitalmente las declaraciones juradas de impuestos sobre pasajes internacionales que recauda mi representada a favor del ICT. De conformidad con la Ley N\00B08454 de Certifica')
||unistr('dos, Firmas Digitales y Documentos Electr\00F3nicos, y su Reglamento')
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P112_TIPO_INSCRIPCION'
,p_plug_display_when_cond2=>'IR'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(172410105887123145)
,p_name=>unistr('Autorizaci\00F3n Uso Firma Digital en declaraciones juradas (Apoderado o Due\00F1o)')
,p_parent_plug_id=>wwv_flow_api.id(194259855309050360)
,p_template=>wwv_flow_api.id(154198847510688906)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID_APODERADO,',
'       ID_CONTRIBUYENTE,',
'       ID_TIPO_APODERADO,',
'       NOMBRE_APODERADO,',
'       CEDULA_APODERADO,',
'       CORREO_APODERADO,',
'       --ID_TIPO_IMPUESTO,',
'       INDICA_AUTORIZO,',
'       FECHA_INICIO_AUTORIZA,',
'       FECHA_FIN_AUTORIZA',
'  from APODERADOS',
'  where ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE',
'  and   ID_TIPO_APODERADO IS NULL',
'  and  FECHA_FIN_AUTORIZA IS NULL ',
'  and  INDICA_AUTORIZO IN (''F'')',
'  and  CODIGO_ESTADO = ''AC'''))
,p_display_when_condition=>'P112_TIPO_INSCRIPCION'
,p_display_when_cond2=>'IR'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(154225098567688891)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(172410199953123146)
,p_query_column_id=>1
,p_column_alias=>'ID_APODERADO'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(172410315089123147)
,p_query_column_id=>2
,p_column_alias=>'ID_CONTRIBUYENTE'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(172410372188123148)
,p_query_column_id=>3
,p_column_alias=>'ID_TIPO_APODERADO'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(172410528747123149)
,p_query_column_id=>4
,p_column_alias=>'NOMBRE_APODERADO'
,p_column_display_sequence=>4
,p_column_heading=>'Nombre'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(172410584086123150)
,p_query_column_id=>5
,p_column_alias=>'CEDULA_APODERADO'
,p_column_display_sequence=>5
,p_column_heading=>unistr('C\00E9dula ')
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(172410715437123151)
,p_query_column_id=>6
,p_column_alias=>'CORREO_APODERADO'
,p_column_display_sequence=>6
,p_column_heading=>'Correo'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(172410909919123153)
,p_query_column_id=>7
,p_column_alias=>'INDICA_AUTORIZO'
,p_column_display_sequence=>7
,p_column_heading=>'Indica Autorizo'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>unistr('STATIC:Autorizaci\00F3n Uso Firma Digital;F,Autorizaci\00F3n a terceras personas;T')
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(172410952318123154)
,p_query_column_id=>8
,p_column_alias=>'FECHA_INICIO_AUTORIZA'
,p_column_display_sequence=>8
,p_column_heading=>unistr('Fecha Inicio Autorizaci\00F3n ')
,p_use_as_row_header=>'N'
,p_column_format=>'DD/MM/YYYY'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(172411123077123155)
,p_query_column_id=>9
,p_column_alias=>'FECHA_FIN_AUTORIZA'
,p_column_display_sequence=>9
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(172411262932123157)
,p_query_column_id=>10
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>11
,p_column_heading=>'Inactivar'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:$s(''P112_ID_APO_TER'',''#ID_APODERADO#'');javascript:openModal(''AUT_ID''); $("#AUT_ID").trigger("apexrefresh");'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P112_VAL_CANT_APO_FIRM'
,p_display_when_condition2=>'N'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(261066836921918818)
,p_query_column_id=>11
,p_column_alias=>'DERIVED$02'
,p_column_display_sequence=>10
,p_column_heading=>'Impuestos'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:208:&SESSION.::&DEBUG.::P208_ID_APODERADO:#ID_APODERADO#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_column_alignment=>'CENTER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(172411700385123161)
,p_plug_name=>unistr('Inactivar Autorizaci\00F3n Uso Firma Digital')
,p_region_name=>'AUT_ID'
,p_parent_plug_id=>wwv_flow_api.id(172410105887123145)
,p_region_template_options=>'#DEFAULT#:js-dialog-size480x320'
,p_plug_template=>wwv_flow_api.id(154191258258688908)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(174044672926863244)
,p_plug_name=>unistr('Agregar Autorizaci\00F3n Uso Firma Digital')
,p_region_name=>'AGREGAR_APOTERC_ID'
,p_parent_plug_id=>wwv_flow_api.id(172410105887123145)
,p_region_template_options=>'#DEFAULT#:js-dialog-size720x480'
,p_plug_template=>wwv_flow_api.id(154191258258688908)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(174045417888863251)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(174044672926863244)
,p_button_name=>'BTN_GUARDA_APO_TERC'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(186204505915847856)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(186204155828847853)
,p_button_name=>'BTN_INSERTAR_TEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Agregar'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(186205337706847864)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(186205017476847861)
,p_button_name=>'BTN_INSERTAR_CORREO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Agregar'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(192277899808450552)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(192277631031450549)
,p_button_name=>'BTN_GUARDAR_NUEVA_VENTA'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(230636292977413651)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(218774368162933966)
,p_button_name=>'BTN_GUARDAR_IMP'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(231653866239221420)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(230637816555413666)
,p_button_name=>'BTN_INACTIVA_IMPUESTO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Inactivar Impuesto'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(180216272790062924)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(180215895587062920)
,p_button_name=>'BTN_GUARDAR_TEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(180217111922062932)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(180216740300062928)
,p_button_name=>'BTN_GUARDAR_CORREO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Actualizar'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(232312378728278367)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(180216740300062928)
,p_button_name=>'BTN_INACTIVAR_CORREO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Inactivar'
,p_button_position=>'BELOW_BOX'
,p_button_condition=>'P112_CANT_CORREOS'
,p_button_condition2=>'S'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_button_css_classes=>'u-color-39'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(218773350592933956)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(218772808805933950)
,p_button_name=>'BTN_GUARDAR_REP_LEG'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(192277325734450546)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(192277037893450543)
,p_button_name=>'BTN_GUARDAR_VENTA'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(171648032579930382)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(171608724738930424)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P112_ID_CONTRIBUYENTE'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(171646779063930386)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(171608724738930424)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_image_alt=>'Regresar'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-double-left'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(171648438274930381)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(171608724738930424)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Crear'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition_type=>'NEVER'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(171647594283930382)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(171608724738930424)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_image_alt=>'Eliminar'
,p_button_position=>'REGION_TEMPLATE_DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition_type=>'NEVER'
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(186204614223847857)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(178158158427038561)
,p_button_name=>'BTN_AGREGAR_TEL'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Agregar Nuevo'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'javascript:openModal(''NEWTEL_ID''); $("#NEWTEL_ID").trigger("apexrefresh");'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(186204910744847860)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(178158734041038566)
,p_button_name=>'BTN_AGREGAR_CORREO'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Agregar Nuevo'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'javascript:openModal(''ID_CORREONEW''); $("#ID_CORREONEW").trigger("apexrefresh");'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(192277538259450548)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(183625243344852826)
,p_button_name=>'BTN_AGREGAR_NUEVA_VENTA'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Agregar Nuevo'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'javascript:openModal(''NUEVA_VENTA''); $("#NUEVA_VENTA").trigger("apexrefresh");'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(172412219691123166)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(172411596331123160)
,p_button_name=>'BTN_INACTIVA_APO'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Inactivar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(174043122803863228)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(172411700385123161)
,p_button_name=>'BTN_INACTIVA_TERC'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Inactivar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(174043993104863237)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_api.id(174043435122863231)
,p_button_name=>'BTN_GUARDA_APO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'REGION_TEMPLATE_NEXT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(172411440658123158)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(169242109070244048)
,p_button_name=>'BTN_AGREGAR_APO'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Agregar Nuevo'
,p_button_position=>'TOP'
,p_button_redirect_url=>'javascript:openModal(''AGREGAR_APO_ID''); $("#AGREGAR_APO_ID").trigger("apexrefresh");'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(172411534814123159)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(172410105887123145)
,p_button_name=>'BTN_AGREGAR_FIRMA'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Agregar Nuevo'
,p_button_position=>'TOP'
,p_button_redirect_url=>'javascript:$s(''P112_TIPO_AUT'',''F'');javascript:openModal(''AGREGAR_APOTERC_ID''); $("#AGREGAR_APOTERC_ID").trigger("apexrefresh");'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(189980293615808219)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(189980202214808218)
,p_button_name=>'BTN_AGREGAR_TERCERO'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Agregar Nuevo'
,p_button_position=>'TOP'
,p_button_redirect_url=>'javascript:$s(''P112_TIPO_AUT'',''T'');javascript:openModal(''AGREGAR_APOTERC_ID''); $("#AGREGAR_APOTERC_ID").trigger("apexrefresh");'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(218772705638933949)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(172408378443123128)
,p_button_name=>'BTN_ACT_REPRE_LEGAL'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Actualizar Rep. Legal'
,p_button_position=>'TOP'
,p_button_redirect_url=>'javascript:$s(''P112_CORREO_REP_LEG'',''&P112_CORREO_REPRE_LEGAL.'');javascript:$s(''P112_CED_REP_LEG'',''&P112_CEDULA_REPRE_LEGAL.'');javascript:$s(''P112_NOM_REP_LEG'',''&P112_NOMBRE_REPRE_LEGAL.'');javascript:openModal(''ID_REP_LEG''); $("#ID_REP_LEG").trigger("apexrefresh");'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(218774294800933965)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(178157572055038555)
,p_button_name=>'BTN_AGREGAR_IMPUESTO'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Agregar Impuesto'
,p_button_position=>'TOP'
,p_button_redirect_url=>'javascript:openModal(''ID_IMPUESTO''); $("#ID_IMPUESTO").trigger("apexrefresh");'
,p_button_condition=>'P112_TIPO_CONTRIB'
,p_button_condition2=>'S'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(171648734575930381)
,p_branch_name=>'Go To Page 112'
,p_branch_action=>'f?p=&APP_ID.:112:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(171648032579930382)
,p_branch_sequence=>1
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(192572626667360566)
,p_branch_name=>'Go To Page 126'
,p_branch_action=>'f?p=&APP_ID.:126:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>11
,p_branch_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_branch_condition=>'P112_BRANCH'
,p_branch_condition_text=>'S'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171608957431930417)
,p_name=>'P112_ID_CONTRIBUYENTE'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(169242203248244049)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_source=>'ID_CONTRIBUYENTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171609436715930411)
,p_name=>'P112_NOMBRE_ENTIDAD'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(169242203248244049)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_prompt=>'Nombre de la entidad:'
,p_source=>'NOMBRE_ENTIDAD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171609794888930407)
,p_name=>'P112_ID_TIPO_IDENTIFICACION'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(169242203248244049)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_prompt=>unistr('Tipo Identificaci\00F3n:')
,p_source=>'ID_TIPO_IDENTIFICACION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NOMBRE_IDENTIFICA, ID_TIPO_IDENTIFICACION FROM TIPO_IDENTIFICACION',
'WHERE ID_TIPO_IDENTIFICACION = :P112_ID_TIPO_IDENTIFICACION'))
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171610181348930406)
,p_name=>'P112_RAZON_SOCIAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(169242203248244049)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_prompt=>unistr('Raz\00F3n Social:')
,p_source=>'RAZON_SOCIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P112_ID_TIPO_IDENTIFICACION'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171610550798930406)
,p_name=>'P112_PERSONA_FISICA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(169242203248244049)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_prompt=>'Persona Fisica:'
,p_source=>'PERSONA_FISICA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>100
,p_display_when=>'P112_VALIDA_PERS_FISICA'
,p_display_when2=>'S'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171611048849930406)
,p_name=>'P112_CEDULA_JURIDICA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(169242203248244049)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_prompt=>unistr('Documento Identificaci\00F3n:')
,p_source=>'CEDULA_JURIDICA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P112_CEDULA_JURIDICA'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171611394811930406)
,p_name=>'P112_CEDULA_FISICA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(169242203248244049)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_prompt=>unistr('Documento Identificaci\00F3n:')
,p_source=>'CEDULA_FISICA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P112_CEDULA_FISICA'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171611843686930405)
,p_name=>'P112_ID_TIPO_CONTRIBUYENTE'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(169242203248244049)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_prompt=>'Tipo Contribuyente:'
,p_source=>'ID_TIPO_CONTRIBUYENTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION,ID_TIPO_CONTRIBUYENTE',
'FROM   TIPO_CONTRIBUYENTE',
'WHERE CODIGO_ESTADO = ''AC''',
'AND IND_TIPO_INSCRIP IN (:P112_TIPO_INSCRIPCION)',
'AND  ID_TIPO_CONTRIBUYENTE = :P112_ID_TIPO_CONTRIBUYENTE'))
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171612237748930405)
,p_name=>'P112_CODIGO_IATA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(169242203248244049)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_prompt=>unistr('C\00F3digo Iata:')
,p_source=>'CODIGO_IATA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P112_VAL_COD_IATA'
,p_display_when2=>'S'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171613024977930405)
,p_name=>'P112_FECHA_INICIO_OPERA'
,p_source_data_type=>'DATE'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(169242203248244049)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_prompt=>'Inicio Operaciones:'
,p_format_mask=>'DD/MM/YYYY'
,p_source=>'FECHA_INICIO_OPERA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P112_TIPO_INSCRIPCION'
,p_display_when2=>'ANRI'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171613382934930405)
,p_name=>'P112_DIRECCION_ENTIDAD'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(169242342984244050)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_prompt=>unistr('Direcci\00F3n:')
,p_source=>'DIRECCION_ENTIDAD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>70
,p_cMaxlength=>1000
,p_cHeight=>4
,p_display_when=>'P112_TIPO_INSCRIPCION'
,p_display_when2=>'IVC'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171613788153930404)
,p_name=>'P112_ID_PROVINCIA_ENTIDAD'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(169242342984244050)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_prompt=>'Provincia:'
,p_source=>'ID_PROVINCIA_ENTIDAD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT DESCRIPCION, ID FROM PROVINCIAS@consulta_ictx'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when=>'P112_TIPO_INSCRIPCION'
,p_display_when2=>'ANRI'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>108
,p_default_id_offset=>149139848948344617
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171614238858930404)
,p_name=>'P112_ID_CANTON_ENTIDAD'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(169242342984244050)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_prompt=>unistr('Cant\00F3n:')
,p_source=>'ID_CANTON_ENTIDAD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT DESCRIPCION, ID FROM CANTONES@consulta_ictx WHERE PROV_ID = :P112_ID_PROVINCIA_ENTIDAD'
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P112_ID_PROVINCIA_ENTIDAD'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_display_when=>'P112_TIPO_INSCRIPCION'
,p_display_when2=>'ANRI'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171614553241930404)
,p_name=>'P112_ID_DISTRITO_ENTIDAD'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(169242342984244050)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_prompt=>'Distrito:'
,p_source=>'ID_DISTRITO_ENTIDAD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION, ID ',
'FROM DISTRITOS@consulta_ictx ',
'WHERE PROV_ID = :P112_ID_PROVINCIA_ENTIDAD',
'AND CANTON_ID = :P112_ID_CANTON_ENTIDAD'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P112_ID_PROVINCIA_ENTIDAD,P112_ID_CANTON_ENTIDAD'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P112_TIPO_INSCRIPCION'
,p_display_when2=>'ANRI'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171614949623930403)
,p_name=>'P112_DIRECCION_NOTIFICA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_api.id(169243278177244060)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_prompt=>unistr('Direcci\00F3n:')
,p_source=>'DIRECCION_NOTIFICA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>70
,p_cMaxlength=>800
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171615371966930403)
,p_name=>'P112_ID_PROVINCIA_NOTIFICA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_api.id(169243278177244060)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_prompt=>'Provincia:'
,p_source=>'ID_PROVINCIA_NOTIFICA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT DESCRIPCION, ID FROM PROVINCIAS@consulta_ictx'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171615761166930403)
,p_name=>'P112_ID_CANTON_NOTIFICA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_api.id(169243278177244060)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_prompt=>unistr('Cant\00F3n:')
,p_source=>'ID_CANTON_NOTIFICA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT DESCRIPCION, ID FROM CANTONES@consulta_ictx WHERE PROV_ID = :P112_ID_PROVINCIA_NOTIFICA'
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P112_ID_PROVINCIA_NOTIFICA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171616247340930403)
,p_name=>'P112_ID_DISTRITO_NOTIFICA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_api.id(169243278177244060)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_prompt=>'Distrito:'
,p_source=>'ID_DISTRITO_NOTIFICA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION, ID ',
'FROM DISTRITOS@consulta_ictx ',
'WHERE PROV_ID = :P112_ID_PROVINCIA_NOTIFICA',
'AND CANTON_ID = :P112_ID_CANTON_NOTIFICA'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P112_ID_PROVINCIA_NOTIFICA,P112_ID_CANTON_NOTIFICA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171616582719930403)
,p_name=>'P112_CEDULA_GERENTE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_api.id(172408322532123127)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_prompt=>unistr('C\00E9dula:')
,p_source=>'CEDULA_GERENTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>25
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171616982993930402)
,p_name=>'P112_NOMBRE_GERENTE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_api.id(172408322532123127)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_prompt=>'Nombre:'
,p_source=>'NOMBRE_GERENTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>80
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171617446338930402)
,p_name=>'P112_CORREO_GERENTE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_api.id(172408322532123127)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_prompt=>'Correo:'
,p_source=>'CORREO_GERENTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171617755182930402)
,p_name=>'P112_NOMBRE_REPRE_LEGAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_api.id(172408378443123128)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_prompt=>'Nombre:'
,p_source=>'NOMBRE_REPRE_LEGAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171618168725930402)
,p_name=>'P112_CEDULA_REPRE_LEGAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_api.id(172408378443123128)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_prompt=>unistr('C\00E9dula:')
,p_source=>'CEDULA_REPRE_LEGAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171618589861930402)
,p_name=>'P112_CORREO_REPRE_LEGAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_api.id(172408378443123128)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_prompt=>'Correo:'
,p_source=>'CORREO_REPRE_LEGAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P112_TIPO_INSCRIPCION'
,p_display_when2=>'ANRI'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171618961557930402)
,p_name=>'P112_CODIGO_ESTADO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(169242203248244049)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_source=>'CODIGO_ESTADO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171619413385930401)
,p_name=>'P112_FECHA_INSCRIPCION'
,p_source_data_type=>'DATE'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(169242203248244049)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_prompt=>unistr('Fecha Inscripci\00F3n:')
,p_format_mask=>'DD/MM/YYYY'
,p_source=>'FECHA_INSCRIPCION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171619793297930401)
,p_name=>'P112_FECHA_CESE_OPERA'
,p_source_data_type=>'DATE'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_api.id(171608724738930424)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_source=>'FECHA_CESE_OPERA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171620245082930401)
,p_name=>'P112_FECHA_INICIO_VENTAS'
,p_source_data_type=>'DATE'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_api.id(171608724738930424)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_source=>'FECHA_INICIO_VENTAS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171620553976930401)
,p_name=>'P112_OBSERVA_EMPRESA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_api.id(171608724738930424)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_source=>'OBSERVA_EMPRESA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171620994009930401)
,p_name=>'P112_OBSERVA_ADM_TRIBUTA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_api.id(171608724738930424)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_source=>'OBSERVA_ADM_TRIBUTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171621401432930400)
,p_name=>'P112_ID_MODALIDAD'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>320
,p_item_plug_id=>wwv_flow_api.id(171608724738930424)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_source=>'ID_MODALIDAD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171621759814930400)
,p_name=>'P112_CODIGO_FUENTE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>330
,p_item_plug_id=>wwv_flow_api.id(171608724738930424)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_source=>'CODIGO_FUENTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171622224182930400)
,p_name=>'P112_CEDULA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>340
,p_item_plug_id=>wwv_flow_api.id(171608724738930424)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_source=>'CEDULA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171622624459930400)
,p_name=>'P112_CODIGO_EMPLEADO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>350
,p_item_plug_id=>wwv_flow_api.id(171608724738930424)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_source=>'CODIGO_EMPLEADO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171622993299930400)
,p_name=>'P112_ID_DEUDOR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(169242203248244049)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_prompt=>unistr('C\00F3digo Registro:')
,p_source=>'ID_DEUDOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171623352098930398)
,p_name=>'P112_FECHA_SUSCRITO'
,p_source_data_type=>'DATE'
,p_item_sequence=>370
,p_item_plug_id=>wwv_flow_api.id(171608724738930424)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_source=>'FECHA_SUSCRITO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171623774031930398)
,p_name=>'P112_LUGAR_SUSCRITO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>380
,p_item_plug_id=>wwv_flow_api.id(171608724738930424)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_source=>'LUGAR_SUSCRITO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171624223101930398)
,p_name=>'P112_ID_TIPO_PUESTO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>390
,p_item_plug_id=>wwv_flow_api.id(171608724738930424)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_source=>'ID_TIPO_PUESTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171624613626930398)
,p_name=>'P112_ID_CHARTER'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>400
,p_item_plug_id=>wwv_flow_api.id(171608724738930424)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_source=>'ID_CHARTER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171625021008930397)
,p_name=>'P112_NUM_EXPEDIENTE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>410
,p_item_plug_id=>wwv_flow_api.id(171608724738930424)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_source=>'NUM_EXPEDIENTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171625421943930397)
,p_name=>'P112_OTRA_ID'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>420
,p_item_plug_id=>wwv_flow_api.id(171608724738930424)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_source=>'OTRA_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171625766578930397)
,p_name=>'P112_PROPIETARIO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>430
,p_item_plug_id=>wwv_flow_api.id(171608724738930424)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_source=>'PROPIETARIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171626244819930397)
,p_name=>'P112_DOMICILIO_FISCAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>440
,p_item_plug_id=>wwv_flow_api.id(171608724738930424)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_source=>'DOMICILIO_FISCAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171626553065930397)
,p_name=>'P112_RESPONSABLE_TRIBUTARIO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(169242203248244049)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_prompt=>'Encargado Reporte Semestral:'
,p_source=>'RESPONSABLE_TRIBUTARIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_display_when=>'P112_TIPO_INSCRIPCION'
,p_display_when2=>'ANRI'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171626982796930397)
,p_name=>'P112_SITIO_WEB'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>460
,p_item_plug_id=>wwv_flow_api.id(171608724738930424)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_source=>'SITIO_WEB'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171627395284930396)
,p_name=>'P112_HABITACIONES'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>470
,p_item_plug_id=>wwv_flow_api.id(171608724738930424)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_source=>'HABITACIONES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171627812323930396)
,p_name=>'P112_FECHA_INGRESO'
,p_source_data_type=>'DATE'
,p_item_sequence=>480
,p_item_plug_id=>wwv_flow_api.id(171608724738930424)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_source=>'FECHA_INGRESO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171628191524930396)
,p_name=>'P112_TIPO_PAGO_TARIFA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>490
,p_item_plug_id=>wwv_flow_api.id(171608724738930424)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_source=>'TIPO_PAGO_TARIFA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171628604982930396)
,p_name=>'P112_EMPLEO_TEMPORADA_BAJA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>500
,p_item_plug_id=>wwv_flow_api.id(171608724738930424)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_source=>'EMPLEO_TEMPORADA_BAJA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171628976461930396)
,p_name=>'P112_EMPLEO_TEMPORADA_ALTA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>510
,p_item_plug_id=>wwv_flow_api.id(171608724738930424)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_source=>'EMPLEO_TEMPORADA_ALTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171629410270930395)
,p_name=>'P112_ID_TIPO_SERVICIO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>520
,p_item_plug_id=>wwv_flow_api.id(171608724738930424)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_source=>'ID_TIPO_SERVICIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171629797290930395)
,p_name=>'P112_NUMERO_ESTRELLAS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>530
,p_item_plug_id=>wwv_flow_api.id(171608724738930424)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_source=>'NUMERO_ESTRELLAS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(171630168995930394)
,p_name=>'P112_ID_NUM_INSCRIPCION'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>540
,p_item_plug_id=>wwv_flow_api.id(171608724738930424)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_source=>'ID_NUM_INSCRIPCION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(172411778444123162)
,p_name=>'P112_NOM_APODERADO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(172411596331123160)
,p_prompt=>'Apoderado'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NOMBRE_APODERADO, ID_APODERADO',
'FROM APODERADOS ',
'WHERE ID_APODERADO = :P112_ID_APODERADO',
'--AND   ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE',
''))
,p_lov_cascade_parent_items=>'P112_ID_APODERADO'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(172411850543123163)
,p_name=>'P112_ID_APO_TER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(172411700385123161)
,p_display_as=>'NATIVE_HIDDEN'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(172412018380123164)
,p_name=>'P112_ID_APODERADO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(172411596331123160)
,p_display_as=>'NATIVE_HIDDEN'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174043159664863229)
,p_name=>'P112_NOM_APO_TERC'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(172411700385123161)
,p_prompt=>'Apoderado'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NOMBRE_APODERADO, ID_APODERADO',
'FROM APODERADOS ',
'WHERE ID_APODERADO = :P112_ID_APO_TER',
'--AND   ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE',
''))
,p_lov_cascade_parent_items=>'P112_ID_APO_TER'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174043513891863232)
,p_name=>'P112_ID_CONTRIBU'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(174043435122863231)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174043602619863233)
,p_name=>'P112_TIPO_APODERADO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(174043435122863231)
,p_prompt=>'Tipo:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_TIPO_APODERADO'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174043737055863234)
,p_name=>'P112_NOMBRE_APODERADO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(174043435122863231)
,p_prompt=>'Nombre:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174043839519863235)
,p_name=>'P112_CEDULA_APODERADO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(174043435122863231)
,p_prompt=>unistr('C\00E9dula: ')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_help_text=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174043936744863236)
,p_name=>'P112_CORREO_APODERADO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(174043435122863231)
,p_prompt=>'Correo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174044558622863243)
,p_name=>'P112_PODER_LEGAL_APO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(174043435122863231)
,p_prompt=>unistr('Adjuntar Personer\00EDa Jur\00EDdica:')
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_field_template=>wwv_flow_api.id(154259886985688872)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174045012678863247)
,p_name=>'P112_NOMBRE_APO_TERC'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(174044672926863244)
,p_prompt=>'Nombre:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174045055384863248)
,p_name=>'P112_CEDULA_APO_TERC'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(174044672926863244)
,p_prompt=>unistr('C\00E9dula: ')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174045171363863249)
,p_name=>'P112_CORREO_APO_TERC'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(174044672926863244)
,p_prompt=>'Correo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174045267248863250)
,p_name=>'P112_PODER_LEGAL_TERC'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(174044672926863244)
,p_prompt=>unistr('Personer\00EDa Jur\00EDdica:')
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_field_template=>wwv_flow_api.id(154259886985688872)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(174045957471863257)
,p_name=>'P112_TIPO_IMPUESTO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(174044672926863244)
,p_prompt=>'Tipo Impuesto:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'       ID_TIPO_IMPUESTO',
'FROM IMPUESTO_X_MAESTRO_CONTRIBUYE',
'WHERE ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE',
'AND   CODIGO_ESTADO = ''AC''',
'--AND   ID_TIPO_IMPUESTO NOT IN (SELECT ID_TIPO_IMPUESTO FROM IMPUESTO_X_MAESTRO_CONTRIBUYE WHERE ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(180216060623062922)
,p_name=>'P112_ID_TEL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(180215895587062920)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(180216168262062923)
,p_name=>'P112_NEW_TELEFONO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(180215895587062920)
,p_prompt=>unistr('Nuevo Tel\00E9fono:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(154259822246688872)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(180216909922062930)
,p_name=>'P112_ID_CORREO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(180216740300062928)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(180216955992062931)
,p_name=>'P112_NEW_CORREO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(180216740300062928)
,p_prompt=>'Correo Nuevo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(154259822246688872)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(180217503721062936)
,p_name=>'P112_TIPO_INSCRIPCION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(169242037425244047)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(180217568699062937)
,p_name=>'P112_NOM_ASISTENTE_CHARTER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(172408528637123129)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_prompt=>'Nombre:'
,p_source=>'NOM_ASISTENTE_CHARTER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>80
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>108
,p_default_id_offset=>149139848948344617
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(180217679995062938)
,p_name=>'P112_CEDULA_ASISTENTE_CHARTER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(172408528637123129)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_prompt=>'Cedula:'
,p_source=>'CEDULA_ASISTENTE_CHARTER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(180217844110062939)
,p_name=>'P112_CORREO_ASISTENTE_CHARTER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(172408528637123129)
,p_item_source_plug_id=>wwv_flow_api.id(171608724738930424)
,p_prompt=>'Correo:'
,p_source=>'CORREO_ASISTENTE_CHARTER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>40
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(183322225929575920)
,p_name=>'P112_CONTRIBUYENTE_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(169242203248244049)
,p_prompt=>'# Contribuyente:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(184055067712637628)
,p_name=>'P112_TIPO_AUT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(174044672926863244)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(184324714206021237)
,p_name=>'P112_NOMBRE_REGION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(169242037425244047)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(186204370044847855)
,p_name=>'P112_TELEFONO_NUEVO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(186204155828847853)
,p_prompt=>unistr('Nuevo Tel\00E9fono:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(154259822246688872)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(186204781726847859)
,p_name=>'P112_TIPO_TEL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(186204155828847853)
,p_prompt=>'Tipo Telefono:'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'TIPO_TELEFONO'
,p_field_template=>wwv_flow_api.id(154259735022688872)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'3'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(186205151154847863)
,p_name=>'P112_CORREO_NUEVO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(186205017476847861)
,p_prompt=>'Correo Nuevo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(154259822246688872)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(187061889442387132)
,p_name=>'P112_VALIDA_PERS_FISICA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(169242037425244047)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(192277145530450544)
,p_name=>'P112_ID_VENTA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(192277037893450543)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(192277204312450545)
,p_name=>'P112_ID_TIPO_VENTA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(192277037893450543)
,p_prompt=>'Nuevo Tipo Venta:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_TIPO_VENTA'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(154259822246688872)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(192277825585450551)
,p_name=>'P112_ID_TIPO_VENTA_NUEVA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(192277631031450549)
,p_prompt=>'Nuevo Tipo Venta:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_TIPO_VENTA'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(154259822246688872)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(192278565336450559)
,p_name=>'P112_VAL_CANT_APO_FIRM'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(169242037425244047)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(192278799995450561)
,p_name=>'P112_VAL_COD_IATA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(169242037425244047)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(192572659945360567)
,p_name=>'P112_BRANCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(172409960603123144)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(194259956041050361)
,p_name=>'P112_VAL_CANT_APO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(169242037425244047)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(218772919578933951)
,p_name=>'P112_NOM_REP_LEG'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(218772808805933950)
,p_prompt=>'Nombre:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(218772961062933952)
,p_name=>'P112_CED_REP_LEG'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(218772808805933950)
,p_prompt=>'Cedula:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(218773142188933953)
,p_name=>'P112_CORREO_REP_LEG'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(218772808805933950)
,p_prompt=>'Correo:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(218773185371933954)
,p_name=>'P112_ARC_REP_LEG1'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(218772808805933950)
,p_prompt=>'Cedula representante:'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(154259886985688872)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_11=>'.pdf'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(218773276028933955)
,p_name=>'P112_ARC_REP_LEG2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(218772808805933950)
,p_prompt=>unistr('Personer\00EDa jur\00EDdica:')
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(154259886985688872)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_11=>'.pdf'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(218773541356933957)
,p_name=>'P112_ARC_CED_APO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(174043435122863231)
,p_prompt=>'Cedula Apoderado:'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_field_template=>wwv_flow_api.id(154259886985688872)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(218774489817933967)
,p_name=>'P112_IMPUESTO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(218774368162933966)
,p_prompt=>'Tipo Impuesto:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'       ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P112_ID_TIPO_CONTRIBUYENTE',
'AND   CODIGO_ESTADO = ''AC''',
'AND   ID_TIPO_IMPUESTO NOT IN (SELECT ID_TIPO_IMPUESTO ',
'                               FROM IMPUESTO_X_MAESTRO_CONTRIBUYE ',
'                               WHERE ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE ',
'                               AND CODIGO_ESTADO = ''AC'')'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(154259950696688872)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(230636401074413652)
,p_name=>'P112_NOMBRE_ENCAR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(218774368162933966)
,p_prompt=>'Nombre Encargado:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(154259950696688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(230636511709413653)
,p_name=>'P112_CORREO_ENCAR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(218774368162933966)
,p_prompt=>'Correo Encargado:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(154259950696688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(230636571440413654)
,p_name=>'P112_CEDULA_ENCAR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(218774368162933966)
,p_prompt=>'Cedula Encargado:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(154259950696688872)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(230637895661413667)
,p_name=>'P112_ID_IMPUESTO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(230637816555413666)
,p_prompt=>'Impuesto'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'       ID_TIPO_IMPUESTO',
'FROM TIPO_IMPUESTO_CONTRIB',
'WHERE ID_TIPO_CONTRIB = :P112_ID_TIPO_CONTRIBUYENTE',
'AND   ID_TIPO_IMPUESTO IN (SELECT ID_TIPO_IMPUESTO FROM IMPUESTO_X_MAESTRO_CONTRIBUYE WHERE ID_CONTRIBUYENTE = :P112_ID_CONTRIBU AND CODIGO_ESTADO = ''AC'')'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(154259822246688872)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(231653737872221418)
,p_name=>'P112_TIPO_CONTRIB'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(169242037425244047)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(231653800343221419)
,p_name=>'P112_CANT_IMPUESTOS'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(169242037425244047)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(231654325513221424)
,p_name=>'P112_PODER_ESPECIAL'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(174044672926863244)
,p_prompt=>'Poder Especial:'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,.jpeg,.png"'
,p_field_template=>wwv_flow_api.id(154259886985688872)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(232312232077278365)
,p_name=>'P112_CANT_CORREOS'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(169242037425244047)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(261067021736918820)
,p_name=>'P112_TIPO_IMPUESTO_1'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(174044672926863244)
,p_prompt=>'Tipo Impuesto:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'       ID_TIPO_IMPUESTO',
'FROM IMPUESTO_X_MAESTRO_CONTRIBUYE',
'WHERE ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE',
'AND   CODIGO_ESTADO = ''AC''',
'--AND   ID_TIPO_IMPUESTO NOT IN (SELECT ID_TIPO_IMPUESTO FROM IMPUESTO_X_MAESTRO_CONTRIBUYE WHERE ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when=>'P112_CANT_IMP_CONTRIB'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(261067074426918821)
,p_name=>'P112_TIPO_IMPUESTO_2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(174044672926863244)
,p_prompt=>'Tipo Impuesto:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PKG_MAESTRO_CONTRIBUYENTE.RETORNA_DESCRIP_TIPO_IMPUESTO (ID_TIPO_IMPUESTO)NOM_IMPUESTO,',
'       ID_TIPO_IMPUESTO',
'FROM IMPUESTO_X_MAESTRO_CONTRIBUYE',
'WHERE ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE',
'AND   CODIGO_ESTADO = ''AC''',
'--AND   ID_TIPO_IMPUESTO NOT IN (SELECT ID_TIPO_IMPUESTO FROM IMPUESTO_X_MAESTRO_CONTRIBUYE WHERE ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE)'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when=>'P112_CANT_IMP_CONTRIB'
,p_display_when2=>'3'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(261067179464918822)
,p_name=>'P112_CANT_IMP_CONTRIB'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(169242037425244047)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(183322264819575921)
,p_validation_name=>'VAL_CORREO'
,p_validation_sequence=>10
,p_validation=>'P112_NEW_CORREO'
,p_validation2=>'@'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Correo no Valido... por favor verifique'
,p_validation_condition_type=>'NEVER'
,p_associated_item=>wwv_flow_api.id(180216955992062931)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(183322377339575922)
,p_validation_name=>'VAL_CORREO_APO'
,p_validation_sequence=>20
,p_validation=>'P112_CORREO_APODERADO'
,p_validation2=>'@'
,p_validation_type=>'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2'
,p_error_message=>'Correo no valida... por favor verifique'
,p_validation_condition=>'P112_CORREO_APODERADO'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(174043936744863236)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(183322494648575923)
,p_validation_name=>'VAL_CEDULA'
,p_validation_sequence=>30
,p_validation=>'P112_CEDULA_APODERADO'
,p_validation_type=>'ITEM_IS_ALPHANUMERIC'
,p_error_message=>unistr('Por favor ingresar el n\00FAmero de c\00E9dula sin espacios y sin guiones ejemplo (102220333)')
,p_validation_condition=>'P112_CEDULA_APODERADO'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(174043839519863235)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(184949281457269005)
,p_validation_name=>'VAL_NOM_ENCAR'
,p_validation_sequence=>40
,p_validation=>'P112_NOMBRE_ENCAR'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe indicar el nombre del encargado del impuesto.'
,p_validation_condition=>'P112_IMPUESTO'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(230636401074413652)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(184949340038269006)
,p_validation_name=>'VAL_CEDULA_ENCAR'
,p_validation_sequence=>50
,p_validation=>'P112_CEDULA_ENCAR'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe indicar la cedula del encargado del impuesto.'
,p_validation_condition=>'P112_IMPUESTO'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(230636571440413654)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(184949469346269007)
,p_validation_name=>'VAL_CORREO_ENCAR'
,p_validation_sequence=>60
,p_validation=>'P112_CORREO_ENCAR'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe indicar el correo del encargado del impuesto.'
,p_validation_condition=>'P112_IMPUESTO'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_api.id(230636511709413653)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(172412297909123167)
,p_name=>'DAC_INACTIVA_APO'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(172412219691123166)
,p_condition_element=>'P112_ID_APODERADO'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(174042126385863218)
,p_event_id=>wwv_flow_api.id(172412297909123167)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'UPDATE APODERADOS SET FECHA_FIN_AUTORIZA = sysdate,CODIGO_ESTADO = ''IA'',USUARIO_SIT = :APP_USER WHERE ID_APODERADO = :P112_ID_APODERADO;',
'commit;',
'END;'))
,p_attribute_02=>'P112_ID_APODERADO'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(174042193794863219)
,p_event_id=>wwv_flow_api.id(172412297909123167)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'El apoderado fue inactivado!!'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(174042550220863223)
,p_event_id=>wwv_flow_api.id(172412297909123167)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(229131161386598126)
,p_name=>'DAC_UPPER_RESP'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P112_RESPONSABLE_TRIBUTARIO'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(229131348095598127)
,p_event_id=>wwv_flow_api.id(229131161386598126)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P112_RESPONSABLE_TRIBUTARIO").val($("#P112_RESPONSABLE_TRIBUTARIO").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(229131425063598128)
,p_name=>'DAC_UPPER_DIRECCION'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P112_DIRECCION_ENTIDAD'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(229131512517598129)
,p_event_id=>wwv_flow_api.id(229131425063598128)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P112_DIRECCION_ENTIDAD").val($("#P112_DIRECCION_ENTIDAD").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(229131587913598130)
,p_name=>'DAC_UPPER_NOM_REP'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P112_NOM_REP_LEG'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(229131699812598131)
,p_event_id=>wwv_flow_api.id(229131587913598130)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P112_NOM_REP_LEG").val($("#P112_NOM_REP_LEG").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(229131800778598132)
,p_name=>'DAC_UPPER_NOM_APO'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P112_NOMBRE_APODERADO'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(229131921531598133)
,p_event_id=>wwv_flow_api.id(229131800778598132)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P112_NOMBRE_APODERADO").val($("#P112_NOMBRE_APODERADO").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(229132034251598134)
,p_name=>'DAC_UPPER_NOM_APO_TER'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P112_NOMBRE_APO_TERC'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(229132089310598135)
,p_event_id=>wwv_flow_api.id(229132034251598134)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P112_NOMBRE_APO_TERC").val($("#P112_NOMBRE_APO_TERC").val().toUpperCase());'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(231654427927221425)
,p_name=>'New'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P112_TIPO_AUT'
,p_condition_element=>'P112_TIPO_AUT'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'T'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(231654507682221426)
,p_event_id=>wwv_flow_api.id(231654427927221425)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P112_PODER_ESPECIAL'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(231654550705221427)
,p_event_id=>wwv_flow_api.id(231654427927221425)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P112_PODER_ESPECIAL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(171649630510930377)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_api.id(171608724738930424)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form 112-Datos Maestro Contribuyente'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(169241894349244046)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_DATOS_MC'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    vId_contribuyente NUMBER;',
'    vTipo_Contrib NUMBER;',
'    vTipo_Inscrip VARCHAR2(5);',
'    vTipo_Identifica NUMBER ;',
'    vCantApoFir NUMBER;',
'    vCantApo NUMBER;',
'    vCantImpuesto NUMBER;',
'    vCantCorreos NUMBER;',
'    ',
'    --Obtenemos el id_contribuyente del usuario logueado',
'    cursor C_MC IS',
'    SELECT ID_CONTRIBUYENTE',
'    FROM   USUARIOS_EXTERNOS',
'    WHERE ID_USUARIO = :APP_USER;',
'    ',
'    --Obtenemos el tipo contribuyente del usuario logueado',
'    CURSOR C_TIPO_CONTRIB (p_id_contribuyente NUMBER)IS',
'    SELECT ID_TIPO_CONTRIBUYENTE,ID_TIPO_IDENTIFICACION',
'    FROM   MAESTRO_CONTRIBUYENTE',
'    WHERE  ID_CONTRIBUYENTE = p_id_contribuyente;',
'   ',
'    ',
'    --Obtenemos el tipo de inscripcion del contribuyente',
'    CURSOR C_TIPO_INSCRIP(p_tipo_contrib NUMBER) IS',
'    SELECT IND_TIPO_INSCRIP',
'    FROM TIPO_CONTRIBUYENTE',
'    WHERE ID_TIPO_CONTRIBUYENTE = p_tipo_contrib;',
'    ',
'    --Obtenemos la cantidad de apoderados a firma digital',
'    CURSOR C_CANT_APO_FIR (p_id_contribuyente NUMBER)IS',
'    SELECT COUNT (*)',
'    FROM APODERADOS ',
'     WHERE INDICA_AUTORIZO IN (''F'')',
'       AND CODIGO_ESTADO = ''AC'' ',
'       AND ID_CONTRIBUYENTE = p_id_contribuyente;',
'    ',
'     --Obtenemos la cantidad de apoderados',
'    CURSOR C_CANT_APO (p_id_contribuyente NUMBER)IS',
'    SELECT COUNT (*)',
'    FROM APODERADOS ',
'    WHERE INDICA_AUTORIZO IN (''A'') ',
'      AND CODIGO_ESTADO = ''AC'' ',
'      AND ID_CONTRIBUYENTE = p_id_contribuyente;',
'      ',
'    --Obtenemos la cantidad de impuestos activos del contribuyente',
'    CURSOR C_CANT_IMP (p_id_contribuyente NUMBER) IS',
'    SELECT COUNT(ID_TIPO_IMPUESTO)',
'    FROM IMPUESTO_X_MAESTRO_CONTRIBUYE',
'    WHERE ID_CONTRIBUYENTE = p_id_contribuyente',
'    AND   CODIGO_ESTADO = ''AC'';',
'    ',
'    --Obtenemos la cantodad de correos del contribuyente',
'    CURSOR C_CANT_CORREOS (p_id_contribuyente NUMBER) IS',
'    SELECT COUNT (*)',
'    FROM   CORREO_NOTIFICACIONES',
'    WHERE  ID_CONTRIBUYENTE = p_id_contribuyente',
'    and    CODIGO_ESTADO = ''AC'';',
'    ',
'BEGIN',
'    OPEN  C_MC;',
'    FETCH C_MC INTO vId_contribuyente;',
'    CLOSE C_MC;',
'    ',
'    OPEN  C_TIPO_CONTRIB (vId_contribuyente);',
'    FETCH C_TIPO_CONTRIB INTO vTipo_Contrib,vTipo_Identifica;',
'    CLOSE C_TIPO_CONTRIB;',
'    ',
'    OPEN  C_TIPO_INSCRIP (vTipo_Contrib);',
'    FETCH C_TIPO_INSCRIP INTO vTipo_Inscrip;',
'    CLOSE C_TIPO_INSCRIP;',
'    ',
'    OPEN  C_CANT_APO_FIR(vId_contribuyente);',
'    FETCH C_CANT_APO_FIR INTO vCantApoFir;',
'    CLOSE C_CANT_APO_FIR;',
'    ',
'    OPEN  C_CANT_APO(vId_contribuyente);',
'    FETCH C_CANT_APO INTO vCantApo;',
'    CLOSE C_CANT_APO;',
'    ',
'    OPEN  C_CANT_IMP (vId_contribuyente);',
'    FETCH C_CANT_IMP INTO vCantImpuesto;',
'    CLOSE C_CANT_IMP;',
'    ',
'    OPEN  C_CANT_CORREOS (vId_contribuyente);',
'    FETCH C_CANT_CORREOS INTO vCantCorreos;',
'    CLOSE C_CANT_CORREOS;',
'    ',
'    ',
'    :P112_ID_CONTRIBUYENTE := vId_contribuyente;',
'    :P112_ID_CONTRIBU      := vId_contribuyente;',
'    :P112_CONTRIBUYENTE_ID := vId_contribuyente;',
'    :P112_TIPO_INSCRIPCION := vTipo_Inscrip;',
'    :P112_ID_TIPO_IDENTIFICACION := vTipo_Identifica;',
'    :P112_BRANCH := ''N'';',
'    :P112_CANT_IMP_CONTRIB := PKG_MAESTRO_CONTRIBUYENTE.CANT_IMPUESTO_TIP_CONTRIB (vTipo_Contrib);',
'    ',
'    IF vTipo_Inscrip = ''IR'' AND vTipo_Identifica = 2 THEN',
'    :P112_VALIDA_PERS_FISICA := ''S'';',
'    END IF;',
'    ',
'    IF  vTipo_Inscrip != ''ANRI'' THEN',
'        :P112_NOMBRE_REGION := ''Domicilio Fiscal'';',
'    ELSE',
unistr('        :P112_NOMBRE_REGION := '' Direcci\00F3n f\00EDsica de la Agencia'';'),
'    END IF;',
'    ',
'    IF vCantApoFir = 1 THEN',
'      :P112_VAL_CANT_APO_FIRM := ''S'';',
'    ELSE ',
'      :P112_VAL_CANT_APO_FIRM := ''N'';',
'    END IF;',
'    ',
'     IF vCantApo = 1 THEN',
'      :P112_VAL_CANT_APO := ''S'';',
'    ELSE ',
'      :P112_VAL_CANT_APO := ''N'';',
'    END IF;',
'    ',
'    IF :P112_ID_CONTRIBUYENTE IN (4,5,7) THEN',
'        :P112_VAL_COD_IATA := ''N'';',
'    ELSE',
'        :P112_VAL_COD_IATA := ''S'';',
'    END IF;',
'',
'    IF vTipo_Contrib IN (3,5,7) THEN',
'        :P112_TIPO_CONTRIB := ''S'';',
'    ELSE',
'        :P112_TIPO_CONTRIB := ''N'';',
'    END IF;',
'    ',
'    IF vCantImpuesto > 1 THEN',
'        :P112_CANT_IMPUESTOS := ''S'';',
'    ELSE',
'        :P112_CANT_IMPUESTOS := ''N'';    ',
'    END IF;',
'    ',
'    IF vCantCorreos > 1 THEN',
'        :P112_CANT_CORREOS := ''S'';',
'    ELSE',
'        :P112_CANT_CORREOS := ''N'';',
'    END IF;',
'    ',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(171649168825930378)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(171608724738930424)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form 112-Datos Maestro Contribuyente'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(174046190944863259)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_AGREGA_APO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vIdApoderado NUMBER;',
'v_retorno_boolean   boolean;',
'v_mensaje_retorno   varchar2(2000);',
'vArchivo BLOB;',
'vMimetype VARCHAR2(255);',
'vFilename VARCHAR2(255);',
'BEGIN',
'    --Insertamos documentos requeridos',
'    --Para agencias de viajes   ',
'     IF :P112_PODER_LEGAL_APO IS NOT NULL AND :P112_ARC_CED_APO IS NOT NULL THEN',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P112_PODER_LEGAL_APO;',
'    PKG_MAESTRO_CONTRIBUYENTE.P_INSERTA_APODERADOS_MC (vIdApoderado,',
'                             :P112_ID_CONTRIBU,',
'                             :P112_TIPO_APODERADO,',
'                             :P112_NOMBRE_APODERADO,',
'                             :P112_CEDULA_APODERADO,',
'                             :P112_CORREO_APODERADO,',
'                             NULL,',
'                             NULL,',
'                             NULL,',
'                             ''A'',',
'                             vArchivo,',
'                             vFilename,',
'                             vMimetype,',
'                             :APP_USER,',
'                             9,',
'                             ''I'',',
'                             v_mensaje_retorno,',
'                             v_retorno_boolean);',
'                             ',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P112_ARC_CED_APO;',
'    PKG_MAESTRO_CONTRIBUYENTE.P_INSERTA_ARCH_APODERADOS_MC (vArchivo,',
'                                  vFilename,',
'                                  vMimetype,',
'                                  vIdApoderado,',
'                                  :APP_USER);                         ',
'      ELSE',
'     --RAISE_APPLICATION_ERROR(-20000,''Debe adjuntar los archivos'');',
'     apex_error.add_error (',
'    p_message          => ''Debe adjuntar los archivos'',',
'    p_display_location => apex_error.c_inline_in_notification );',
'     END IF;',
'     ',
'     :P112_BRANCH := ''S'';',
'   ',
'IF NOT v_retorno_boolean  ',
'   THEN',
'     RAISE_APPLICATION_ERROR(-20000,v_mensaje_retorno);',
'     rollback;',
'     return; ',
'   else ',
'      commit;',
'   end if;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(174043993104863237)
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>108
,p_default_id_offset=>149139848948344617
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(174046336998863260)
,p_process_sequence=>20
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_AGREGA_APO_TERC'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vIdApoderado NUMBER;',
'v_retorno_boolean   boolean;',
'v_mensaje_retorno   varchar2(2000);',
'vArchivo BLOB;',
'vMimetype VARCHAR2(255);',
'vFilename VARCHAR2(255);',
'BEGIN',
'IF :P112_TIPO_AUT = ''T'' THEN',
'    IF :P112_PODER_LEGAL_TERC IS NOT NULL AND :P112_PODER_ESPECIAL IS NOT NULL THEN',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P112_PODER_LEGAL_TERC;',
'    PKG_MAESTRO_CONTRIBUYENTE.P_INSERTA_APODERADOS_MC (vIdApoderado,',
'                             :P112_ID_CONTRIBU,',
'                             NULL,',
'                             :P112_NOMBRE_APO_TERC,',
'                             :P112_CEDULA_APO_TERC,',
'                             :P112_CORREO_APO_TERC,',
'                             :P112_TIPO_IMPUESTO,',
'                             :P112_TIPO_IMPUESTO_1,',
'                             :P112_TIPO_IMPUESTO_2,',
'                             :P112_TIPO_AUT,',
'                             vArchivo,',
'                             vFilename,',
'                             vMimetype,',
'                             :APP_USER,',
'                             11,',
'                             ''I'',',
'                             v_mensaje_retorno,',
'                             v_retorno_boolean);',
'     ',
'        SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P112_PODER_ESPECIAL;',
'        PKG_MAESTRO_CONTRIBUYENTE.P_INSERTA_ARCH_APODERADOS_MC (vArchivo,',
'                                      vFilename,',
'                                      vMimetype,',
'                                      vIdApoderado,',
'                                      :APP_USER);',
'    ELSE',
'     RAISE_APPLICATION_ERROR(-20000,''Debe adjuntar los archivos'');',
'    END IF;',
'ELSIF :P112_TIPO_AUT = ''F'' THEN',
'    IF :P112_PODER_LEGAL_TERC IS NOT NULL THEN',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P112_PODER_LEGAL_TERC;',
'    PKG_MAESTRO_CONTRIBUYENTE.P_INSERTA_APODERADOS_MC (vIdApoderado,',
'                             :P112_ID_CONTRIBU,',
'                             NULL,',
'                             :P112_NOMBRE_APO_TERC,',
'                             :P112_CEDULA_APO_TERC,',
'                             :P112_CORREO_APO_TERC,',
'                             :P112_TIPO_IMPUESTO,',
'                             :P112_TIPO_IMPUESTO_1,',
'                             :P112_TIPO_IMPUESTO_2,',
'                             :P112_TIPO_AUT,',
'                             vArchivo,',
'                             vFilename,',
'                             vMimetype,',
'                             :APP_USER,',
'                             10,',
'                             ''I'',',
'                             v_mensaje_retorno,',
'                             v_retorno_boolean);',
'     ELSE',
unistr('     RAISE_APPLICATION_ERROR(-20000,''Debe adjuntar los la Personer\00EDa Jur\00EDdica'');'),
'     END IF;',
'END IF;',
'    :P112_BRANCH := ''S'';',
'IF NOT v_retorno_boolean  ',
'   THEN',
'     RAISE_APPLICATION_ERROR(-20000,v_mensaje_retorno);',
'     rollback;',
'     return; ',
'   else ',
'      commit;',
'   end if;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(174045417888863251)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(186204734107847858)
,p_process_sequence=>30
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_AGREGAR_TEL'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vId_telefono NUMBER;',
'BEGIN',
'vId_telefono := SEQ_TELEFONO_MAESTRO.NEXTVAL;',
'INSERT INTO TELEFONO_X_MAESTRO_CONTRIBU VALUES(vId_telefono,:P112_ID_CONTRIBUYENTE,:P112_TIPO_TEL,:P112_TELEFONO_NUEVO,:APP_USER);',
'COMMIT;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(186204505915847856)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(180216504712062926)
,p_process_sequence=>50
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_ACTUALIZA_TELEFONO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'UPDATE TELEFONO_X_MAESTRO_CONTRIBU SET TELEFONO = :P112_NEW_TELEFONO,USUARIO_SIT = :APP_USER WHERE ID_TELEFONO = :P112_ID_TEL AND ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE;',
'COMMIT;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(180216272790062924)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(186205446331847865)
,p_process_sequence=>60
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_AGREGAR_CORREO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vId_correo_notif NUMBER;',
'BEGIN',
'vId_correo_notif := SEQ_CORREO_NOTIFICA.NEXTVAL;',
'    INSERT INTO CORREO_NOTIFICACIONES (ID_CORREO_NOTIFICA,',
'                                       ID_CONTRIBUYENTE,',
'                                       CORREO_NOTIFICA,',
'                                       USUARIO_SIT,',
'                                      CODIGO_ESTADO)',
'                               VALUES (vId_correo_notif,',
'                                       :P112_ID_CONTRIBUYENTE,',
'                                       :P112_CORREO_NUEVO,',
'                                       :APP_USER,',
'                                      ''AC''); ',
'COMMIT;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(186205337706847864)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(180217149847062933)
,p_process_sequence=>70
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_ACTUALIZA_CORREO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'UPDATE CORREO_NOTIFICACIONES SET CORREO_NOTIFICA = :P112_NEW_CORREO,USUARIO_SIT = :APP_USER WHERE ID_CORREO_NOTIFICA = :P112_ID_CORREO AND ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE;',
'COMMIT;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(180217111922062932)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(234074116431206218)
,p_process_sequence=>80
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INACTIVAR_CORREO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'UPDATE CORREO_NOTIFICACIONES SET CODIGO_ESTADO = ''AI'',USUARIO_SIT = :APP_USER WHERE ID_CORREO_NOTIFICA = :P112_ID_CORREO AND ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE;',
'COMMIT;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(232312378728278367)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(192277404260450547)
,p_process_sequence=>90
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_ACTUALIZA_VENTA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'UPDATE VENTAS_X_MAESTRO_CONTRIBU SET ID_TIPO_VENTAS = :P112_ID_TIPO_VENTA, USUARIO_SIT = :APP_USER WHERE ID_VENTAS = :P112_ID_VENTA AND ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE;',
'COMMIT;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(192277325734450546)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(192277957496450553)
,p_process_sequence=>100
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_AGREGAR_VENTA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vId_venta NUMBER;',
'BEGIN',
'vId_venta := SEQ_VENTAS_MAESTRO.NEXTVAL;',
'INSERT INTO VENTAS_X_MAESTRO_CONTRIBU VALUES(vId_venta,:P112_ID_CONTRIBUYENTE,:P112_ID_TIPO_VENTA_NUEVA,:APP_USER);',
'COMMIT;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(192277899808450552)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(192278476400450558)
,p_process_sequence=>110
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INACTIVA_APO_TER'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'UPDATE APODERADOS SET FECHA_FIN_AUTORIZA = sysdate,CODIGO_ESTADO = ''IA'', USUARIO_SIT = :APP_USER WHERE ID_APODERADO = :P112_ID_APO_TER;',
'commit;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(174043122803863228)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(218773567765933958)
,p_process_sequence=>120
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_ACT_REPRE_LEG'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vIdRepreLegal NUMBER;',
'v_retorno_boolean   boolean;',
'v_mensaje_retorno   varchar2(2000);',
'vArchivo BLOB;',
'vMimetype VARCHAR2(255);',
'vFilename VARCHAR2(255);',
'vId_Archi NUMBER;',
'vId_Deudor NUMBER;',
'BEGIN',
'vId_Deudor:= PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR (:APP_USER);',
'PKG_MAESTRO_CONTRIBUYENTE.P_INSERT_TEMP_REP_LEGAL (vIdRepreLegal,',
'                         :P112_ID_CONTRIBUYENTE,',
'                         :P112_NOM_REP_LEG,',
'                         :P112_CED_REP_LEG,',
'                         :P112_CORREO_REP_LEG,',
'                         :APP_USER,',
'                         v_mensaje_retorno,',
'                         v_retorno_boolean);',
'',
'IF vIdRepreLegal IS NOT NULL THEN',
'    IF :P112_ARC_REP_LEG1 IS NULL OR :P112_ARC_REP_LEG2 IS NULL THEN',
'        RAISE_APPLICATION_ERROR(-20000, ''Debe adjuntar un archivo'');',
'    END IF;',
'IF :P112_ARC_REP_LEG1 IS NOT NULL THEN',
'    vId_Archi := SEQ_TEMP_ARCHI_REPRE_LEGAL.NEXTVAL;',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P112_ARC_REP_LEG1;',
'INSERT INTO TEMP_ARCHI_REPRE_LEGAL VALUES (vIdRepreLegal,vFilename,vArchivo,vMimetype,SYSDATE,:APP_USER,vId_Archi);',
'COMMIT;',
'END IF;',
'',
'IF :P112_ARC_REP_LEG2 IS NOT NULL THEN',
'    vId_Archi := SEQ_TEMP_ARCHI_REPRE_LEGAL.NEXTVAL;',
'    SELECT BLOB_CONTENT, MIME_TYPE, FILENAME INTO vArchivo,vMimetype, vFilename FROM APEX_APPLICATION_TEMP_FILES WHERE NAME = :P112_ARC_REP_LEG2;',
'INSERT INTO TEMP_ARCHI_REPRE_LEGAL VALUES (vIdRepreLegal,vFilename,vArchivo,vMimetype,SYSDATE,:APP_USER,vId_Archi);',
'COMMIT;',
'END IF;',
'',
'PKG_ENVIO_NOTIF_ICT_CONTRIB.NOTIFICA_CONTRIBUYENTES (:P112_ID_CONTRIBUYENTE,vId_Deudor,13,''I'',''I'',0);',
'',
':P112_BRANCH := ''S'';',
'END IF;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(218773350592933956)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(230636722284413655)
,p_process_sequence=>130
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INSERT_IMPUESTO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vId_Impuesto NUMBER;',
'BEGIN',
'IF :P112_IMPUESTO IS NOT NULL THEN',
'    IF :P112_NOMBRE_ENCAR IS NOT NULL AND :P112_CEDULA_ENCAR IS NOT NULL AND :P112_CORREO_ENCAR IS NOT NULL THEN',
'vId_Impuesto := SEQ_TEMP_IMPUESTO.NEXTVAL;',
'INSERT INTO TEMP_IMPUESTO_MAEST_CONTRIB VALUES (:P112_IMPUESTO,',
'                                                :P112_ID_CONTRIBUYENTE,',
'                                                :P112_NOMBRE_ENCAR,',
'                                                :P112_CEDULA_ENCAR,',
'                                                :P112_CORREO_ENCAR,',
'                                                ''P'',',
'                                                :APP_USER,',
'                                                ''N'',',
'                                               vId_Impuesto);',
'COMMIT;   ',
'PKG_ENVIO_NOTIF_ICT_CONTRIB.NOTIFICA_CONTRIBUYENTES (:P112_ID_CONTRIBUYENTE,:P112_ID_DEUDOR,12,''I'',''I'',0);',
':P112_BRANCH := ''S'';',
'    END IF;',
'END IF;',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(230636292977413651)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(231654018198221421)
,p_process_sequence=>140
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PRC_INACTIVAR_IMPUESTO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vIdDeudor NUMBER;',
'vNomEncar VARCHAR2(80);',
'vCedEncar VARCHAR2(20);',
'vCorreoEncar VARCHAR2(40);',
'vId_Impuesto NUMBER;',
'    CURSOR C_DAT_IMP IS',
'    SELECT NOMBRE_ENCARGADO_IMP,CEDULA_ENCARGADO_IMP,CORREO_ENCARGADO_IMP',
'    FROM   IMPUESTO_X_MAESTRO_CONTRIBUYE',
'    WHERE  ID_TIPO_IMPUESTO = :P112_ID_IMPUESTO',
'    AND    ID_CONTRIBUYENTE = :P112_ID_CONTRIBUYENTE;',
'BEGIN',
'    OPEN   C_DAT_IMP;',
'    FETCH  C_DAT_IMP INTO vNomEncar,vCedEncar,vCorreoEncar;',
'    CLOSE  C_DAT_IMP;',
'     vId_Impuesto := SEQ_TEMP_IMPUESTO.NEXTVAL;',
'INSERT INTO TEMP_IMPUESTO_MAEST_CONTRIB VALUES (:P112_ID_IMPUESTO,',
'                                                :P112_ID_CONTRIBUYENTE,',
'                                                vNomEncar,',
'                                                vCedEncar,',
'                                                vCorreoEncar,',
'                                                ''P'',',
'                                                :APP_USER,',
'                                               ''I'',',
'                                               vId_Impuesto);',
'COMMIT;   ',
'vIdDeudor := PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR_CONTRIB (:P112_ID_CONTRIBUYENTE);',
'PKG_ENVIO_NOTIF_ICT_CONTRIB.NOTIFICA_CONTRIBUYENTES (:P112_ID_CONTRIBUYENTE, vIdDeudor,12,''I'',''I'',0);',
':P112_BRANCH := ''S'';',
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(231653866239221420)
);
wwv_flow_api.component_end;
end;
/
