prompt --application/pages/page_00206
begin
--   Manifest
--     PAGE: 00206
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>108
,p_default_id_offset=>149139848948344617
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_page(
 p_id=>206
,p_user_interface_id=>wwv_flow_api.id(154283420613688838)
,p_name=>'206-Consulta Intereses Arreglos de Pago'
,p_alias=>'206-CONSULTA-INTERESES-ARREGLOS-DE-PAGO'
,p_step_title=>'206-Consulta Intereses Arreglos de Pago'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js'
,p_page_template_options=>'#DEFAULT#'
,p_browser_cache=>'N'
,p_last_updated_by=>'KIMBERLYN.SOLANO'
,p_last_upd_yyyymmddhh24miss=>'20221121125627'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(186089993757837725)
,p_plug_name=>'Consulta Intereses Arreglos de Pago'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(154198847510688906)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(186092489603837750)
,p_button_sequence=>140
,p_button_plug_id=>wwv_flow_api.id(186089993757837725)
,p_button_name=>'BTN_CALCULAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(154260943869688868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Calcular'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(186090144231837726)
,p_name=>'P206_ID_DEUDOR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(186089993757837725)
,p_prompt=>'Deudor:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NOMBRE_ENTIDAD,ID_CONTRIBUYENTE',
'FROM MAESTRO_CONTRIBUYENTE',
'WHERE ID_DEUDOR = PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR (:APP_USER)'))
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(186090202692837727)
,p_name=>'P206_NUM_ARREGLO_PAGO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(186089993757837725)
,p_prompt=>unistr('N\00BA Arreglo Pago:')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select DC.ID_ARREGLO_P a, DC.ID_ARREGLO_P b',
'from V_FUENTES_DEUDORES@CONSULTA_ICTX  D, ARREGLOS_PAGOS@CONSULTA_ICTX DC',
'where D.ID_DEUDOR = DC.ID_DEUDOR ',
'AND CODIGO_ESTADO = ''A''',
'AND DC.ID_DEUDOR = PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR (:APP_USER)',
'ORDER BY D.NOMBRE ASC'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(186090325718837728)
,p_name=>'P206_MONTO_ADEUDADO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(186089993757837725)
,p_prompt=>'Monto Adeudado:'
,p_format_mask=>'999G999G999G999G990D00'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'onfocusout="this.value=Number(this.value).toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, ''$1,'')"'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(186090774480837733)
,p_name=>'P206_NUM_CUOTA_PAG_C'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(186089993757837725)
,p_prompt=>unistr('N\00BA Cuota del Arreglo Pago a Calcular')
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('SELECT ''N\00BA.Cuota:  ''||NUMERO_CUOTA||''   ''||''  Fecha Pago:  ''||to_char(FECHA_PAGO,''dd/mm/yyyy'')||''   Fecha Inicio:  ''||to_char(to_date(FECHA_PAGO + 1),''dd/mm/yyyy'') DESCRIPCION, NUMERO_CUOTA ID'),
'FROM CALCULO_CUOTA_ARREGLO_PAGO@CONSULTA_ICTX',
'WHERE ID_ARREGLO_P = :P206_NUM_ARREGLO_PAGO',
'AND CODIGO_ESTADO =''P'' ',
'AND ID_DEUDOR = PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR (:APP_USER) ',
'AND trunc(FECHA_PAGO) <= trunc(sysdate) ',
'ORDER BY NUMERO_CUOTA',
'',
unistr('/*SELECT ''N\00BA.Cuota:  ''||NUMERO_CUOTA||''   ''||''  Fecha Pago:  ''||to_char(FECHA_PAGO,''dd/mm/yyyy'')||''   Fecha Inicio:  ''||(FECHA_PAGO + 1) DESCRIPCION, NUMERO_CUOTA ID'),
'FROM CALCULO_CUOTA_ARREGLO_PAGO@CONSULTA_ICTX',
'WHERE ID_ARREGLO_P = :P206_NUM_ARREGLO_PAGO',
'AND CODIGO_ESTADO =''P'' ',
'AND ID_DEUDOR = PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR (:APP_USER) ',
'AND trunc(FECHA_PAGO) <= trunc(sysdate) ',
'ORDER BY NUMERO_CUOTA*/',
''))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P206_NUM_ARREGLO_PAGO'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>60
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(186091040415837735)
,p_name=>'P206_FECHA_INICIAL'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(186089993757837725)
,p_prompt=>'Fecha Inicial:'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_tag_attributes=>'disabled=disabled'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(186091321848837738)
,p_name=>'P206_FECHA_CALCULO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(186089993757837725)
,p_item_default=>'SYSDATE'
,p_item_default_type=>'PLSQL_EXPRESSION'
,p_prompt=>'Fecha a Calcular:'
,p_format_mask=>'DD/MM/YYYY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>20
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(154259886985688872)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(186091700490837742)
,p_name=>'P206_MENSAJE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(186089993757837725)
,p_item_default=>'La fecha a calcular no puede ser menor a la fecha inicial.'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="color:red;"'
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(186091834893837743)
,p_name=>'P206_VAL_MSJ'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(186089993757837725)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(186092212682837747)
,p_name=>'P206_MONTO_CUOTA'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(186089993757837725)
,p_prompt=>'Monto Cuota:'
,p_format_mask=>'999G999G999G999G990D00'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'data-type="currency"'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(186092275312837748)
,p_name=>'P206_TASA_MORA'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(186089993757837725)
,p_prompt=>'Tasa Mora %:'
,p_format_mask=>'999G999G999G999G990D00'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(186092424458837749)
,p_name=>'P206_DIAS_ATRASO'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(186089993757837725)
,p_prompt=>unistr('D\00EDas Atraso:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(186092634612837751)
,p_name=>'P206_INTERESES_MORA'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(186089993757837725)
,p_prompt=>'Intereses Moratorios:'
,p_format_mask=>'999G999G999G999G990D00'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'data-type="currency"'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(186092718445837752)
,p_name=>'P206_TOTAL_PAGAR'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(186089993757837725)
,p_prompt=>'Total a Pagar:'
,p_format_mask=>'999G999G999G999G990D00'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'data-type="currency"'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(186092989293837755)
,p_name=>'P206_VAL_MSJ2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(186089993757837725)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(186093054020837756)
,p_name=>'P206_MENSAJE2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(186089993757837725)
,p_item_default=>'Error al realizar el calculo, por favor validar.'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="color:red;"'
,p_field_template=>wwv_flow_api.id(154259640237688873)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(186090624693837731)
,p_name=>'DAC_MONTO'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P206_NUM_ARREGLO_PAGO'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186090651690837732)
,p_event_id=>wwv_flow_api.id(186090624693837731)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vMonto NUMBER;',
'    CURSOR C_MONTO IS',
'    SELECT DC.SALDO_DOCUMENTO a',
'    FROM V_FUENTES_DEUDORES@CONSULTA_ICTX  D, ARREGLOS_PAGOS@CONSULTA_ICTX DC',
'    WHERE D.ID_DEUDOR = DC.ID_DEUDOR ',
'    AND DC.CODIGO_ESTADO = ''A''',
'    AND DC.ID_DEUDOR = PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR (:APP_USER)',
'    AND DC.ID_ARREGLO_P = :P206_NUM_ARREGLO_PAGO',
'    ORDER BY D.NOMBRE ASC;',
'BEGIN',
'   OPEN  C_MONTO;',
'   FETCH C_MONTO INTO vMonto;',
'   CLOSE C_MONTO;',
'   :P206_MONTO_ADEUDADO := vMonto;',
'END;'))
,p_attribute_02=>'P206_NUM_ARREGLO_PAGO'
,p_attribute_03=>'P206_MONTO_ADEUDADO'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(186091074493837736)
,p_name=>'DAC_FECHA_INICIAL'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P206_NUM_CUOTA_PAG_C'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186091206988837737)
,p_event_id=>wwv_flow_api.id(186091074493837736)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vFecha DATE;',
'    CURSOR C_FEHCA_INI IS',
'    SELECT (FECHA_PAGO + 1)FECHA_INICIAL',
'    FROM CALCULO_CUOTA_ARREGLO_PAGO@CONSULTA_ICTX',
'    WHERE ID_ARREGLO_P = :P206_NUM_ARREGLO_PAGO',
'    AND   NUMERO_CUOTA = :P206_NUM_CUOTA_PAG_C',
'    AND CODIGO_ESTADO =''P'' ',
'    AND ID_DEUDOR = PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR (:APP_USER) ',
'    AND trunc(FECHA_PAGO) <= trunc(sysdate) ',
'    ORDER BY 1;',
'BEGIN',
'    OPEN  C_FEHCA_INI;',
'    FETCH C_FEHCA_INI INTO vFecha;',
'    CLOSE C_FEHCA_INI;',
'    :P206_FECHA_INICIAL := to_date(vFecha,''dd/mm/yyyy'');',
'END;'))
,p_attribute_02=>'P206_NUM_ARREGLO_PAGO,P206_NUM_CUOTA_PAG_C'
,p_attribute_03=>'P206_FECHA_INICIAL'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(186091506292837740)
,p_name=>'DAC_VAL_FECHA'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P206_FECHA_CALCULO'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186091557142837741)
,p_event_id=>wwv_flow_api.id(186091506292837740)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'BEGIN',
'    IF to_date(:P206_FECHA_CALCULO,''dd/mm/yyyy'')  < to_date(:P206_FECHA_INICIAL,''dd/mm/yyyy'') THEN',
'        :P206_VAL_MSJ := ''S'';',
'    ELSE',
'        :P206_VAL_MSJ := ''N'';',
'    END IF;',
'END;'))
,p_attribute_02=>'P206_FECHA_INICIAL,P206_FECHA_CALCULO'
,p_attribute_03=>'P206_VAL_MSJ'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(186091925332837744)
,p_name=>'DAC_MUESTRA_MSJ'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P206_VAL_MSJ'
,p_condition_element=>'P206_VAL_MSJ'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'S'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186092015287837745)
,p_event_id=>wwv_flow_api.id(186091925332837744)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P206_MENSAJE'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186092138162837746)
,p_event_id=>wwv_flow_api.id(186091925332837744)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P206_MENSAJE'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186203794048847849)
,p_event_id=>wwv_flow_api.id(186091925332837744)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(186092489603837750)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186203910967847850)
,p_event_id=>wwv_flow_api.id(186091925332837744)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_api.id(186092489603837750)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(186092796884837753)
,p_name=>'DAC_CALCULAR'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(186092489603837750)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186092927441837754)
,p_event_id=>wwv_flow_api.id(186092796884837753)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'vMontoCuota NUMBER;',
'vTasaMora NUMBER;',
'vDiasAtraso NUMBER; ',
'vInt_Mora NUMBER;',
'vparam_retorno NUMBER := 1;',
'v_Mensaje_Retorno VARCHAR2(1000);',
'BEGIN',
'PKG_MAESTRO_CONTRIBUYENTE.P_CALCULO_INT_ARREGLO_PAGO (PKG_MAESTRO_CONTRIBUYENTE.RETORNA_ID_DEUDOR (:APP_USER), ',
'                                                      :P206_NUM_ARREGLO_PAGO, ',
'                                                      TO_DATE(:P206_FECHA_INICIAL,''DD/MM/RRRR''), ',
'                                                      --  TO_DATE(:P206_FECHA_INICIAL,''MM/DD/RRRR''), ',
'                                                      TO_DATE(:P206_FECHA_CALCULO,''DD/MM/RRRR''),',
'                                                      vMontoCuota, ',
'                                                      vTasaMora, ',
'                                                      vDiasAtraso, ',
'                                                      vInt_Mora,',
'                                                      vparam_retorno, --enviar parametro en 1',
'                                                      v_Mensaje_Retorno);                                            ',
'    IF  vparam_retorno = 0 THEN',
'            :P206_VAL_MSJ2 := ''S'';',
'    ELSE',
'            :P206_VAL_MSJ2 := ''N'';',
'            :P206_MONTO_CUOTA    := vMontoCuota;',
'            :P206_TASA_MORA      := vTasaMora;',
'            :P206_DIAS_ATRASO    := vDiasAtraso;',
'            :P206_INTERESES_MORA := vInt_Mora;',
'            :P206_TOTAL_PAGAR  :=  vMontoCuota +  vInt_Mora;',
'    END IF;',
'END;'))
,p_attribute_02=>'P206_NUM_ARREGLO_PAGO,P206_FECHA_INICIAL,P206_FECHA_CALCULO'
,p_attribute_03=>'P206_MONTO_CUOTA,P206_TASA_MORA,P206_DIAS_ATRASO,P206_INTERESES_MORA,P206_TOTAL_PAGAR,P206_VAL_MSJ2'
,p_attribute_04=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186203290563847844)
,p_event_id=>wwv_flow_api.id(186092796884837753)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_FOCUS'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P206_MONTO_CUOTA'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186203358986847845)
,p_event_id=>wwv_flow_api.id(186092796884837753)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_FOCUS'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P206_INTERESES_MORA'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186203527244847846)
,p_event_id=>wwv_flow_api.id(186092796884837753)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_FOCUS'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P206_TOTAL_PAGAR'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186203602474847847)
,p_event_id=>wwv_flow_api.id(186092796884837753)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_FOCUS'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P206_ID_DEUDOR'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186203734007847848)
,p_event_id=>wwv_flow_api.id(186092796884837753)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_FOCUS'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P206_ID_DEUDOR'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(186093166272837757)
,p_name=>'DAC_MENSAJE2'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P206_VAL_MSJ2'
,p_condition_element=>'P206_VAL_MSJ2'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'S'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186093293421837758)
,p_event_id=>wwv_flow_api.id(186093166272837757)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P206_MENSAJE2'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186093359546837759)
,p_event_id=>wwv_flow_api.id(186093166272837757)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P206_MENSAJE2'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(186201940439847830)
,p_name=>'DAC_FORMATO_MONTO'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P206_MONTO_ADEUDADO'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186202036753847831)
,p_event_id=>wwv_flow_api.id(186201940439847830)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Jquery Dependency',
'',
'$("input[data-type=''currency'']").on({',
'    keyup: function() {',
'      formatCurrency($(this));',
'    },',
'    blur: function() { ',
'      formatCurrency($(this), "blur");',
'    }',
'});',
'',
'function formatNumber(n) {',
unistr('  // formato del n\00FAmero de 1000000 a 1,234,567'),
'  return n.replace(/\D/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")',
'}',
'',
'function formatCurrency(input, blur) {',
'  var input_val = input.val();',
'',
'  if (input_val === "") { return; }',
'',
'  var original_len = input_val.length;',
'',
'  var caret_pos = input.prop("selectionStart");',
' ',
'  if (input_val.indexOf(".") >= 0) {',
'',
'    var decimal_pos = input_val.indexOf(".");',
'',
'    var left_side = input_val.substring(0, decimal_pos);',
'    var right_side = input_val.substring(decimal_pos);',
'',
unistr('    // A\00F1ade comas a la derecha de los n\00FAmeros'),
'    left_side = formatNumber(left_side);',
'',
'    // Valida el valor del lado derecho',
'    right_side = formatNumber(right_side);',
'    ',
unistr('    // Indicamos que los decimales sean 2 n\00FAmeros siempre'),
'    if (blur === "blur") {',
'      right_side += "00";',
'    }',
'    ',
unistr('    // Indicamos el l\00EDmite de decimales'),
'    right_side = right_side.substring(0, 2);',
'    input_val = left_side + "." + right_side;',
'',
'  } else {',
unistr('    // removemos todos los valores que no son n\00FAmeros'),
'    input_val = formatNumber(input_val);',
'    input_val = input_val;',
'    ',
'    // indicamos la cantidad de decimales',
'    if (blur === "blur") {',
'      input_val += ".00";',
'    }',
'  }',
'  ',
unistr('  // env\00EDamos la actualizaci\00F3n al campo'),
'  input.val(input_val);',
'',
unistr('  // Lo colocamos en la posici\00F3n izquierda del campo'),
'  var updated_len = input_val.length;',
'  caret_pos = updated_len - original_len + caret_pos;',
'  input[0].setSelectionRange(caret_pos, caret_pos);',
'}'))
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186202066259847832)
,p_event_id=>wwv_flow_api.id(186201940439847830)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_FOCUS'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P206_MONTO_ADEUDADO'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186202205420847833)
,p_event_id=>wwv_flow_api.id(186201940439847830)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P206_MONTO_ADEUDADO'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186202270931847834)
,p_event_id=>wwv_flow_api.id(186201940439847830)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_FOCUS'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P206_NUM_CUOTA_PAG_C'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(186202444074847835)
,p_name=>'DAC_FORMATO_MONTO_CUOTA'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P206_MONTO_CUOTA'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186202525057847836)
,p_event_id=>wwv_flow_api.id(186202444074847835)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Jquery Dependency',
'',
'$("input[data-type=''currency'']").on({',
'    keyup: function() {',
'      formatCurrency($(this));',
'    },',
'    blur: function() { ',
'      formatCurrency($(this), "blur");',
'    }',
'});',
'',
'',
'function formatNumber(n) {',
unistr('  // formato del n\00FAmero de 1000000 a 1,234,567'),
'  return n.replace(/\D/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")',
'}',
'',
'',
'function formatCurrency(input, blur) {',
'  var input_val = input.val();',
'',
'  if (input_val === "") { return; }',
'',
'  var original_len = input_val.length;',
'',
'  var caret_pos = input.prop("selectionStart");',
' ',
'  if (input_val.indexOf(".") >= 0) {',
'',
'    var decimal_pos = input_val.indexOf(".");',
'',
'    var left_side = input_val.substring(0, decimal_pos);',
'    var right_side = input_val.substring(decimal_pos);',
'',
unistr('    // A\00F1ade comas a la derecha de los n\00FAmeros'),
'    left_side = formatNumber(left_side);',
'',
'    // Valida el valor del lado derecho',
'    right_side = formatNumber(right_side);',
'    ',
unistr('    // Indicamos que los decimales sean 2 n\00FAmeros siempre'),
'    if (blur === "blur") {',
'      right_side += "00";',
'    }',
'    ',
unistr('    // Indicamos el l\00EDmite de decimales'),
'    right_side = right_side.substring(0, 2);',
'    input_val = left_side + "." + right_side;',
'',
'  } else {',
unistr('    // removemos todos los valores que no son n\00FAmeros'),
'    input_val = formatNumber(input_val);',
'    input_val = input_val;',
'    ',
'    // indicamos la cantidad de decimales',
'    if (blur === "blur") {',
'      input_val += ".00";',
'    }',
'  }',
'  ',
unistr('  // env\00EDamos la actualizaci\00F3n al campo'),
'  input.val(input_val);',
'',
unistr('  // Lo colocamos en la posici\00F3n izquierda del campo'),
'  var updated_len = input_val.length;',
'  caret_pos = updated_len - original_len + caret_pos;',
'  input[0].setSelectionRange(caret_pos, caret_pos);',
'}'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(186202938715847840)
,p_name=>'DAC_FORMAT_INTERESES'
,p_event_sequence=>90
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P206_INTERESES_MORA'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186202949220847841)
,p_event_id=>wwv_flow_api.id(186202938715847840)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Jquery Dependency',
'',
'$("input[data-type=''currency'']").on({',
'    keyup: function() {',
'      formatCurrency($(this));',
'    },',
'    blur: function() { ',
'      formatCurrency($(this), "blur");',
'    }',
'});',
'',
'',
'function formatNumber(n) {',
unistr('  // formato del n\00FAmero de 1000000 a 1,234,567'),
'  return n.replace(/\D/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")',
'}',
'',
'',
'function formatCurrency(input, blur) {',
'  var input_val = input.val();',
'',
'  if (input_val === "") { return; }',
'',
'  var original_len = input_val.length;',
'',
'  var caret_pos = input.prop("selectionStart");',
' ',
'  if (input_val.indexOf(".") >= 0) {',
'',
'    var decimal_pos = input_val.indexOf(".");',
'',
'    var left_side = input_val.substring(0, decimal_pos);',
'    var right_side = input_val.substring(decimal_pos);',
'',
unistr('    // A\00F1ade comas a la derecha de los n\00FAmeros'),
'    left_side = formatNumber(left_side);',
'',
'    // Valida el valor del lado derecho',
'    right_side = formatNumber(right_side);',
'    ',
unistr('    // Indicamos que los decimales sean 2 n\00FAmeros siempre'),
'    if (blur === "blur") {',
'      right_side += "00";',
'    }',
'    ',
unistr('    // Indicamos el l\00EDmite de decimales'),
'    right_side = right_side.substring(0, 2);',
'    input_val = left_side + "." + right_side;',
'',
'  } else {',
unistr('    // removemos todos los valores que no son n\00FAmeros'),
'    input_val = formatNumber(input_val);',
'    input_val = input_val;',
'    ',
'    // indicamos la cantidad de decimales',
'    if (blur === "blur") {',
'      input_val += ".00";',
'    }',
'  }',
'  ',
unistr('  // env\00EDamos la actualizaci\00F3n al campo'),
'  input.val(input_val);',
'',
unistr('  // Lo colocamos en la posici\00F3n izquierda del campo'),
'  var updated_len = input_val.length;',
'  caret_pos = updated_len - original_len + caret_pos;',
'  input[0].setSelectionRange(caret_pos, caret_pos);',
'}'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(186203060361847842)
,p_name=>'DAC_FORMAT_TOTAL'
,p_event_sequence=>100
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P206_TOTAL_PAGAR'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(186203152197847843)
,p_event_id=>wwv_flow_api.id(186203060361847842)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Jquery Dependency',
'',
'$("input[data-type=''currency'']").on({',
'    keyup: function() {',
'      formatCurrency($(this));',
'    },',
'    blur: function() { ',
'      formatCurrency($(this), "blur");',
'    }',
'});',
'',
'',
'function formatNumber(n) {',
unistr('  // formato del n\00FAmero de 1000000 a 1,234,567'),
'  return n.replace(/\D/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")',
'}',
'',
'',
'function formatCurrency(input, blur) {',
'  var input_val = input.val();',
'',
'  if (input_val === "") { return; }',
'',
'  var original_len = input_val.length;',
'',
'  var caret_pos = input.prop("selectionStart");',
' ',
'  if (input_val.indexOf(".") >= 0) {',
'',
'    var decimal_pos = input_val.indexOf(".");',
'',
'    var left_side = input_val.substring(0, decimal_pos);',
'    var right_side = input_val.substring(decimal_pos);',
'',
unistr('    // A\00F1ade comas a la derecha de los n\00FAmeros'),
'    left_side = formatNumber(left_side);',
'',
'    // Valida el valor del lado derecho',
'    right_side = formatNumber(right_side);',
'    ',
unistr('    // Indicamos que los decimales sean 2 n\00FAmeros siempre'),
'    if (blur === "blur") {',
'      right_side += "00";',
'    }',
'    ',
unistr('    // Indicamos el l\00EDmite de decimales'),
'    right_side = right_side.substring(0, 2);',
'    input_val = left_side + "." + right_side;',
'',
'  } else {',
unistr('    // removemos todos los valores que no son n\00FAmeros'),
'    input_val = formatNumber(input_val);',
'    input_val = input_val;',
'    ',
'    // indicamos la cantidad de decimales',
'    if (blur === "blur") {',
'      input_val += ".00";',
'    }',
'  }',
'  ',
unistr('  // env\00EDamos la actualizaci\00F3n al campo'),
'  input.val(input_val);',
'',
unistr('  // Lo colocamos en la posici\00F3n izquierda del campo'),
'  var updated_len = input_val.length;',
'  caret_pos = updated_len - original_len + caret_pos;',
'  input[0].setSelectionRange(caret_pos, caret_pos);',
'}'))
);
wwv_flow_api.component_end;
end;
/
