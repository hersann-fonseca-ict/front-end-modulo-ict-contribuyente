prompt --application/shared_components/navigation/lists/desktop_navigation_menu
begin
--   Manifest
--     LIST: Desktop Navigation Menu
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>108
,p_default_id_offset=>149139848948344617
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(154145289518688954)
,p_name=>'Desktop Navigation Menu'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(154293405698688770)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Inicio'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-home'
,p_list_item_disp_cond_type=>'NEVER'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(171607881204959752)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>unistr('Mis datos/Actualizaci\00F3n ')
,p_list_item_link_target=>'f?p=&APP_ID.:112:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-address-card-o'
,p_list_item_disp_cond_type=>'USER_IS_NOT_PUBLIC_USER'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(154461627967453802)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('Requisitos e inscripci\00F3n ')
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-list-alt'
,p_list_item_disp_cond_type=>'USER_IS_PUBLIC_USER'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(154461911944450302)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>unistr('Requisitos des-inscripci\00F3n')
,p_list_item_link_target=>'f?p=&APP_ID.:101:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-server-x'
,p_list_item_disp_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_list_item_disp_condition=>'GLOBAL_TIPO_INSCRIPCION'
,p_list_item_disp_condition2=>'IR'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(154462188368447492)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>unistr('Inscripci\00F3n regular')
,p_list_item_link_target=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-clipboard-list'
,p_list_item_disp_cond_type=>'NEVER'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(164934858542594796)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>unistr('Solicitar Des-inscripci\00F3n')
,p_list_item_link_target=>'f?p=&APP_ID.:113:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-text'
,p_list_item_disp_cond_type=>'NEVER'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(176906291224939894)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>unistr('Inscripci\00F3n vuelos ch\00E1rter')
,p_list_item_link_target=>'f?p=&APP_ID.:115:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-plane'
,p_list_item_disp_cond_type=>'USER_IS_PUBLIC_USER'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(184093545745279075)
,p_list_item_display_sequence=>65
,p_list_item_link_text=>'Registro agencias de viajes no recaudaras de impuestos'
,p_list_item_link_target=>'f?p=&APP_ID.:124:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-suitcase'
,p_list_item_disp_cond_type=>'USER_IS_PUBLIC_USER'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'124'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(180829790509751514)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>unistr('Tramite Ch\00E1rter Ocasional Terrestre')
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::P5_TIPO_CONTRIBUYENTE:8:'
,p_list_item_icon=>'fa-truck'
,p_list_item_disp_cond_type=>'USER_IS_PUBLIC_USER'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'122'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(181064013978589448)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>unistr('Solicitar Usuario y Contrase\00F1a')
,p_list_item_link_target=>'f?p=&APP_ID.:123:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'USER_IS_PUBLIC_USER'
,p_parent_list_item_id=>wwv_flow_api.id(180829790509751514)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(189543584764608829)
,p_list_item_display_sequence=>190
,p_list_item_link_text=>unistr('Ingresar con usuario y contrase\00F1a')
,p_list_item_link_target=>'f?p=&APP_ID.:9999:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(180829790509751514)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(166816411320173715)
,p_list_item_display_sequence=>75
,p_list_item_link_text=>unistr('Tr\00E1mite Terrestre Regular')
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::P5_TIPO_CONTRIBUYENTE:17:'
,p_list_item_icon=>'fa-car'
,p_list_item_disp_cond_type=>'NEVER'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(184398500842778565)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Inactivar Agencia de Viajes'
,p_list_item_link_target=>'f?p=&APP_ID.:125:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_list_item_disp_condition=>'GLOBAL_TIPO_INSCRIPCION'
,p_list_item_disp_condition2=>'ANRI'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'125'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(185090795796103903)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Consultas Gestiones Tributarias '
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-align-justify'
,p_list_item_disp_cond_type=>'VALUE_OF_ITEM_IN_CONDITION_NOT_IN_COLON_DELIMITED_LIST'
,p_list_item_disp_condition=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_list_item_disp_condition2=>'16'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(185091774333411474)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Declar. Presentadas Imp. $15 y 5%(ab)'
,p_list_item_link_target=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(185090795796103903)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'200'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(185177102645839149)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Declaraciones Rectificadas'
,p_list_item_link_target=>'f?p=&APP_ID.:201:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(185090795796103903)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(185279888122488352)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'Actuaciones Tributarias'
,p_list_item_link_target=>'f?p=&APP_ID.:202:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(185090795796103903)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'202'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(185585220137298229)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>unistr('Cr\00E9ditos Fiscales')
,p_list_item_link_target=>'f?p=&APP_ID.:203:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(185090795796103903)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'203'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(185779902979223805)
,p_list_item_display_sequence=>160
,p_list_item_link_text=>'Consulta Cuotas Arreglos Pagos'
,p_list_item_link_target=>'f?p=&APP_ID.:204:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(185090795796103903)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'204'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(185790387854505415)
,p_list_item_display_sequence=>170
,p_list_item_link_text=>'Consulta Intereses Tributarios'
,p_list_item_link_target=>'f?p=&APP_ID.:205:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(185090795796103903)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'205'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(186145384919832159)
,p_list_item_display_sequence=>180
,p_list_item_link_text=>'Consulta Intereses Arreglos de Pago'
,p_list_item_link_target=>'f?p=&APP_ID.:206:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(185090795796103903)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'206'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(189780251445484888)
,p_list_item_display_sequence=>200
,p_list_item_link_text=>unistr('Iniciar sesi\00F3n ')
,p_list_item_link_target=>'f?p=&APP_ID.:9999:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-user'
,p_list_item_disp_cond_type=>'USER_IS_PUBLIC_USER'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(175790084229555685)
,p_list_item_display_sequence=>210
,p_list_item_link_text=>unistr('Solicitud Gesti\00F3n de Tr\00E1mite Terrestre Regular')
,p_list_item_link_target=>'f?p=&APP_ID.:128:&SESSION.::&DEBUG.::P128_MOSTRAR_RECOMEN,P128_TTR:N,17:'
,p_list_item_disp_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_list_item_disp_condition=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_list_item_disp_condition2=>'4'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
