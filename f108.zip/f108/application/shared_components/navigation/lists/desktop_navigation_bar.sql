prompt --application/shared_components/navigation/lists/desktop_navigation_bar
begin
--   Manifest
--     LIST: Desktop Navigation Bar
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>108
,p_default_id_offset=>149139848948344617
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(154283063363688838)
,p_name=>'Desktop Navigation Bar'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(154294850934688758)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'&GLOBAL_NOM_ENTIDAD.'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-user'
,p_list_item_disp_cond_type=>'USER_IS_NOT_PUBLIC_USER'
,p_list_text_02=>'has-username'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(154295335387688758)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'---'
,p_list_item_link_target=>'separator'
,p_parent_list_item_id=>wwv_flow_api.id(154294850934688758)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(180262452566629111)
,p_list_item_display_sequence=>25
,p_list_item_link_text=>unistr('Actualizar Contrase\00F1a')
,p_list_item_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::P3_CAMBIAR_PWD:S:'
,p_list_item_icon=>'fa-ellipsis-h'
,p_parent_list_item_id=>wwv_flow_api.id(154294850934688758)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(154295741626688757)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Salir'
,p_list_item_link_target=>'&LOGOUT_URL.'
,p_list_item_icon=>'fa-sign-out'
,p_parent_list_item_id=>wwv_flow_api.id(154294850934688758)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(154462955266417133)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>unistr('Iniciar Sesi\00F3n ')
,p_list_item_link_target=>'f?p=&APP_ID.:9999:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-user'
,p_list_item_disp_cond_type=>'NEVER'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(156812953250966536)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Regresar'
,p_list_item_link_target=>'f?p=501.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-angle-double-left'
,p_list_item_disp_cond_type=>'NEVER'
,p_list_text_02=>'icon-only'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
