prompt --application/shared_components/navigation/lists/navigation_menu_cot
begin
--   Manifest
--     LIST: Navigation Menu COT
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5801312104779619
,p_default_application_id=>108
,p_default_id_offset=>149139848948344617
,p_default_owner=>'DESA_SIT'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(190028168275699893)
,p_name=>'Navigation Menu COT'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(190031581430699897)
,p_list_item_display_sequence=>5
,p_list_item_link_text=>'Mis Datos'
,p_list_item_link_target=>'f?p=&APP_ID.:209:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-address-card'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(190031217865699897)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>unistr('Declaraci\00F3n Jurada de Ch\00E1rter Terrestre Transporte Internacional')
,p_list_item_link_target=>'f?p=&APP_ID.:128:&SESSION.::&DEBUG.::P128_MOSTRAR_RECOMEN:N:'
,p_list_item_icon=>'fa-truck'
,p_list_item_disp_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_list_item_disp_condition=>'GLOBAL_TIPO_CONTRIBUYENTE'
,p_list_item_disp_condition2=>'8'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_api.component_end;
end;
/
